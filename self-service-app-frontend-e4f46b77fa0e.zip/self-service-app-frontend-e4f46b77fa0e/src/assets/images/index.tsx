export const IMAGES = {
    google: require('./google.png'),
    background: require('./background.png'),
    notification: require('./notification.png'),
    back: require('./back.png'),
    profile: require('./profile.png'),
    logo: require('./telecom.png'),
    facebook: require('./facebook.png'),
    apple: require('./apple.png'),
    down: require('./down.png'),
}