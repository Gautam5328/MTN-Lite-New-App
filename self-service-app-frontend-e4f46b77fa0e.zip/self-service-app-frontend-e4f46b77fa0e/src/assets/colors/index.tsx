export const LIGHT_THEME_COLOR = {
     _E31837: '#E31837',
     _80C72E: '#80C72E',
     _F7F7F7: '#f7f7f7',
     _D3D3D3: '#d3d3d3',
     _AFAFAF: '#afafaf',
     _333333: "#333333",
     _FFF: '#fff',
     _000: '#000',
}

export const DARK_THEME_COLOR = {
    _E31837: '#E31837',
    _80C72E: '#80C72E',
    _F7F7F7: '#f7f7f7',
    _D3D3D3: '#d3d3d3',
    _AFAFAF: '#afafaf',
    _333333: "#333333",
    _FFF: '#fff',
    _000: '#000'
}