export default {
    //LEADING SCREEN
    your_one_stop_application: "Your One Stop Application.",
    boost_your_life_enhance_your_world: 'Boost your life enhance your world',
    let_get_started: "Let's get started",

    //LOGIN SCREEN
    welcome_to: "Welcome To ",
    telecom: 'Telecom!',
    insert_your_phone_number_to_continue: 'Insert your phone number to continue',
    mobile_number: 'Mobile Number',
    continue: 'Continue',
    or: 'OR',
    continue_with_apple: "Continue with Apple",
    continue_with_facebook: "Continue with Facebook",
    continue_with_google: "Continue with Google",
};