import { getScaleSize } from './scaleSize'
import { STRINGS, getTranslation } from './strings'

export {
    getScaleSize,

    STRINGS,
    getTranslation
}