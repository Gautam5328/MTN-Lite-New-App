import React, { createContext, useEffect, useState } from 'react'

//ASSETS
import { LIGHT_THEME_COLOR, DARK_THEME_COLOR } from '../assets'
import { operator } from '../constant';


interface ThemeProviderProps {
    children: JSX.Element
}

enum ThemeName {
    Light = 'light',
    DARK = 'dark'
}

export type ThemeContextType = {
    currentTheme: ThemeName,
    theme: typeof LIGHT_THEME_COLOR,
    operator: string
};

const initalValues = {
    currentTheme: ThemeName.Light,
    theme: LIGHT_THEME_COLOR,
    operator: operator
}

export const ThemeContext = createContext<ThemeContextType>(initalValues);

export function ThemeProvider(props: ThemeProviderProps): JSX.Element {

    const [currentTheme, setCurrentTheme] = useState<ThemeName>(ThemeName.Light)

    useEffect(() => {

    }, [currentTheme])

    function getTheme() {
        if (currentTheme == 'dark') {
            return DARK_THEME_COLOR
        }
        else {
            return LIGHT_THEME_COLOR
        }
    }

    const theme = getTheme()

    const contextValue: ThemeContextType = {
        theme: theme,
        currentTheme: currentTheme,
        operator: operator
    };

    return (
        <ThemeContext.Provider
            value={contextValue}>
            {props.children}
        </ThemeContext.Provider >
    )
}
