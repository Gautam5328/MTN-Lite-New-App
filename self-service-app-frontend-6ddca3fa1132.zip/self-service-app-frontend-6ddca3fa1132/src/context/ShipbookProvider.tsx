import React, { createContext, useEffect } from 'react'

// Logging library
import shipbook from '@shipbook/react-native';
import Log from '@shipbook/react-native/lib/log';
import KeysTurbo from 'react-native-keys';

interface ShipbookProviderProps {
  children: JSX.Element
}

interface ShipbookContextType {
  logDetails: (message: string) => void,
  logScreen: (screenName: string) => void,
};

export const ShipbookContext = createContext<ShipbookContextType>();


export function ShipbookProvider(props: ShipbookProviderProps): JSX.Element {

  useEffect(() => {
    // TODO: Replace the provided App ID and App Key with new credentials
    //  when creating a new Shipbook account
    const appID = KeysTurbo.secureFor('shipbook_api_key')
    const appKey = KeysTurbo.secureFor('shipbook_api_key')
    shipbook.start(appID, appKey);

    // TODO: Replace userId argument in the below registerUser() 
    // with the dynamic userId received from the API after login
    shipbook.registerUser('103');
  }, []);

  const log = getLogDetails();

  function getLogDetails(tagName = 'MODULE_NAME') {
    return shipbook.getLogger(tagName);
  }

  function logDetails(message: string) {
    if (KeysTurbo.DISABLE_SHIP_BOOK_LOG == 'false') {
      log.i(message)
    }
    
  }

  function logScreen(screenName: string) {
    shipbook.screen(screenName)
  }

  const contextValue: ShipbookContextType = {
    logDetails,
    logScreen
  };

  return (
    <ShipbookContext.Provider
      value={contextValue}>
      {props.children}
    </ShipbookContext.Provider >
  )
}
