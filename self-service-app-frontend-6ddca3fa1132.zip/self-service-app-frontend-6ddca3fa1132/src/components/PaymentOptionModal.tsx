import React, { useState, useContext } from "react"
import { StyleProp, ViewStyle, View, Modal, Dimensions, TouchableOpacity, Image, StyleSheet, FlatList } from "react-native";//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { PaymentOptions, getScaleSize } from "../constant";
import { FONTS } from "../assets";

//COMPONENTS
import { Button, Icons, Text } from ".";

const PaymentOptionModal = (props: any) => {
    const { theme } = useContext(ThemeContext)

    const [selectedItem, setSelectedItem] = useState<any>()

    return (
        <Modal
            animationType="fade"
            transparent={true}
            visible={props.visible}
            onRequestClose={props.onClose}
        >
            <View style={styles(theme).optionCardContainer}>
                <View style={styles(theme).optioncard}>
                    <TouchableOpacity style={styles(theme).closeIcon} onPress={props.onClose}
                    >
                        <Icons
                            name={'close'}
                            color={theme._AFAFAF}
                            type={'MaterialIcons'}
                            size={20} />
                    </TouchableOpacity>
                    <FlatList
                        data={PaymentOptions}
                        renderItem={({ item, index }) => {
                            return (
                                <TouchableOpacity onPress={() => {
                                    setSelectedItem(item)
                                    props.onPress(item, index)

                                }}>
                                    <View style={styles(theme).optionCOntainer}>

                                        <View style={styles(theme).iconContainer}>
                                            <Icons
                                                name={selectedItem?.title == item?.title ? 'radio-btn-active' : 'radio-btn-passive'}
                                                color={selectedItem?.title == item?.title ? theme.MAIN_THEME_COLOR : theme._D3D3D3}
                                                size={16}
                                                type='Fontisto' />
                                        </View>
                                        <Text
                                            font={FONTS.Roboto.Medium}
                                            color={theme._333333}
                                            size={getScaleSize(16)}>
                                            {item?.title}
                                        </Text>
                                    </View>
                                </TouchableOpacity>

                            )
                        }} />
                </View>
            </View>

        </Modal>
    )

}
export default PaymentOptionModal

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({

    optionCardContainer: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center", backgroundColor: 'rgba(52, 52, 52, 0.9)'
    },
    optioncard: {
        backgroundColor: "#fff",
        borderRadius: getScaleSize(10),
        paddingTop: getScaleSize(20),
        paddingBottom: getScaleSize(20),
        width: Dimensions.get('window').width - getScaleSize(60),
        alignItems: "center",
        justifyContent: "center",
        alignContent: "center",
        paddingHorizontal: getScaleSize(15),
        position: 'relative'
    },
    closeIcon: {
        position: 'absolute',
        top: getScaleSize(8), right: getScaleSize(8)
    },
    iconContainer: { marginRight: getScaleSize(15), marginTop: getScaleSize(4) },
    optionCOntainer: { flexDirection: 'row', margin: getScaleSize(10) }
})