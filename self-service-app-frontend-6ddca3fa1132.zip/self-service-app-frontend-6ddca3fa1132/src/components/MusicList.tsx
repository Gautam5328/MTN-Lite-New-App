import React, { useContext, useEffect, useState } from 'react';
import { View, SafeAreaView, StyleSheet, FlatList, TouchableOpacity, Image, ScrollView, ActivityIndicator } from 'react-native';

//CONSTANT
import { FONTS } from '../assets'

//CONTEXT
import { ThemeContext, ThemeContextType } from '../context';
import { getScaleSize, showMessageToast } from '../constant';

//API
import { API } from '../api';

//PACKAGES
import _ from 'lodash';

//COMPONENTS
import { CategoryList, List, MusicPlayer, Text } from '../components';

function MusicList(props: any) {

    const { theme } = useContext(ThemeContext)

    const [loading, setLoading] = useState(false);
    const [musicList, setMusicList] = useState<any[]>([])
    const [presignedUrl, setPresignedUrl] = useState('');
    const [selectedMusic, setSelectedMusic] = useState(null);

    useEffect(() => {
        getMusicList();
    }, [])

    async function getMusicList() {
        try {
            setLoading(true);
            const result = await API.transactionInstance.get('/play/music')
            if (result.status == 200) {
                if (result?.data) {
                    const musicList = result?.data?.audio_list ?? []
                    const array = musicList.map((e: any) => {
                        var output1 = Object.entries(e).map(([key, value]) => ({ title: key, data: value }));
                        return output1[0]
                    })
                    setMusicList(array)
                    setLoading(false)
                }
            } else {
                setMusicList([])
            }
        }
        catch (error: any) {
            setLoading(false)
            setMusicList([])
            showMessageToast(error?.message ?? '')
        }
    }
    // if (loading) {
    //     return (
    // <View style={[styles(theme).emptyContainer]}>
    //     <ActivityIndicator color={theme.MAIN_THEME_COLOR} size='large' />
    // </View>
    //     )
    // }
    // else {
    return (
        <ScrollView style={styles(theme).rootContainer} showsVerticalScrollIndicator={false}>
            <List isLoading={loading}>
                <View style={styles(theme).container}>
                    {musicList.map((category, index) => (
                        <CategoryList
                            key={index}
                            theme={theme}
                            category={category}
                            handlePress={(item: any) => MusicPlayer.setAudio(item)}
                        />
                    ))}
                </View>
                <SafeAreaView />
            </List>
        </ScrollView>
    )
}
// }

export default MusicList;

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({

    rootContainer: {
        backgroundColor: theme._FFF,
    },
    languageIconContainer: {
        alignItems: 'center',
        marginRight: getScaleSize(15),
        marginTop: getScaleSize(20),
        marginBottom: getScaleSize(20)
    },
    languageIcon: {
        width: getScaleSize(100),
        height: getScaleSize(120),
        borderRadius: getScaleSize(2),
    },
    movContainer: { marginTop: getScaleSize(5), marginBottom: getScaleSize(5) },
    container: { padding: getScaleSize(16) },
    emptyContainer: {
        flex: 1.0,
        backgroundColor: theme._FFF,
        justifyContent: 'center'
    }
})
