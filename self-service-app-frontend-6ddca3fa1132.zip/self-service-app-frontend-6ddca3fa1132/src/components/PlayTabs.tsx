import React, { useContext, useEffect, useState } from 'react';
import { View, PressableAndroidRippleConfig, StyleProp, TextStyle, ViewStyle, Dimensions, StyleSheet, ActivityIndicator } from 'react-native';
//Context
import { ThemeContext } from "../context";
//Components
import { Games, MusicList, NewsList, VideoList } from '../components';
//Packages
import { TabView, TabBar, SceneMap, NavigationState, Route, SceneRendererProps, TabBarIndicatorProps, TabBarItemProps } from 'react-native-tab-view';
import { Scene, Event } from 'react-native-tab-view/lib/typescript/src/types';
import { EventRegister } from 'react-native-event-listeners';

const initialLayout = { width: Dimensions.get('window').width };

function PlayTabs(props: any) {

  const { theme } = useContext(ThemeContext);

  const [index, setIndex] = useState(0);

  const [routes] = useState([
    { key: 'music', title: 'Music' },
    { key: 'videos', title: 'Videos' },
    { key: 'news', title: 'News' },
    { key: 'games', title: 'Games' },
  ]);

  useEffect(() => {
    EventRegister.addEventListener('onRedirectToPlay', (type) => {
      if (type == 'Music') {
        setIndex(0)
      } else if (type == 'Movies') {
        setIndex(1)
      } else if (type == 'News') {
        setIndex(2)
      }
    });

    if (props.redirect) {
      if (props.redirect == 'Music') {
        setIndex(0)
      } else if (props.redirect == 'Movies') {
        setIndex(1)
      } else if (props.redirect == 'News') {
        setIndex(2)
      }
    }

    return () => {
      EventRegister.removeEventListener('onMusic')
    }
  }, [])

  const renderScene = SceneMap({

    games: () => (
      <Games navigation={props.navigation} />
    ),
    music: () => (
      <MusicList navigation={props.navigation} />
    ),
    videos: () => (
      <VideoList navigation={props.navigation} />
    ),
    news: () => (
      <NewsList navigation={props.navigation} />
    )

  });

  const renderTabBar = (props: React.JSX.IntrinsicAttributes & SceneRendererProps & { navigationState: NavigationState<Route>; scrollEnabled?: boolean | undefined; bounces?: boolean | undefined; activeColor?: string | undefined; inactiveColor?: string | undefined; pressColor?: string | undefined; pressOpacity?: number | undefined; getLabelText?: ((scene: Scene<Route>) => string | undefined) | undefined; getAccessible?: ((scene: Scene<Route>) => boolean | undefined) | undefined; getAccessibilityLabel?: ((scene: Scene<Route>) => string | undefined) | undefined; getTestID?: ((scene: Scene<Route>) => string | undefined) | undefined; renderLabel?: ((scene: Scene<Route> & { focused: boolean; color: string; }) => React.ReactNode) | undefined; renderIcon?: ((scene: Scene<Route> & { focused: boolean; color: string; }) => React.ReactNode) | undefined; renderBadge?: ((scene: Scene<Route>) => React.ReactNode) | undefined; renderIndicator?: ((props: TabBarIndicatorProps<Route>) => React.ReactNode) | undefined; renderTabBarItem?: ((props: TabBarItemProps<Route> & { key: string; }) => React.ReactElement<any, string | React.JSXElementConstructor<any>>) | undefined; onTabPress?: ((scene: Scene<Route> & Event) => void) | undefined; onTabLongPress?: ((scene: Scene<Route>) => void) | undefined; tabStyle?: StyleProp<ViewStyle>; indicatorStyle?: StyleProp<ViewStyle>; indicatorContainerStyle?: StyleProp<ViewStyle>; labelStyle?: StyleProp<TextStyle>; contentContainerStyle?: StyleProp<ViewStyle>; style?: StyleProp<ViewStyle>; gap?: number | undefined; testID?: string | undefined; android_ripple?: PressableAndroidRippleConfig | undefined; }) => (
    <TabBar
      {...props}
      indicatorStyle={{ backgroundColor: theme.TEXT_COLOR_AS_THEME }}
      style={{ backgroundColor: theme.MAIN_THEME_COLOR, elevation: 0 }}
      tabStyle={{ height: 45 }}
      labelStyle={{ fontSize: 13, color: theme.TEXT_COLOR_AS_THEME, textTransform: 'none', fontWeight: 'bold' }}
    />
  );

  return (
    <View style={styles.container}>
      <TabView
        navigationState={{ index, routes }}
        renderScene={renderScene}
        renderTabBar={renderTabBar}
        onIndexChange={setIndex}
        initialLayout={initialLayout}
        swipeEnabled={false}
        animationEnabled={true}
      />
    </View>
  );
};

export default PlayTabs;

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
});