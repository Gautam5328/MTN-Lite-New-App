import React, { useContext } from "react";
import { Image, StyleProp, StyleSheet, TouchableOpacity, View, ViewStyle, ActivityIndicator } from 'react-native'

//ASSETS & CONSTANTS
import { FONTS, IMAGES } from "../assets";
import { STRINGS, formatToDecimalNumber, getScaleSize } from "../constant";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//COMPONENTS
import Text from "./Text";
import Button from "./Button";
import Icons from "./Icons";
import moment from "moment";

interface HomeCardProps {
    style?: StyleProp<ViewStyle>
    item?: any
    onPayBill?: () => void,
    onRecharge?: () => void,
    onBuyBundle?: () => void,
    onRefresh?: () => void,
    isLoading?: boolean
}

function HomeCard(props: HomeCardProps) {

    const { theme } = useContext(ThemeContext)

    const item = props?.item

    if (props?.isLoading) {
        return (
            <View style={[styles(theme).container, props.style]}>
                <View style={[styles(theme).cardHeader]}>
                    <Icons
                        name={'mobile'}
                        color={theme.TEXT_COLOR_AS_THEME}
                        type={'Fontisto'}
                        size={20} />
                        <Text
                            font={FONTS.Roboto.Regular}
                            color={theme.SUB_TEXT_COLOR_AS_THEME}
                            size={getScaleSize(12)}>
                            {item?.billing_type ?? '-'}
                        </Text>
                    <Text
                        font={FONTS.Roboto.Regular}
                        color={theme.SUB_TEXT_COLOR_AS_THEME}
                        size={getScaleSize(12)}>
                        {item?.msisdn ?? '-'}
                    </Text>
                    <TouchableOpacity style={styles(theme).refreshIconContainer}
                        onPress={props?.onRefresh}>
                        <Image style={styles(theme).refreshIcon} source={IMAGES.refresh} />
                    </TouchableOpacity>
                </View>
                <View style={styles(theme).cardDetails}>

                    <View style={styles(theme).cardDetailsItem}>
                        <ActivityIndicator color={theme.TEXT_COLOR_AS_THEME} />
                        <Text
                            style={{ marginTop: getScaleSize(2) }}
                            font={FONTS.Roboto.Regular}
                            color={theme.SUB_TEXT_COLOR_AS_THEME}
                            size={getScaleSize(10)}>
                            {STRINGS.airtime_balance}
                        </Text>
                    </View>
                    <View style={styles(theme).cardDetailsSeperator}></View>
                    <View style={styles(theme).cardDetailsItem}>
                        <ActivityIndicator color={theme.TEXT_COLOR_AS_THEME} />
                        <Text
                            style={{ marginTop: getScaleSize(2) }}
                            font={FONTS.Roboto.Regular}
                            color={theme.SUB_TEXT_COLOR_AS_THEME}
                            size={getScaleSize(10)}>
                            {STRINGS.data_balance}
                        </Text>
                    </View>
                </View>
                <View style={styles(theme).cardFotter}>
                    <TouchableOpacity style={styles(theme).btnRechargeContainer}>
                        <Text
                            font={FONTS.Roboto.Regular}
                            color={theme._333333}
                            size={getScaleSize(11)}>
                            <ActivityIndicator color={theme._333333} />
                        </Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles(theme).btnRechargeContainer} >
                        <Text
                            font={FONTS.Roboto.Regular}
                            color={theme._333333}
                            size={getScaleSize(11)}>
                            <ActivityIndicator color={theme._333333} />
                        </Text>
                    </TouchableOpacity>
                </View>
            </View>
        )
    }
    else {
        return (
            <View style={[styles(theme).container, props.style]}>
                <View style={[styles(theme).cardHeader]}>
                    <Icons
                        name={'mobile'}
                        color={theme.TEXT_COLOR_AS_THEME}
                        type={'Fontisto'}
                        size={20} />
                    <Text
                        font={FONTS.Roboto.Regular}
                        color={theme.SUB_TEXT_COLOR_AS_THEME}
                        size={getScaleSize(12)}>
                        {item?.billing_type != undefined ? 'Mobile ' + item?.billing_type : 'Mobile Prepaid'}
                    </Text>
                    <Text
                        font={FONTS.Roboto.Regular}
                        color={theme.SUB_TEXT_COLOR_AS_THEME}
                        size={getScaleSize(12)}>
                        {item?.msisdn ?? ''}
                    </Text>
                    <TouchableOpacity style={styles(theme).refreshIconContainer}
                        onPress={props?.onRefresh}>
                        <Image style={styles(theme).refreshIcon} source={IMAGES.refresh} />
                    </TouchableOpacity>
                </View>
                <View style={styles(theme).cardDetails}>

                    <View style={styles(theme).cardDetailsItem}>

                    <Text
                            style={{ marginTop: getScaleSize(2) }}
                            font={FONTS.Roboto.Regular}
                            color={theme.SUB_TEXT_COLOR_AS_THEME}
                            size={getScaleSize(12)}>
                            {STRINGS.airtime}
                        </Text>
                        <Text
                            font={FONTS.Roboto.Medium}
                            color={theme.TEXT_COLOR_AS_THEME}
                            size={getScaleSize(16)}>
                            {STRINGS.currency+`${formatToDecimalNumber(item?.airtime_balance)}`}
                        </Text>
                    </View>
                    <View style={styles(theme).cardDetailsSeperator}></View>
                    
                    <View style={styles(theme).cardDetailsItem}>
                        <Text
                            style={{ marginTop: getScaleSize(2) }}
                            font={FONTS.Roboto.Regular}
                            color={theme.SUB_TEXT_COLOR_AS_THEME}
                            size={getScaleSize(12)}>
                            {STRINGS.data}
                        </Text>
                        <Text
                            font={FONTS.Roboto.Medium}
                            color={theme.TEXT_COLOR_AS_THEME}
                            size={getScaleSize(16)}>
                            {`${item?.data_balance} MB`}
                        </Text>
                        <Text
                        font={FONTS.Roboto.Regular}
                        color={theme.SUB_TEXT_COLOR_AS_THEME}
                        size={getScaleSize(10)}>
                        {item?.plan_name ?? ''}
                    </Text>
                        <Text
                            font={FONTS.Roboto.Regular}
                            color={theme.SUB_TEXT_COLOR_AS_THEME}
                            size={getScaleSize(10)}>
                            {
                                ((moment.duration(item?.validity, 'minutes')).days() < 1) ?
                                    'Renews in ' + (moment.duration(item?.validity, 'minutes')).hours() + ' hours'
                                    :
                                    'Renews in ' + (moment.duration(item?.validity, 'minutes')).days() + ' days'
                            }
                        </Text>
                    </View>
                </View>
                <View style={styles(theme).cardFotter}>
                    {item?.billing_type=="Postpaid"?
                    <TouchableOpacity style={styles(theme).btnRechargeContainer} onPress={props.onPayBill}>
                        <Text
                            font={FONTS.Roboto.Medium}
                            color={theme._333333}
                            size={getScaleSize(14)}>
                            {STRINGS.pay_bill}
                        </Text>
                    </TouchableOpacity>
                    :
                    <TouchableOpacity style={styles(theme).btnRechargeContainer} onPress={props.onRecharge}>
                        <Text
                            font={FONTS.Roboto.Medium}
                            color={theme._333333}
                            size={getScaleSize(14)}>
                            {STRINGS.recharge}
                        </Text>
                    </TouchableOpacity>
    }
                    <TouchableOpacity style={styles(theme).btnRechargeContainer} onPress={props.onBuyBundle}>
                        <Text
                            font={FONTS.Roboto.Medium}
                            color={theme._333333}
                            size={getScaleSize(14)}>
                            {STRINGS.buy_bundle}
                        </Text>
                    </TouchableOpacity>
                </View>
            </View>
        )
    }

}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        backgroundColor: theme.MAIN_THEME_COLOR,
        borderRadius: getScaleSize(20),
        padding: getScaleSize(5),
        overflow: 'hidden'
    },
    cardHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: getScaleSize(12),
        alignItems: 'center',
        borderBottomWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.5)'
    },
    refreshIconContainer: {
        height: getScaleSize(40),
        width: getScaleSize(40),
        justifyContent: 'center',
        alignItems: 'center'
    },
    refreshIcon: {
        height: getScaleSize(20),
        width: getScaleSize(20),
        tintColor: theme.SUB_TEXT_COLOR_AS_THEME
    },
    cardDetails: {
        flexDirection: 'row',
        marginVertical: getScaleSize(15)
    },
    cardDetailsItem: {
        flex: 1.0,
        // justifyContent: 'center',
        alignItems: 'flex-start',
        marginHorizontal:getScaleSize(12)
    },
    cardDetailsSeperator: {
        // flex: 1.0,
        backgroundColor: 'rgba(255, 255, 255, 0.5)',
        width:getScaleSize(1)
    },
    cardFotter: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: getScaleSize(12),
        // alignItems: 'center',
        marginBottom: getScaleSize(10)
    },
    btnRechargeContainer: {
        paddingHorizontal: getScaleSize(10),
        paddingVertical: getScaleSize(5),
        backgroundColor: theme._FFF,
        borderRadius: getScaleSize(15),
        width:'45%',
        alignItems:'center',
    },
    emptyContainer: {
        height: getScaleSize(150),
        marginHorizontal: getScaleSize(13),
        backgroundColor: theme.MAIN_THEME_COLOR,
        borderRadius: getScaleSize(20),
        justifyContent: 'center'
    }
})
export default HomeCard