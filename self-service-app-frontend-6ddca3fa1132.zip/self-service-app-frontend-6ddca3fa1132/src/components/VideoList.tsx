import React, { useContext, useEffect, useState } from 'react';
import { View, StyleSheet, SafeAreaView, FlatList, Image, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
//Assets
import { FONTS } from '../assets';
//Components
import { CategoryList, List, MusicPlayer, Text } from '../components';
//Constants
import { getScaleSize, showMessageToast } from '../constant';
//Context
import { ThemeContext, ThemeContextType } from '../context';
//API
import { API } from '../api';
//Screens
import { SCREENS } from '../screens';

import _ from 'lodash';

function VideoList(props: any) {

    const { theme } = useContext(ThemeContext);

    const [videoList, setVideoList] = useState<Array<{ title: string; data: any[] }>>([]);

    const [selectedVideo, setSelectedVideo] = useState(null);

    const [presignedUrl, setPresignedUrl] = useState('');

    const [loading, setLoading] = useState(false);

    useEffect(() => {
        fetchVideoList();
    }, []);

    const fetchVideoList = async () => {
        try {
            setLoading(true)
            const result = await API.transactionInstance.get('/play/video');
            if (result.status === 200) {
                const videoList = result?.data?.video_list ?? []
                const array = videoList.map((e: any) => {
                    var output1 = Object.entries(e).map(([key, value]) => ({ title: key, data: value }));
                    return output1[0]
                })
                setVideoList(array)
                setLoading(false)
            }
        } catch (error: any) {
            setLoading(false)
            showMessageToast(error?.message ?? '');
        }
    };

    const getPresignedUrl = async (videoId: any) => {
        try {
            const result = await API.transactionInstance.get(`/play/presignedurl/${videoId}`);
            if (result.status === 200) {
                const url = result?.data?.url;
                props.navigation.navigate(SCREENS.PlayVideo.identifier, { url });
            }
        } catch (error: any) {
            showMessageToast(error?.message ?? '');
        }
    };

    const handleVideoPress = (video: any) => {
        MusicPlayer.stopPlayer()
        setSelectedVideo(video);
        getPresignedUrl(video.video_id);
    };
    // if (loading) {
    //     return (
    //         <View style={[style(theme).emptyContainer]}>
    //             <ActivityIndicator color={theme.MAIN_THEME_COLOR} size='large' />
    //         </View>)
    // }
    // else {
    return (
        <ScrollView style={style(theme).rootContainer} showsVerticalScrollIndicator={false}>
            <List isLoading={loading}>
                <View style={style(theme).container}>
                    {videoList.map((category, index) => (
                        <CategoryList
                            key={index}
                            theme={theme}
                            category={category}
                            handlePress={handleVideoPress}
                        />
                    ))}
                </View>
                <SafeAreaView />
            </List>
        </ScrollView>
    );
}
// }

export default VideoList;

const style = (theme: ThemeContextType['theme']) =>
    StyleSheet.create({
        rootContainer: {
            backgroundColor: theme._FFF,
        },
        languageIconContainer: {
            alignItems: 'center',
            marginRight: getScaleSize(15),
            marginTop: getScaleSize(20),
            marginBottom: getScaleSize(20)
        },
        languageIcon: {
            width: getScaleSize(100),
            height: getScaleSize(120),
            borderRadius: getScaleSize(2),
        },
        movContainer: {
            marginTop: getScaleSize(5),
            marginBottom: getScaleSize(5)
        },
        container:
        {
            padding: getScaleSize(16)
        },
        emptyContainer: {
            flex: 1.0,
            backgroundColor: theme._FFF,
            justifyContent: 'center'
        }
    });
