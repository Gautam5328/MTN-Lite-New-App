import FontAwesome from 'react-native-vector-icons/FontAwesome'
import Feather from 'react-native-vector-icons/Feather'
import Foundation from 'react-native-vector-icons/Foundation'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons'
import Fontisto from 'react-native-vector-icons/Fontisto'
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons'

interface IconsProps {
    name: string,
    size: number,
    type: 'FontAwesome' | 'Feather' | 'Foundation' | 'MaterialIcons' | 'Fontisto' | 'MaterialIcons' | 'MaterialCommunityIcons',
    color: string
}

export default function Icons(props: IconsProps) {

    if (props.type == 'FontAwesome') {
        return (
            <FontAwesome
                name={props.name}
                size={props.size}
                color={props.color} />
        )
    }
    else if (props.type == 'Feather') {
        return (
            <Feather
                name={props.name}
                size={props.size} 
                color={props.color}/>
        )
    }
    else if (props.type == 'Foundation') {
        return (
            <Foundation
                name={props.name}
                size={props.size} 
                color={props.color}/>
        )
    }
    else if (props.type == 'MaterialIcons') { 
        return (
            <MaterialIcons
                name={props.name}
                size={props.size} 
                color={props.color}/>
        )
    }
    else if (props.type == 'Fontisto') {
        return (
            <Fontisto
                name={props.name}
                size={props.size} 
                color={props.color}/>
        )
    }
    else if (props.type == 'MaterialCommunityIcons') {
        return (
            <MaterialCommunityIcons
                name={props.name}
                size={props.size} 
                color={props.color}/>
        )
    }
   
}