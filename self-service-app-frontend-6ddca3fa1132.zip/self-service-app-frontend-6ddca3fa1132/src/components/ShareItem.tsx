import React, { useContext } from 'react'
import { StyleSheet, View ,TouchableOpacity,ViewStyle,StyleProp} from 'react-native'

//COMPONENTS
import Text from './Text'

//ASSETS
import { FONTS } from '../assets'

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//CONSTANT
import { getScaleSize } from "../constant";
import Icons from './Icons';

interface ShareItemProps {
    title?: string | '',
    description?:string | '',
    iconName: string,
    onPress?: () => void,
}
export default function ShareItem(props:ShareItemProps) {

    const { theme } = useContext(ThemeContext)
    return(
        <TouchableOpacity style={styles(theme).shareContainer} onPress={props.onPress}>
            <View style={{ flex: 1, flexDirection: 'row', }}>
                <Icons
                    name={props.iconName}
                    color={theme.TEXT_COLOR_AS_THEME}
                    type={'MaterialIcons'}
                    size={40} />
                <View style={{ marginLeft: getScaleSize(10) }}>
                    <Text
                        font={FONTS.Roboto.Bold}
                        color={theme.TEXT_COLOR_AS_THEME}
                        size={getScaleSize(16)}>
                        {props.title}
                    </Text>
                    <Text
                        font={FONTS.Roboto.Regular}
                        color={theme.TEXT_COLOR_AS_THEME}
                        size={getScaleSize(12)}>
                        {props.description}
                    </Text>
                </View>
            </View>
            <View style={{ justifyContent: 'center' }}>
                <Icons
                    name={'angle-right'}
                    color={theme.ICON_COLOR_AS_THEME}
                    type={'FontAwesome'}
                    size={20} />
            </View>
        </TouchableOpacity>
    )
}
const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    shareContainer: {
        marginVertical: getScaleSize(10),
        flexDirection: 'row',
        padding: getScaleSize(20),
        backgroundColor: theme.MAIN_THEME_COLOR,
        borderRadius: getScaleSize(10)
    }
})