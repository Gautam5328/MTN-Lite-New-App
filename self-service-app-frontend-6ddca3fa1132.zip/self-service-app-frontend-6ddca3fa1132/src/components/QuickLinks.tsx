import React, { useContext } from "react";
import { Dimensions, Image, StyleSheet, TouchableOpacity, View } from 'react-native'

//COMPONENTS
import Text from "./Text";

//CONTEXT
import { ThemeContextType, ThemeContext } from "../context";

//CONSTANTS & ASSETS
import { STRINGS, getScaleSize, showMessageToast } from "../constant";
import { FONTS, IMAGES } from "../assets";

//COMPONENTS
import Icons from "./Icons";

//PACKAGES
import { useNavigation } from "@react-navigation/native";
import { useSelector } from "react-redux";

//EVENT
import { EventRegister } from 'react-native-event-listeners';

interface QuickLinksProps {
    data?: any,
    onPress?: (item: any) => void,
}

function QuickLinks(props: QuickLinksProps) {

    const customerDetails = useSelector((state: any) => state.customerData);

    const navigation = useNavigation()

    const { theme } = useContext(ThemeContext)

    function onPress(item: any) {
        if (item.navigation) {
            if (item?.navigation == 'History') {
                if (customerDetails?.customer?.msisdns?.length > 0) {
                    navigation.navigate(item?.navigation)
                } else {
                    showMessageToast("You don't have any valid msisdn")
                }
            } else if (item?.navigation == 'Music') {
                EventRegister.emit('onRedirectToPlay', 'Music')
                navigation.navigate('Play', {
                    redirect: 'Music'
                })
            } else if (item?.navigation == 'Movies') {
                EventRegister.emit('onRedirectToPlay', 'Movies')
                navigation.navigate('Play', {
                    redirect: 'Movies'
                })
            } else if (item?.navigation == 'News') {
                EventRegister.emit('onRedirectToPlay', 'News')
                navigation.navigate('Play', {
                    redirect: 'News'
                })
            } else {
                navigation.navigate(item?.navigation)
            }
        }
    }

    return (
        <View>
            <Text
                style={{ marginHorizontal: getScaleSize(24) }}
                align="center"
                font={FONTS.Roboto.Bold}
                color={theme._333333}
                size={getScaleSize(18)}>
                {STRINGS.quick_links}
            </Text>
            <View style={styles(theme).container}>
                {props.data?.map((item: any, index: number) => {
                    return (
                        <TouchableOpacity
                            key={index}
                            style={styles(theme).linkItem}
                            onPress={() => onPress(item)}>
                            <View style={styles(theme).linkItemImage}>
                                <Icons
                                    name={item.image}
                                    color={item.color}
                                    type={item.type}
                                    size={20} />
                            </View>
                            <Text
                                align="center"
                                font={FONTS.Roboto.Medium}
                                color={theme._333333}
                                size={getScaleSize(10)}>
                                {item?.title}
                            </Text>
                        </TouchableOpacity>
                    )
                })}
            </View>
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        paddingBottom: getScaleSize(20)
    },
    linkItem: {
        width: Dimensions.get('window').width / 4,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: getScaleSize(20)
    },
    linkItemImage: {
        width: getScaleSize(50),
        height: getScaleSize(50),
        backgroundColor: theme._F7F7F7,
        borderRadius: (Dimensions.get('window').width / 6) / 2,
        marginBottom: getScaleSize(5),
        justifyContent: 'center',
        alignItems: 'center'
    },
    linkImage: {
        width: getScaleSize(40),
        height: getScaleSize(40),
    }
})

export default QuickLinks