import React, { useContext } from "react";
import { StyleProp, ViewStyle, View, StyleSheet } from 'react-native'

//CONSTANT & ASSETS
import { STRINGS, getScaleSize, formatToDecimalNumber } from "../constant";
import { FONTS } from "../assets";

//COMPONENTS
import Text from "./Text";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";
import Button from "./Button";


interface BundleCardProps {
    style?: StyleProp<ViewStyle>,
    plan_name?: string | '',
    plan_description?: string | '',
    category?: string | '',
    price?: number | 0,
    onPress?: () => void,
}

function BundleCard(props: BundleCardProps) {

    const { theme } = useContext(ThemeContext)

    return (
        <View style={[styles(theme).container, props.style]}>
            <View style={styles(theme).bundleContainer}>
                <View style={styles(theme).amountContainer}>
                <Text
                        font={FONTS.Roboto.Bold}
                        color={theme._333333}
                        size={getScaleSize(16)}>
                        {props.plan_name}
                    </Text>
                    

                </View>
                <View style={styles(theme).otherContainer}>
                <Text
                        font={FONTS.Roboto.Bold}
                        color={theme.MAIN_THEME_COLOR}
                        size={getScaleSize(16)}>
                        {STRINGS.currency + formatToDecimalNumber(props.price)}
                    </Text>
                    
                </View>
            </View>
            <View>
                <Text
                    font={FONTS.Roboto.Regular}
                    color={theme._828282}
                    size={getScaleSize(12)}>
                    {props.plan_description}
                </Text>
            </View>

            <View style={styles(theme).buttonContainer}>
                <Button style={{ width: getScaleSize(100), }}
                    title={STRINGS.buy_now}
                    onPress={props.onPress} />
            </View>
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1,
        borderColor: theme._F5F5F5,
        borderWidth: getScaleSize(1),
        borderRadius: getScaleSize(10),
        padding: getScaleSize(15),
        marginVertical: getScaleSize(10),
        backgroundColor: theme._F7F7F7
    },
    bundleContainer: { flexDirection: 'row', marginBottom: getScaleSize(5) },
    amountContainer: { flex: 1 },
    otherContainer: { marginLeft: getScaleSize(10) },
    buttonContainer: { alignItems: 'flex-end', marginTop: getScaleSize(5) }
})

export default BundleCard