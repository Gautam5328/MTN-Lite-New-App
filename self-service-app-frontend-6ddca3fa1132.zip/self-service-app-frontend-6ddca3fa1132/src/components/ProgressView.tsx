import React, { useContext } from 'react'
import { View, Modal, ActivityIndicator, StyleSheet } from 'react-native';

//CONTEXT
import { ThemeContext, ThemeContextType } from '../context';

/**
 * ProgressView is Function Component to render indicator modal
 * @property {bool} visible - show modal
 */

const ProgressView = () => {

    const { theme } = useContext(ThemeContext)

    return (
        <Modal visible={true} transparent={true} supportedOrientations={['portrait', 'landscape']}>
            <View style={styles(theme).container}>
                <View style={styles(theme).indecatorView}>
                    <ActivityIndicator
                        size='large'
                        animating={true}
                        color={theme.MAIN_THEME_COLOR} />
                </View>
            </View>
        </Modal>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        justifyContent: 'center',
        backgroundColor: 'rgba(0,0,0,0.4)',
    },
    indecatorView: {
        backgroundColor: theme._FFF,
        alignSelf: 'center',
        padding: 30,
        borderRadius: 10,
    }
});


export default ProgressView;

