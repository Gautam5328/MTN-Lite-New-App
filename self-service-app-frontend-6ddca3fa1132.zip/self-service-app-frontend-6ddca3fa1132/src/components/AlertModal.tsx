import React, { useState, useContext } from "react"
import { StyleProp, ViewStyle, View, Modal, Dimensions, TouchableOpacity, Image, StyleSheet } from "react-native";//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { getScaleSize } from "../constant";
import { FONTS } from "../assets";

//COMPONENTS
import { Button, Icons, Text } from "../components";

interface AlertModalProps {
    style?: StyleProp<ViewStyle> | undefined,
    isVisible: boolean,
    imageType?: string | 'SUCCESS' | 'FAIL' | 'WARNING' | 'INFO',
    title?: string | '',
    description?: string | '',
    actions?: any | [],
    onPress?: (e: any, index: number) => void
    onClose: () => void
}

const AlertModal = (props: AlertModalProps) => {
    const { theme } = useContext(ThemeContext)

    function getImage() {
        if (props.imageType == 'SUCCESS') {
            return (
                <View>
                    <Icons
                        name={'check-circle'}
                        color={theme._14A44D}
                        type={'MaterialIcons'}
                        size={40} />
                </View>
            )
        } else if (props.imageType == 'FAIL') {
            return (
                <View>
                    <Icons
                        name={'close'}
                        color={theme.MAIN_THEME_COLOR}
                        type={'Fontisto'}
                        size={40} />
                </View>
            )
        } else if (props.imageType == 'WARNING') {
            return (
                <View>
                    <Icons
                        name={'warning'}
                        color={theme._E4A11B}
                        type={'MaterialIcons'}
                        size={40} />
                </View>
            )
        } else if (props.imageType == 'INFO') {
            return (
                <View>
                    <Icons
                        name={'info'}
                        color={theme._54B4D3}
                        type={'MaterialIcons'}
                        size={40} />
                </View>
            )
        }

    }

    return (
        <Modal
            animationType="fade"
            transparent={true}
            visible={props.isVisible}
            onRequestClose={props.onClose}
        >
            <View style={styles(theme).alertCardContainer}>
                <View style={styles(theme).alertcard}>
                    <TouchableOpacity style={styles(theme).closeIcon} onPress={props.onClose}
                    >
                        <Icons
                            name={'close'}
                            color={theme._AFAFAF}
                            type={'MaterialIcons'}
                            size={20} />
                    </TouchableOpacity>
                    {getImage()}
                    <View style={styles(theme).textContainer}>
                        <Text style={styles(theme).alertSuccess}
                            font={FONTS.Roboto.Bold}
                            color={theme._333333}
                            size={getScaleSize(15)}>{props.title}</Text>
                        <Text
                            style={{ textAlign: 'center' }}
                            font={FONTS.Roboto.Regular}
                            color={theme._AFAFAF}
                            size={getScaleSize(13)}>{props.description}</Text>
                        <View style={styles(theme).buttonContainer}>

                            {props.actions.map((e: any, index: number) => {
                                return (
                                    <Button
                                        style={[styles(theme).btnOk, { backgroundColor: e.color }]}
                                        title={e.title}
                                        onPress={() => { props.onPress && props.onPress(e, index) }}
                                    />
                                )
                            })}
                        </View>

                    </View>
                </View>
            </View>
        </Modal>
    )

}
export default AlertModal

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    alertCardContainer: {
        flex: 1, alignItems: "center",
        justifyContent: "center", backgroundColor: 'rgba(52, 52, 52, 0.9)'
    },
    alertcard: {
        backgroundColor: "#fff",
        borderRadius: getScaleSize(10),
        paddingTop: getScaleSize(20),
        paddingBottom: getScaleSize(10),
        width: Dimensions.get('window').width - getScaleSize(60),
        alignItems: "center",
        justifyContent: "center",
        alignContent: "center",
        paddingHorizontal: getScaleSize(15),
        position: 'relative'
    },
    closeIcon: {
        position: 'absolute',
        top: getScaleSize(8), right:getScaleSize(8)
    },
    alertSuccess: {
        marginTop: getScaleSize(16),
        textAlign: "center",
        textAlignVertical: "center"
    },
    textContainer: { marginBottom: getScaleSize(10), alignItems: 'center' },
    buttonContainer: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center' },
    btnOk: {
        width: Dimensions.get('window').width / 2.9,
        marginTop: getScaleSize(15),
        // marginBottom: getScaleSize(10),
        paddingHorizontal: getScaleSize(20),
        marginHorizontal: getScaleSize(5)
    },
})