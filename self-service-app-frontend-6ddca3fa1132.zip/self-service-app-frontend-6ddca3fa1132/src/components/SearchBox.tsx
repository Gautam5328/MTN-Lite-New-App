import React, { useContext } from "react";
import { StyleSheet, View, Image, ViewStyle, StyleProp, TextInput } from 'react-native'

//CONSTANT & ASSETS
import { getScaleSize } from "../constant";
import { FONTS, IMAGES } from "../assets";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

interface SearchBoxProps {
    style?: StyleProp<ViewStyle> | undefined,
    onChangeText?: ((text: string) => void) | undefined,
    placeholder: string | undefined
}

function SearchBox(props: SearchBoxProps) {

    const { theme } = useContext(ThemeContext)

    return (
        <View style={[styles(theme).container, props.style]}>
            <Image style={styles(theme).searchIcon} source={IMAGES.search} />
            <TextInput style={styles(theme).input}
                placeholder={props.placeholder}
                onChangeText={props.onChangeText} />
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        backgroundColor: theme._F7F7F7,
        height: getScaleSize(40),
        borderRadius: getScaleSize(20),
        paddingHorizontal: getScaleSize(12),
        flexDirection: 'row',
        alignItems: 'center'
    },
    searchIcon: {
        height: getScaleSize(20),
        width: getScaleSize(20),
        marginRight: getScaleSize(12),
    },
    input: {
        flex: 1.0,
        fontSize: getScaleSize(14),
        fontFamily: FONTS.Roboto.Medium
    }
})

export default SearchBox