import React, { useContext } from "react";
import { Image, StyleProp, StyleSheet, TouchableOpacity, View, ViewStyle, ActivityIndicator } from 'react-native'

//ASSETS & CONSTANTS
import { FONTS, IMAGES } from "../assets";
import { STRINGS, formatToDecimalNumber, getScaleSize } from "../constant";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//COMPONENTS
import Text from "./Text";
import Button from "./Button";
import Icons from "./Icons";
import moment from "moment";

interface HomeCardProps {
    style?: StyleProp<ViewStyle>
    item?: any
    onPayBill?: () => void,
    onRecharge?: () => void,
    onBuyFiberPlan?: () => void,
    onRefresh?: () => void,
    isLoading?: boolean
}

function HomeFiberCard(props: HomeCardProps) {

    const { theme } = useContext(ThemeContext)

    const item = props?.item

    if (props?.isLoading) {
        return (
            <View style={[styles(theme).container, props.style]}>
                <View style={[styles(theme).cardHeader]}>
                    <Icons
                        name={'mobile'}
                        color={theme.TEXT_COLOR_AS_THEME}
                        type={'Fontisto'}
                        size={20} />
                    <Text
                        font={FONTS.Roboto.Regular}
                        color={theme.SUB_TEXT_COLOR_AS_THEME}
                        size={getScaleSize(12)}>
                        {item?.billing_type ?? '-'}
                    </Text>
                    <Text
                        font={FONTS.Roboto.Regular}
                        color={theme.SUB_TEXT_COLOR_AS_THEME}
                        size={getScaleSize(12)}>
                        {item?.msisdn ?? '-'}
                    </Text>
                    <TouchableOpacity style={styles(theme).refreshIconContainer}
                        onPress={props?.onRefresh}>
                        <Image style={styles(theme).refreshIcon} source={IMAGES.refresh} />
                    </TouchableOpacity>
                </View>
                <View style={styles(theme).cardDetails}>

                    <View style={styles(theme).cardDetailsItem}>
                        <ActivityIndicator color={theme.TEXT_COLOR_AS_THEME} />
                        <Text
                            style={{ marginTop: getScaleSize(2) }}
                            font={FONTS.Roboto.Regular}
                            color={theme.SUB_TEXT_COLOR_AS_THEME}
                            size={getScaleSize(10)}>
                            {STRINGS.airtime_balance}
                        </Text>
                    </View>
                    <View style={styles(theme).cardDetailsSeperator}></View>
                    <View style={styles(theme).cardDetailsItem}>
                        <ActivityIndicator color={theme.TEXT_COLOR_AS_THEME} />
                        <Text
                            style={{ marginTop: getScaleSize(2) }}
                            font={FONTS.Roboto.Regular}
                            color={theme.SUB_TEXT_COLOR_AS_THEME}
                            size={getScaleSize(10)}>
                            {STRINGS.data_balance}
                        </Text>
                    </View>
                </View>
                <View style={styles(theme).cardFotter}>
                    <TouchableOpacity style={styles(theme).btnRechargeContainer}>
                        <Text
                            font={FONTS.Roboto.Regular}
                            color={theme._333333}
                            size={getScaleSize(11)}>
                            <ActivityIndicator color={theme._333333} />
                        </Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles(theme).btnRechargeContainer} >
                        <Text
                            font={FONTS.Roboto.Regular}
                            color={theme._333333}
                            size={getScaleSize(11)}>
                            <ActivityIndicator color={theme._333333} />
                        </Text>
                    </TouchableOpacity>
                </View>
            </View>
        )
    }
    else {
        return (
            <View style={[styles(theme).container, props.style]}>
                <View style={[styles(theme).cardHeader]}>
                    <Text
                        font={FONTS.Roboto.Regular}
                        color={theme.SUB_TEXT_COLOR_AS_THEME}
                        size={getScaleSize(12)}>
                        {STRINGS.fiber}
                    </Text>
                    <Text
                        font={FONTS.Roboto.Regular}
                        color={theme.SUB_TEXT_COLOR_AS_THEME}
                        size={getScaleSize(12)}>
                        {item?.fiber_id ?? ''}
                    </Text>
                    <TouchableOpacity style={styles(theme).refreshIconContainer}
                        onPress={props?.onRefresh}>
                        <Image style={styles(theme).refreshIcon} source={IMAGES.refresh} />
                    </TouchableOpacity>
                </View>
                <View style={styles(theme).cardDetailsItem}>
                    <Text
                        style={{ marginTop: getScaleSize(2) }}
                        font={FONTS.Roboto.Regular}
                        color={theme.SUB_TEXT_COLOR_AS_THEME}
                        size={getScaleSize(12)}>
                        {STRINGS.data_speed}
                    </Text>
                    <Text
                        font={FONTS.Roboto.Medium}
                        color={theme.TEXT_COLOR_AS_THEME}
                        size={getScaleSize(16)}>
                        {item?.fiber_name ?? ''}
                    </Text>
                    {/* <Text
                        font={FONTS.Roboto.Medium}
                        color={theme.SUB_TEXT_COLOR_AS_THEME}
                        size={getScaleSize(12)}>
                        {item?.fiber_id ?? ''}
                    </Text> */}
                    <View style={styles(theme).dataPlane}>
                        <Text
                            style={{ flex: 1.0 }}
                            font={FONTS.Roboto.Medium}
                            color={theme.SUB_TEXT_COLOR_AS_THEME}
                            size={getScaleSize(10)}>
                            {STRINGS.currency + `${formatToDecimalNumber(item?.price)}`}
                        </Text>
                        <Text
                            font={FONTS.Roboto.Regular}
                            color={theme.SUB_TEXT_COLOR_AS_THEME}
                            size={getScaleSize(10)}>
                            {
                                ((moment.duration(item?.validity, 'minutes')).days() < 1) ?
                                    'Renews in ' + (moment.duration(item?.validity, 'minutes')).hours() + ' hours'
                                    :
                                    'Renews in ' + (moment.duration(item?.validity, 'minutes')).days() + ' days'
                            }
                        </Text>
                    </View>

                </View>
                <View style={styles(theme).cardFotter}>
                    <TouchableOpacity style={styles(theme).btnRechargeContainer} onPress={props.onRecharge}>
                        <Text
                            font={FONTS.Roboto.Medium}
                            color={theme._333333}
                            size={getScaleSize(14)}>
                            {STRINGS.upgrade}
                        </Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles(theme).btnRechargeContainer} onPress={props.onBuyFiberPlan}>
                        <Text
                            font={FONTS.Roboto.Medium}
                            color={theme._333333}
                            size={getScaleSize(14)}>
                            {STRINGS.browse_plans}
                        </Text>
                    </TouchableOpacity>
                </View>
            </View>
        )
    }

}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        backgroundColor: theme.MAIN_THEME_COLOR,
        borderRadius: getScaleSize(20),
        padding: getScaleSize(5),
        overflow: 'hidden'
    },
    cardHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: getScaleSize(12),
        alignItems: 'center',
        borderBottomWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.5)'
    },
    refreshIconContainer: {
        height: getScaleSize(40),
        width: getScaleSize(40),
        justifyContent: 'center',
        alignItems: 'center'
    },
    refreshIcon: {
        height: getScaleSize(20),
        width: getScaleSize(20),
        tintColor: theme.SUB_TEXT_COLOR_AS_THEME
    },
    cardDetails: {
        flexDirection: 'row',
        marginVertical: getScaleSize(15)
    },
    cardDetailsItem: {
        flex: 1.0,
        // justifyContent: 'center',
        alignItems: 'flex-start',
        marginHorizontal: getScaleSize(12),
        marginTop: getScaleSize(10),
        marginBottom: getScaleSize(10)
    },
    cardDetailsSeperator: {
        // flex: 1.0,
        backgroundColor: 'rgba(255, 255, 255, 0.5)',
        width: getScaleSize(1)
    },
    cardFotter: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: getScaleSize(12),
        // alignItems: 'center',
        marginBottom: getScaleSize(10)
    },
    btnRechargeContainer: {
        paddingHorizontal: getScaleSize(10),
        paddingVertical: getScaleSize(5),
        backgroundColor: theme._FFF,
        borderRadius: getScaleSize(15),
        width: '45%',
        alignItems: 'center',
    },
    emptyContainer: {
        height: getScaleSize(150),
        marginHorizontal: getScaleSize(13),
        backgroundColor: theme.MAIN_THEME_COLOR,
        borderRadius: getScaleSize(20),
        justifyContent: 'center'
    },
    dataPlane: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginTop: getScaleSize(8)
    },
})
export default HomeFiberCard