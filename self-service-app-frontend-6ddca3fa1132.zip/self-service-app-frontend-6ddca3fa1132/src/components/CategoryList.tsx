import React from 'react';
import { View, FlatList, TouchableOpacity, Image, StyleSheet } from 'react-native';

//Assets
import { FONTS } from '../assets';

//Constants
import { getScaleSize } from '../constant';

//Components
import Text from './Text';

const CategoryList = ({ theme, category, handlePress, additionalStyles }: any) => (
    <View>
        <Text font={FONTS.Roboto.Bold} color={theme._000} size={getScaleSize(20)}>
            {category.title}
        </Text>
        <FlatList
            data={category.data}
            horizontal
            showsHorizontalScrollIndicator={false}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => {
                const styles = getStyles(theme, additionalStyles); // Get the styles dynamically
                return (
                    <TouchableOpacity
                        style={[
                            styles.languageIconContainer,
                            additionalStyles?.languageIconContainer, // Check if additionalStyles is defined
                        ]}
                        onPress={() => handlePress(item)}
                    >
                        <View style={styles.iconContainer}>
                            <Image source={{ uri: `data:image/png;base64,${item.icon}` }} style={[styles.languageIcon, additionalStyles?.languageIcon]} />
                        </View>
                        <Text font={FONTS.Roboto.Regular} color={theme._000} size={getScaleSize(13)}>
                            {item.name}
                        </Text>
                    </TouchableOpacity>
                );
            }}
        />
    </View>
);

const getStyles = (theme: any, additionalStyles: any) => {
    return StyleSheet.create({
        languageIconContainer: {
            alignItems: 'center',
            marginRight: getScaleSize(15),
            marginTop: getScaleSize(20),
            marginBottom: getScaleSize(20),
        },
        iconContainer: {},
        languageIcon: {
            resizeMode: 'contain',
            width: getScaleSize(100),
            height: getScaleSize(120),
            borderRadius: getScaleSize(5),
            borderWidth: getScaleSize(1),
            borderColor: theme._E8E8E8,
        },
    });
};

export default CategoryList;
