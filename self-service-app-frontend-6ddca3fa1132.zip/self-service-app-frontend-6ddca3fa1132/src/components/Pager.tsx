import React, { useContext } from "react";
import { StyleSheet, View } from 'react-native'

//CONTEXT
import { ThemeContextType, ThemeContext } from "../context";

//CONSTANTS
import { getScaleSize } from "../constant";

interface PagerProps {
    totalPages: number,
    currentPage: number,
}

function Pager(props: PagerProps) {

    const {theme} = useContext(ThemeContext)

    const totalItems = Array.from(Array(props.totalPages).keys())
    return (
        <View style={styles(theme).pageContainer}>
            {totalItems.map((e: number, index: number) => {
                const selected = props.currentPage == index ? styles(theme).pageSelected : styles(theme).pageDeselected
                return (
                    <View key={index} style={[styles(theme).pageItem, selected]}/>
                )
            })}
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    pageContainer: {
        flexDirection: 'row'
    },
    pageItem: {
        height: getScaleSize(8),
        width: getScaleSize(8),
        borderRadius: getScaleSize(4),
        marginHorizontal: getScaleSize(4)
    },
    pageSelected: {
        backgroundColor: theme.MAIN_THEME_COLOR 
    },
    pageDeselected: {
        backgroundColor: theme._D3D3D3 
    }
})

export default Pager