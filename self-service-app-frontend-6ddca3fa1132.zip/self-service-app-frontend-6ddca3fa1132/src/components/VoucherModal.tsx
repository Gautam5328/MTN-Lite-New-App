import React, { useState, useContext } from "react"
import { StyleProp, ViewStyle, View, Modal, Dimensions, TouchableOpacity, Image, StyleSheet, FlatList, TextInput } from "react-native";//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { PaymentOptions, STRINGS, getScaleSize } from "../constant";
import { FONTS } from "../assets";

//COMPONENTS
import { Button, Icons, Text } from ".";

const VoucherModal = (props: any) => {
    const { theme } = useContext(ThemeContext)

    const [voucherNumber, setVoucherNumber] = useState<any>('')

    return (
        <Modal
            animationType="fade"
            transparent={true}
            visible={props.visible}
            onRequestClose={props.onClose}
        >
            <View style={styles(theme).optionCardContainer}>
                <View style={styles(theme).optioncard}>
                    <TouchableOpacity style={styles(theme).closeIcon} onPress={props.onClose}
                    >
                        <Icons
                            name={'close'}
                            color={theme._AFAFAF}
                            type={'MaterialIcons'}
                            size={20} />
                    </TouchableOpacity>

                    <Text
                        style={styles(theme).titleText}
                        font={FONTS.Roboto.Medium}
                        color={theme._333333}
                        size={getScaleSize(18)}>
                        {STRINGS.enter_voucher}
                    </Text>
                    <View style={[styles(theme).inputContainer, {
                        marginTop: getScaleSize(10),
                    }]}>
                        <TextInput
                            keyboardType="number-pad"
                            value={voucherNumber}
                            onChangeText={(value: any) => { setVoucherNumber((value)) }}
                            style={styles(theme).numberInput}
                            placeholder={STRINGS.enter_voucher}
                            placeholderTextColor={theme._333333} />

                    </View>
                    {props.errorMessage &&
                        <Text
                            style={styles(theme).errorText}
                            font={FONTS.Roboto.Regular}
                            color={'red'}
                            size={getScaleSize(10)}>
                            {'Enter voucher number'}
                        </Text>
                    }
                    <Button
                        style={[styles(theme).btnContinue]}
                        title={STRINGS.continue}
                        onPress={() => { props.onPress && props.onPress(voucherNumber) }}
                    />
                </View>
            </View>

        </Modal>
    )

}
export default VoucherModal

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({

    optionCardContainer: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center", backgroundColor: 'rgba(52, 52, 52, 0.9)'
    },
    optioncard: {
        backgroundColor: "#fff",
        borderRadius: getScaleSize(10),
        paddingTop: getScaleSize(20),
        paddingBottom: getScaleSize(20),
        width: Dimensions.get('window').width - getScaleSize(60),
        alignItems: "center",
        justifyContent: "center",
        alignContent: "center",
        paddingHorizontal: getScaleSize(15),
        position: 'relative'
    },
    closeIcon: {
        position: 'absolute',
        top: getScaleSize(8), right:getScaleSize(8)
    },
    iconContainer: { marginRight: getScaleSize(15), marginTop: getScaleSize(4) },
    optionCOntainer: { flexDirection: 'row', margin: getScaleSize(10) },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: getScaleSize(20),
        borderWidth: 1,
        borderColor: theme._D3D3D3,
        marginHorizontal: getScaleSize(24),
        paddingHorizontal: getScaleSize(10),
    },
    numberInput: {
        flex: 1.0,
        height: getScaleSize(40),
        color: theme._000
    },
    btnContinue: {
        width: Dimensions.get('window').width / 2.9,
        marginTop: getScaleSize(15),
        // marginBottom: getScaleSize(10),
        paddingHorizontal: getScaleSize(20),
        marginHorizontal: getScaleSize(5),
        backgroundColor: theme.MAIN_THEME_COLOR
    },
    titleText: {
        marginHorizontal: getScaleSize(24)
    },
    errorText: {
        marginHorizontal: getScaleSize(24),
    },
})