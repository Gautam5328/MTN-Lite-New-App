import React, { useContext } from 'react'
import { StyleSheet, View ,TouchableOpacity,ViewStyle,StyleProp} from 'react-native'

//COMPONENTS
import Text from './Text'

//ASSETS
import { FONTS } from '../assets'

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//CONSTANT
import { getScaleSize } from "../constant";
import Icons from './Icons';

interface CustomItemProps {
    style?: StyleProp<ViewStyle> | undefined
    title?: string | '',
    iconName: string,
    iconType: "FontAwesome" | "Feather" | "Foundation" | "MaterialIcons" | "Fontisto",
    leftIcon?: string,
    onPress?: () => void,
}
export default function CustomItem(props:CustomItemProps) {

    const { theme } = useContext(ThemeContext)
    return(
        <TouchableOpacity onPress={props.onPress}>
            <View style={{ flexDirection: 'row' }}>
            <View style={{ flexDirection: 'row',flex:1 }}>
                <Icons
                    name={props.iconName}
                    color={theme._333333}
                    type={props.iconType}
                    size={20} />
                <Text
                    style={{ marginLeft: getScaleSize(20) }}
                    font={FONTS.Roboto.Medium}
                    color={theme._333333}
                    size={getScaleSize(16)}>
                    {props.title}
                </Text>
                </View>
                <View style={{alignItems:'flex-end'}}>
                <Icons
                    name={'angle-right'}
                    color={theme._333333}
                    type={'FontAwesome'}
                    size={20} />
                </View>
            </View>
        </TouchableOpacity>
    )
}
