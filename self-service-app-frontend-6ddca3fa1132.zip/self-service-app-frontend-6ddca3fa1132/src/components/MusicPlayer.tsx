import React, { useContext, useEffect, useState } from 'react';
import { ActivityIndicator, Image, StyleSheet, TouchableOpacity, View } from 'react-native'

//API
import { API } from '../api';

//CONSTANT & ASSETS
import { showMessageToast } from '../constant';
import { FONTS } from '../assets';

//CONTEXT
import { ThemeContext, ThemeContextType } from '../context';
import Text from './Text';
import Icons from './Icons';

//PACKAGES
import TrackPlayer, { Capability, Event, State, useTrackPlayerEvents } from 'react-native-track-player';

const MusicPlayer = () => {

    const { theme } = useContext(ThemeContext)

    const [isLoading, setLoading] = useState(false)
    const [audioDetails, setAudioDetails] = useState(null);
    const [playerStatus, setPlayerStatus] = useState<State>(State.None)

    useTrackPlayerEvents([Event.PlaybackState], async event => {
        setPlayerStatus(event.state)
    });

    useEffect(() => {

        TrackPlayer.addEventListener(Event.RemotePlay, () => TrackPlayer.play());

        TrackPlayer.addEventListener(Event.RemotePause, () => TrackPlayer.pause());

        TrackPlayer.addEventListener(Event.RemoteStop, () => resetTrackPlayer());

        return () => {
            
        }
    }, [])

    useEffect(() => {
        if (audioDetails) {
            getTrackDetails()
        }
        else {

        }
    }, [audioDetails])

    async function getTrackDetails() {
        try {
            setLoading(true)
            const result = await API.transactionInstance.get(`/play/presignedurl/${audioDetails?.music_id ?? ''}`);
            setLoading(false)

            if (result?.status === 200) {
                const url = result?.data?.url;
                setNewURL(url)
            }
        } catch (error: any) {
            showMessageToast(error?.message ?? '');
        }
    }

    MusicPlayer.stopPlayer = () => {
        resetTrackPlayer()
    }
    
    MusicPlayer.setAudio = (audio: any) => {
        setAudioDetails(audio);
    };

    async function setNewURL(url: string) {
        await TrackPlayer.reset();

        await TrackPlayer.updateOptions({
            android: {
                alwaysPauseOnInterruption: true
            },
            alwaysPauseOnInterruption: true,
            capabilities: [Capability.Play, Capability.Pause, Capability.Stop],
            compactCapabilities: [Capability.Play, Capability.Pause, Capability.Stop]
        })
        TrackPlayer.add([{
            url: url,
            title: (audioDetails?.name ?? '')
        }])

        TrackPlayer.play()
    }

    async function resetTrackPlayer() {
        setAudioDetails(null)
        setPlayerStatus(State.None)

        await TrackPlayer.reset();
    }

    if (audioDetails) {
        return (
            <View style={styles(theme).container}>
                <Image source={{ uri: `data:image/png;base64,${audioDetails?.icon ?? ''}` }} style={styles(theme).audioImage} />
                <Text
                    style={{ marginHorizontal: 8, flex: 1.0 }}
                    font={FONTS.Roboto.Regular}
                    color={theme.TEXT_COLOR_AS_THEME}
                    size={13}>
                    {audioDetails?.name}
                </Text>
                {(isLoading || playerStatus == State.Loading) ?
                    <ActivityIndicator color={theme.TEXT_COLOR_AS_THEME} />
                    :
                    <>
                        <TouchableOpacity
                            style={styles(theme).buttons}
                            onPress={() => {
                                if (playerStatus == State.Playing) {
                                    TrackPlayer.pause()
                                }
                                else {
                                    TrackPlayer.play()
                                }
                            }}>
                            <Icons
                                color={theme.TEXT_COLOR_AS_THEME}
                                name={playerStatus == State.Playing ? 'pause' : 'play'}
                                type='Feather'
                                size={27} />
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={styles(theme).buttons}
                            onPress={() => {
                                resetTrackPlayer()
                            }}>
                            <Icons
                                color={theme.TEXT_COLOR_AS_THEME}
                                name='stop'
                                type='Fontisto'
                                size={20} />
                        </TouchableOpacity>
                    </>
                }

            </View>
        );
    }
    else {
        return null
    }

};

export default MusicPlayer;

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        height: 60,
        flexDirection: 'row',
        backgroundColor: theme.MAIN_THEME_COLOR,
        paddingHorizontal: 20,
        alignItems: 'center',
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(0,0,0,0.1)'
    },
    audioImage: {
        width: 40,
        height: 40,
        borderRadius: 3,
    },
    buttons: {
        width: 40,
        height: 40,
        justifyContent: 'center',
        alignItems: 'center'
    }
})
