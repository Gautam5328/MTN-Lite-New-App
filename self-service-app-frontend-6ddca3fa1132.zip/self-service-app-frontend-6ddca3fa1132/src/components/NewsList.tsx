import React, { useContext, useEffect, useState } from 'react';
import { View, StyleProp, TextStyle, StyleSheet, ScrollView, FlatList, TouchableOpacity, Image, SafeAreaView, ActivityIndicator } from 'react-native';

//CONSTANT & ASSETS
import { FONTS } from '../assets'
import { getScaleSize, showMessageToast } from '../constant';

//CONTEXT
import { ThemeContext, ThemeContextType } from '../context';

//COMPONENTS
import { CategoryList, List, Text } from '../components';

//API
import { API } from '../api';

//Packages
import _ from 'lodash';
import { SCREENS } from '../screens';

function NewsList(props: any) {

    const { theme } = useContext(ThemeContext)

    const [loading, setLoading] = useState(false);
    const [newsList, setNewsList] = useState<any[]>([])

    useEffect(() => {
        getNewsList();
    }, [])

    async function getNewsList() {
        try {
            setLoading(true);
            const result = await API.transactionInstance.get('/play/news')
            setLoading(false)
            if (result.status == 200) {
                if (result?.data) {
                    const newsList = result?.data?.news_list ?? []
                    const array = newsList.map((e: any) => {
                        var output1 = Object.entries(e).map(([key, value]) => ({ title: key, data: value }));
                        return output1[0]
                    })
                    setNewsList(array)
                    setLoading(false)
                }
            } else {
                setNewsList([])
            }
        }
        catch (error: any) {
            setLoading(false)
            setNewsList([])
            showMessageToast(error?.message ?? '')
        }
    }
    // if (loading) {
    //     return (
    //         <View style={[styles(theme).emptyContainer]}>
    //             <ActivityIndicator color={theme.MAIN_THEME_COLOR} size='large' />
    //         </View>)
    // }
    // else {
    return (
        <ScrollView style={styles(theme).rootContainer} showsVerticalScrollIndicator={false}>
            <List isLoading={loading}>
                <View style={styles(theme).container}>
                    {newsList.map((category, index) => (
                        <CategoryList
                            key={index}
                            theme={theme}
                            category={category}
                            handlePress={(item: any) => props.navigation.navigate(SCREENS.NewsDetails.identifier, { url: item?.url })}
                            additionalStyles={{
                                languageIcon: { height: getScaleSize(100) },
                            }}
                        />
                    ))}
                </View>
                <SafeAreaView />
            </List>
        </ScrollView>
    )
}
// }


export default NewsList;

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({

    rootContainer: {
        backgroundColor: theme._FFF,
    },
    languageIconContainer: {
        alignItems: 'center',
        marginRight: getScaleSize(15),
        marginTop: getScaleSize(20),
        marginBottom: getScaleSize(20)
    },
    iconContainer: {
    },
    languageIcon: {
        resizeMode: 'contain',
        width: getScaleSize(100),
        height: getScaleSize(100),
        borderRadius: getScaleSize(5),
        borderWidth: getScaleSize(1),
        borderColor: theme._E8E8E8,
    },
    movContainer: { marginTop: getScaleSize(5), marginBottom: getScaleSize(5) },
    container: { padding: getScaleSize(16) },
    emptyContainer: {
        flex: 1.0,
        backgroundColor: theme._FFF,
        justifyContent: 'center'
    }
})
