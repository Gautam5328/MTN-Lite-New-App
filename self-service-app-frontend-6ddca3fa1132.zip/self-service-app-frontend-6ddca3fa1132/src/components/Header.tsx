import React, { useContext } from "react"
import { Image, Platform, SafeAreaView, StyleProp, StyleSheet, TouchableOpacity, View, ViewStyle } from "react-native"

//COMPONENTS
import Text from "./Text"

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context"

//CONSTANT & ASSETS
import { getScaleSize } from '../constant'
import { FONTS, IMAGES } from "../assets"
import Icons from "./Icons"
import { opratorLogo } from "../constant/utils"

interface HeaderProps {
    style?: StyleProp<ViewStyle> | undefined
    title?: string | '',
    isHome?: boolean
    isDisableShadow?: boolean,
    onBack?: () => void,
    onNotification?: () => void,
    onProfile?: () => void,
}

function Header(props: HeaderProps) {

    const { theme, operator } = useContext(ThemeContext)
    const shadowStyle = props.isDisableShadow ? {} : styles(theme).shadowContainer
    return (
        <View style={shadowStyle}>
            <SafeAreaView />
            <View style={[styles(theme).container, props.style]}>
                {props.onBack &&
                    <TouchableOpacity style={styles(theme).iconContainer}
                        onPress={props.onBack}>
                        <Icons
                            name={'angle-left'}
                            color={theme._828282}
                            type={'FontAwesome'}
                            size={getScaleSize(30)} />
                    </TouchableOpacity>
                }
                <View style={styles(theme).titleContainer}>
                    {props.isHome &&
                        <Image
                            style={[styles(theme).titleLogo, { height: opratorLogo(operator)?.height, width: opratorLogo(operator)?.width }]}
                            resizeMode="contain"
                            source={opratorLogo(operator)?.source} />
                    }
                    {props.title &&
                        <Text
                            font={FONTS.Roboto.Bold}
                            color={theme.HEADER_TEXT_COLOR}
                            size={getScaleSize(18)}>
                            {props.title}
                        </Text>
                    }
                </View>
                {props.onNotification &&
                    <TouchableOpacity style={styles(theme).iconContainer}
                        onPress={props.onBack}>
                        <Image style={styles(theme).icon}
                            source={IMAGES.notification} />
                    </TouchableOpacity>
                }
                {props.onProfile &&
                    <TouchableOpacity style={styles(theme).iconContainer}
                        onPress={props.onBack}>
                        <Image style={styles(theme).icon}
                            source={IMAGES.profile} />
                    </TouchableOpacity>
                }
            </View>
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    shadowContainer: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 1,
    },
    container: {
        height: Platform.OS == 'ios' ? getScaleSize(44) : getScaleSize(56),
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: theme._FFF,
        paddingHorizontal: getScaleSize(8),
    },
    titleContainer: {
        flex: 1.0,
        flexDirection: 'row',
    },
    iconContainer: {
        height: Platform.OS == 'ios' ? getScaleSize(44) : getScaleSize(56),
        width: Platform.OS == 'ios' ? getScaleSize(44) : getScaleSize(56),
        justifyContent: 'center',
        alignItems: 'center'
    },
    icon: {
        height: Platform.OS == 'ios' ? getScaleSize(22) : getScaleSize(27),
        width: Platform.OS == 'ios' ? getScaleSize(22) : getScaleSize(27),
    },
    titleLogo: {
        marginLeft: getScaleSize(10),

    }
})

export default Header