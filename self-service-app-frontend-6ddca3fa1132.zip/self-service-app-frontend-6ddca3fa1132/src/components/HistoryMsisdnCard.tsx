import React, { useContext } from "react";
import { StyleProp, ViewStyle, View, StyleSheet, Dimensions } from 'react-native'

//CONSTANT & ASSETS
import { formatRawMobileNumber, getScaleSize } from "../constant";
import { FONTS } from "../assets";

//COMPONENTS
import Text from "./Text";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

interface HistoryMsisdnCardProps {
    style?: StyleProp<ViewStyle>,
    customer_name?: string | '',
    selectedMsisdn?: string | '',
    msisdn?: string | '',
    onPress?: () => void,
}

function HistoryMsisdnCard(props: HistoryMsisdnCardProps) {

    const { theme } = useContext(ThemeContext)

    return (
        <View style={styles(theme).container}>
            <View style={[props.selectedMsisdn == props.msisdn ? styles(theme).shadowContainer : styles(theme).userImage]}>
                <Text
                    font={FONTS.Roboto.Bold}
                    color={props.selectedMsisdn == props.msisdn ? theme._333333 : theme._333333}
                    size={getScaleSize(16)}>
                    {props.customer_name}
                </Text>
            </View>
            <Text
                font={props.selectedMsisdn == props.msisdn ? FONTS.Roboto.Bold :FONTS.Roboto.Regular}
                color={props.selectedMsisdn == props.msisdn ? theme.TEXT_COLOR_AS_THEME :theme._FFF}
                size={getScaleSize(12)}>
                {props.msisdn}
            </Text>
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        alignItems: 'center',
        width: Dimensions.get('window').width / 3.5,
        paddingHorizontal: getScaleSize(10)
    },
    userImage: {
        backgroundColor: theme._F5F5F5,
        height: getScaleSize(40),
        width: getScaleSize(40),
        borderRadius: getScaleSize(20),
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: getScaleSize(5),
        borderColor:theme.MAIN_THEME_COLOR, borderWidth:1
    },
    shadowContainer: {

        backgroundColor: theme._D3D3D3,
        height: getScaleSize(40),
        width: getScaleSize(40),
        borderRadius: getScaleSize(20),
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: getScaleSize(5),

        shadowColor: theme._FFF,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.5,
        shadowRadius: 20,
        elevation: 3,
    },
})

export default HistoryMsisdnCard