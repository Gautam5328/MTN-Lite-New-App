import React, { useContext } from "react";
import { StyleProp, ViewStyle, View, StyleSheet, Image } from 'react-native'

//CONSTANT & ASSETS
import { getScaleSize } from "../constant";
import { FONTS, IMAGES } from "../assets";

//COMPONENTS
import Text from "./Text";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";


interface WatherCardProps {
    style?: StyleProp<ViewStyle>
}

function WatherCard(props: WatherCardProps) {

    const { theme } = useContext(ThemeContext)

    return (
        <View style={[styles(theme).container, props.style]}>
            <View style={styles(theme).header}>
                <View style={styles(theme).tempTextContainer}>
                    <Text
                        font={FONTS.Roboto.Medium}
                        color={theme.TEXT_COLOR_AS_THEME}
                        size={getScaleSize(30)}>
                        {'24°C'}
                    </Text>
                    <Image style={styles(theme).tempIcon} source={IMAGES.up_arrow} />
                </View>
                <View style={styles(theme).tempIconContainer}>
                    <Image style={styles(theme).tempIcon} source={IMAGES.temperature} />
                </View>
            </View>
            <View style={styles(theme).fotter}>
                <View style={styles(theme).cardDetailsItem}>
                    <Text
                        font={FONTS.Roboto.Medium}
                        color={theme.TEXT_COLOR_AS_THEME}
                        size={getScaleSize(16)}>
                        {'24°C'}
                    </Text>
                    <Text
                        style={{ marginTop: getScaleSize(3) }}
                        font={FONTS.Roboto.Regular}
                        color={theme.SUB_TEXT_COLOR_AS_THEME}
                        size={getScaleSize(11)}>
                        {'Outside'}
                    </Text>
                </View>
                <View style={styles(theme).cardDetailsItem}>
                    <Text
                        font={FONTS.Roboto.Medium}
                        color={theme.TEXT_COLOR_AS_THEME}
                        size={getScaleSize(16)}>
                        {'48.5%'}
                    </Text>
                    <Text
                        style={{ marginTop: getScaleSize(3) }}
                        font={FONTS.Roboto.Regular}
                        color={theme.SUB_TEXT_COLOR_AS_THEME}
                        size={getScaleSize(11)}>
                        {'Home Humidity'}
                    </Text>
                </View>
                <View style={styles(theme).cardDetailsItem}>
                    <Text
                        font={FONTS.Roboto.Medium}
                        color={theme.TEXT_COLOR_AS_THEME}
                        size={getScaleSize(16)}>
                        {'Excellent'}
                    </Text>
                    <Text
                        style={{ marginTop: getScaleSize(3) }}
                        font={FONTS.Roboto.Regular}
                        color={theme.SUB_TEXT_COLOR_AS_THEME}
                        size={getScaleSize(11)}>
                        {'Air Quality'}
                    </Text>
                </View>

            </View>
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        backgroundColor: theme.MAIN_THEME_COLOR,
        borderRadius: getScaleSize(20),
        overflow: 'hidden'
    },
    header: {
        marginHorizontal: getScaleSize(20),
        height: getScaleSize(70),
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderBottomColor: 'rgba(255,255,255,0.5)',
        borderBottomWidth: 1,
        borderStyle: 'solid',
    },
    tempIconContainer: {
        height: getScaleSize(40),
        width: getScaleSize(40),
        backgroundColor: 'rgba(255,255,255,0.5)',
        borderRadius: getScaleSize(20),
        justifyContent: 'center',
        alignItems: 'center'
    },
    tempTextContainer: {
        flexDirection: 'row',
        alignItems: 'center'
    },
    tempIcon: {
        height: getScaleSize(20),
        width: getScaleSize(20),
        tintColor: theme.ICON_COLOR_AS_THEME
    },
    fotter: {
        marginHorizontal: getScaleSize(20),
        height: getScaleSize(80),
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between'
    },
    cardDetailsItem: {

    },
})

export default WatherCard