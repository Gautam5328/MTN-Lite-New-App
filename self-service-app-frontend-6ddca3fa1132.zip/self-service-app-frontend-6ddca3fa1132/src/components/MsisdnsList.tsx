import React, { useContext, useEffect, useRef, useState } from 'react';
import { View, FlatList, Dimensions, StyleSheet, ActivityIndicator, TouchableOpacity, StyleProp, SafeAreaView } from 'react-native';

//Context
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { formatRawMobileNumber, getScaleSize } from "../constant";

//Components
import { HistoryMsisdnCard, ProgressView,  } from '../components';
import { TextStyle } from 'react-native';
import { useSelector } from 'react-redux';

const initialLayout = { width: Dimensions.get('window').width };

interface MsisdnsProps {
    style?: StyleProp<TextStyle> | undefined,
    msisdn?: string,
    msisdnList?: [] | any
    onPress?: (e: any) => void
}

function MsisdnsList(props: MsisdnsProps) {

    const { theme } = useContext(ThemeContext);

    const [msisdnList, setMsisdnList] = useState<any[]>(props.msisdnList)
    const [mobileNumber, setMobileNumber] = useState<any>(props.msisdn)

    useEffect(() => {
    }, [mobileNumber])


    const onMsisdnSelect = async (item: any) => {
        setMobileNumber(item)

    }

    return (

        <View style={styles(theme).msisdnContainer}>
            <FlatList
                data={msisdnList}
                horizontal={true}
                showsHorizontalScrollIndicator={false}
                scrollEventThrottle={16}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item, index }) => {
                    if (item?.fiber_id) {
                    return (
                        <TouchableOpacity onPress={() => {
                            setMobileNumber(item)
                            props.onPress && props.onPress(item)
                        }}>
                            <HistoryMsisdnCard selectedMsisdn={mobileNumber?.fiber_id} msisdn={item?.fiber_id} customer_name={item?.customer_name?.charAt(0)} />
                        </TouchableOpacity>
                    )
                    } else {
                        return (
                            <TouchableOpacity onPress={() => {
                                setMobileNumber(item)
                                props.onPress && props.onPress(item)
                            }}>
                                <HistoryMsisdnCard selectedMsisdn={formatRawMobileNumber(mobileNumber?.msisdn)} msisdn={formatRawMobileNumber(item?.msisdn)} customer_name={item?.customer_name?.charAt(0)} />
                            </TouchableOpacity>
                        )
                    }
                }}
            />
        </View>
    );
};

export default MsisdnsList;

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    msisdnContainer: {
        flexDirection: 'row',
        marginVertical: getScaleSize(10),
        marginHorizontal: getScaleSize(20),
        backgroundColor: theme.MAIN_THEME_COLOR,
        paddingVertical: getScaleSize(20),
        borderRadius: getScaleSize(15),
    },
});