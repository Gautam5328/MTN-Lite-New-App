import React, { useContext } from "react";
import { Dimensions, StyleSheet, View, Image, StyleProp, ViewStyle, TouchableOpacity } from 'react-native'

//CONSTANT
import { getScaleSize } from "../constant";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS
import { FONTS, IMAGES } from "../assets";

//COMPONENTS
import Text from "./Text";
import Icons from "./Icons";


interface NumberBoxProps {
    style?: StyleProp<ViewStyle>
    msisdn?:string,
    item?: any,
    isDisable?: boolean | undefined,
    onPress?: () => void
}

function NumberBox(props: NumberBoxProps) {

    const { theme } = useContext(ThemeContext)
    return (
        <TouchableOpacity style={[styles(theme).container, props.style]}
            disabled={props.isDisable}
            onPress={props.onPress}>
            <View style={styles(theme).userImage}>
                <Text
                    font={FONTS.Roboto.Bold}
                    color={theme._333333}
                    size={getScaleSize(16)}>
                    {props?.item?.customer_name?.charAt(0)}
                </Text>
            </View>
            <View style={styles(theme).numberContainer}>
                <Text
                    font={FONTS.Roboto.Medium}
                    color={theme.TEXT_COLOR_AS_THEME}
                    size={getScaleSize(12)}>
                    {props?.item?.customer_name}
                </Text>
                <Text
                    style={{ marginTop: getScaleSize(3) }}
                    font={FONTS.Roboto.Medium}
                    color={theme.TEXT_COLOR_AS_THEME}
                    size={getScaleSize(12)}>
                    {props?.item?.msisdn}
                </Text>
            </View>
            {!props.isDisable &&
                <Icons
                    name="chevron-right"
                    type='Feather'
                    size={22}
                    color={theme.TEXT_COLOR_AS_THEME} />
            }
        </TouchableOpacity>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        padding: getScaleSize(8),
        backgroundColor: theme.MAIN_THEME_COLOR,
        borderRadius: getScaleSize(10),
        flexDirection: 'row',
        alignItems: 'center'
    },
    userImage: {
        backgroundColor: theme._F5F5F5,
        height: getScaleSize(40),
        width: getScaleSize(40),
        borderRadius: getScaleSize(20),
        justifyContent: 'center',
        alignItems: 'center'
    },
    numberContainer: {
        flex: 1.0,
        marginHorizontal: getScaleSize(12)
    }
})

export default NumberBox