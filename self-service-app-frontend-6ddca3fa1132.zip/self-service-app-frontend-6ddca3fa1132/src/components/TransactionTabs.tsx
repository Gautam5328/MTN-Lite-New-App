import React, { useContext, useEffect, useRef, useState } from 'react';
import { View, FlatList, Dimensions, StyleSheet, ActivityIndicator, TouchableOpacity, StyleProp, SafeAreaView } from 'react-native';

//Context
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { STRINGS, formatRawMobileNumber, getScaleSize } from "../constant";
import { FONTS, IMAGES } from "../assets";

//Constant
import { Storage, showMessageToast } from '../constant';

//API
import { API } from '../api';

//Components
import { HistoryCard, HistoryMsisdnCard, MsisdnsList, ProgressView, Text } from '../components';
import { TextStyle } from 'react-native';
import { useSelector } from 'react-redux';
import moment from 'moment';

const initialLayout = { width: Dimensions.get('window').width };
interface TransactionProps {
    style?: StyleProp<TextStyle> | undefined,
    msisdn?: string,
    msisdnList?: [] | null
}

function TransactionTabs(props: TransactionProps) {

    const { theme } = useContext(ThemeContext);

    const customerdetails = useSelector((state: any) => state.customerData);
    const msisdndetails = customerdetails?.customer?.msisdns?.[0];

    const menulistRef = useRef<FlatList>(null);

    const [loading, setLoading] = useState(false);
    const [selectedMenu, setSelectedMenu] = useState<number>(0)
    const [rechargeHistory, setRechargeHistory] = useState<any[]>([])
    const [bundleHistory, setBundleHistory] = useState<any[]>([])
    const [msisdnList, setMsisdnList] = useState<any[]>([...(customerdetails?.customer?.msisdns?? []), ...(customerdetails?.customer?.fiber_data?? [])])
    const [mobileNumber, setMobileNumber] = useState<any>(msisdndetails)

    useEffect(() => {
        if (selectedMenu == 0) {
            getRechargeHistoryData();
        }
        if (selectedMenu == 1) {
            getBundleHistoryData();
        }
    }, [mobileNumber])

    const getRechargeHistoryData = async () => {
        try {
            setLoading(true);
            const result = await API.transactionInstance.get('/customer/recharge/get-history/' + formatRawMobileNumber(mobileNumber?.msisdn))
            setLoading(false)
            if (result.status == 200) {
                if (result?.data) {
                    let sortedInput = (result?.data).slice().sort((a: any, b: any) => b.timestamp - a.timestamp);
                    setRechargeHistory(sortedInput);
                }
            } else {
                setRechargeHistory([])
            }
        }
        catch (error: any) {
            console.log("Taberror: ", error?.message?.message)
            setRechargeHistory([])
            setLoading(false)
            showMessageToast(error?.message?.message ?? error?.message ?? '')
        }
    }

    const getBundleHistoryData = async () => {
        try {
            setLoading(true);
            var value='';
            if (mobileNumber?.fiber_id) {
                value = mobileNumber?.fiber_id
            } else {
                value = formatRawMobileNumber(mobileNumber?.msisdn)
            }
            const result = await API.transactionInstance.get('/customer/bundle/get-history/' + value)
            setLoading(false)
            if (result.status == 200) {
                if (result?.data) {
                    let sortedInput = (result?.data).slice().sort((a: any, b: any) => b.timestamp - a.timestamp);
                    setBundleHistory(sortedInput);
                }
            } else {
                setBundleHistory([])
            }
        }
        catch (error: any) {
            setBundleHistory([]);
            setLoading(false)
            showMessageToast(error?.message ?? '')
        }
    }

    const onMsisdnSelect = async (item: any) => {
        setMobileNumber(item)
    }

    return (
        <View style={styles(theme).container}>

            {/* <View style={styles(theme).msisdnContainer}> */}
                {/* <FlatList
                    data={msisdnList}
                    horizontal={true}
                    showsHorizontalScrollIndicator={false}
                    scrollEventThrottle={16}
                    keyExtractor={(item, index) => index.toString()}
                    renderItem={({ item, index }) => {
                        return (
                            <TouchableOpacity onPress={() => { onMsisdnSelect(item) }}>
                                <HistoryMsisdnCard selectedMsisdn={mobileNumber.msisdn} msisdn={item?.msisdn} customer_name={item.customer_name.charAt(0)} />
                            </TouchableOpacity>
                        )
                    }}
                /> */}
                <MsisdnsList msisdn={mobileNumber} msisdnList={msisdnList} onPress={(item) => {
                    onMsisdnSelect(item)
                }} />
            {/* </View> */}
            <View style={styles(theme).deviceMenuContainer}>
                <FlatList
                    data={['Airtime', 'Bundle']}
                    horizontal={true}
                    ref={menulistRef}
                    ListHeaderComponent={() => <View style={{ width: getScaleSize(20) }} />}
                    ListFooterComponent={() => <View style={{ width: getScaleSize(20) }} />}
                    showsHorizontalScrollIndicator={false}
                    renderItem={({ item, index }) => {
                        return (
                            <TouchableOpacity style={[styles(theme).deviceMenuItem, { backgroundColor: selectedMenu == index ? theme.MAIN_THEME_COLOR : theme._FFF }]}
                                onPress={() => {
                                    setSelectedMenu(index)
                                    menulistRef?.current?.scrollToIndex({ index: index, viewPosition: 0.5 })
                                    if (index == 0) {
                                        getRechargeHistoryData();
                                    }
                                    if (index == 1) {
                                        getBundleHistoryData();
                                    }
                                }}>
                                <Text
                                    font={FONTS.Roboto.Medium}
                                    color={selectedMenu == index ? theme.TEXT_COLOR_AS_THEME : theme._AFAFAF}
                                    size={getScaleSize(16)}>
                                    {item}
                                </Text>
                            </TouchableOpacity>
                        )
                    }} />
            </View>
            <View style={styles(theme).listContainer}>
                {selectedMenu == 0 ?
                    <FlatList
                        data={rechargeHistory}
                        ListFooterComponent={() => {
                            return (
                                <View style={{ height: getScaleSize(170) }}></View>
                            )
                        }}
                        renderItem={({ item, index }) => {
                            return (
                                <HistoryCard
                                    timestamp={moment(item['timestamp'] * 1000).format('ddd MMM DD YYYY hh:mm:ss')}
                                    message={item?.message} amount={item?.amount} to_msisdn={item?.to_msisdn}
                                />
                            )
                        }} />
                    :
                    <FlatList
                        data={bundleHistory}
                        ListFooterComponent={() => {
                            return (
                                <View style={{ height: getScaleSize(170) }}></View>
                            )
                        }}
                        renderItem={({ item, index }) => {
                            return (
                                <HistoryCard
                                    timestamp={moment(item['timestamp'] * 1000).format('ddd MMM DD YYYY hh:mm:ss')}
                                    message={item?.message} amount={item?.amount} to_msisdn={item?.to_msisdn}
                                    />
                            )
                        }} />
                }

                <SafeAreaView />
            </View>
            {loading && <ProgressView />}
        </View>
    );
};

export default TransactionTabs;

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1
    },
    deviceMenuContainer: {
        paddingTop: getScaleSize(16),
        paddingBottom: getScaleSize(10),
    },
    deviceMenuItem: {
        paddingVertical: getScaleSize(5),
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: getScaleSize(20),
        borderColor: theme.MAIN_THEME_COLOR, 
        borderWidth: getScaleSize(1),
        paddingHorizontal: getScaleSize(10), 
        borderRadius: getScaleSize(10)
    },
    deviceMenuDevider: {
        height: getScaleSize(2),
        borderRadius: getScaleSize(2),
        marginTop: getScaleSize(2),
        width: '75%',
        backgroundColor: theme.MAIN_THEME_COLOR
    },
    listContainer: {
        paddingHorizontal: getScaleSize(20),
        // marginBottom:getScaleSize(100)
    },
});