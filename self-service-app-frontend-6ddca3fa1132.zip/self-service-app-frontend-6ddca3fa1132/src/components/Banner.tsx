import React, { useContext } from "react";
import { Dimensions, StyleSheet, View, Image } from 'react-native'

//CONSTANT
import { getScaleSize } from "../constant";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS
import { IMAGES } from "../assets";


interface BannerProps {
    item?: any
}

function Banner(props: BannerProps) {

    const item = props.item
    const { theme } = useContext(ThemeContext)

    return (
        <View style={styles(theme).main}>
            <Image
                style={styles(theme).container}
                resizeMode='cover'
                source={{ uri: `data:image/png;base64,${item?.icon}` }} />
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    main: {
        justifyContent: 'center',
        alignItems: 'center'
    },
    container: {
        backgroundColor: theme._AFAFAF,
        width: Dimensions.get('window').width - getScaleSize(40),
        height: (Dimensions.get('window').width - getScaleSize(40)) * 0.35,
        borderRadius: getScaleSize(10),
        overflow: 'hidden'
    }
})

export default Banner