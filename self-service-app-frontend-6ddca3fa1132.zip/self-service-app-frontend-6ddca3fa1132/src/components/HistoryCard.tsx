import React, { useContext } from "react";
import { StyleProp, ViewStyle, View, StyleSheet } from 'react-native'

//CONSTANT & ASSETS
import { STRINGS, getScaleSize, formatToDecimalNumber } from "../constant";
import { FONTS } from "../assets";

//COMPONENTS
import Text from "./Text";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";
import Icons from "./Icons";

interface HistoryCardProps {
    style?: StyleProp<ViewStyle>,
    message?: string | '',
    timestamp?: string | '',
    to_msisdn?: string | '',
    amount?: number | 0,
    onPress?: () => void,
}

function HistoryCard(props: HistoryCardProps) {

    const { theme } = useContext(ThemeContext)

    return (
        <View style={styles(theme).container}>
            <View style={styles(theme).amountContainer}>
                <View style={styles(theme).messageContainer}>
                    <Text style={styles(theme).textWrap}
                        font={FONTS.Roboto.Bold}
                        color={theme._333333}
                        size={getScaleSize(14)}>
                        {props.message + '  (' + props.to_msisdn + ') '}
                    </Text>
                </View>
                <Text
                    font={FONTS.Roboto.Bold}
                    color={theme.MAIN_THEME_COLOR}
                    size={getScaleSize(16)}>
                    {STRINGS.currency + formatToDecimalNumber(props.amount)}
                </Text>
            </View>
            <View style={styles(theme).dateContainer}>
                <Icons
                    name={'date'}
                    color={theme._54B4D3}
                    type={'Fontisto'}
                    size={15} />
                <Text style={{ marginLeft: getScaleSize(5) }}
                    font={FONTS.Roboto.Regular}
                    color={theme._333333}
                    size={getScaleSize(12)}>
                    {props.timestamp}
                </Text>
            </View>
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1,
        borderColor: theme._F5F5F5,
        borderWidth: getScaleSize(1),
        borderRadius: getScaleSize(10),
        padding: getScaleSize(15),
        marginVertical: getScaleSize(10),
        backgroundColor: theme._F7F7F7
    },
    amountContainer: { flexDirection: 'row', justifyContent: 'space-between' },
    dateContainer: { marginTop: getScaleSize(10), flexDirection: 'row' },
    messageContainer: { width: '75%', },
    textWrap: { flexWrap: 'wrap', }
})

export default HistoryCard