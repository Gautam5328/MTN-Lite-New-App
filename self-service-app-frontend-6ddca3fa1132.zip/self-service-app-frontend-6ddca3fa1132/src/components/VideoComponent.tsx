import React, { useState, useRef, useContext } from 'react';
import { SafeAreaView, StyleSheet, Text, View } from 'react-native';

//Context
import { ThemeContextType, ThemeContext } from '../context';

//Components
import { ProgressView } from '../components';

//Packages
import Video from 'react-native-video';
import MediaControls, { PLAYER_STATES } from 'react-native-media-controls';

const VideoComponent = ({ uri }: any) => {
    const { theme } = useContext(ThemeContext);
    const videoPlayer = useRef(null);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [isFullScreen, setIsFullScreen] = useState(false);
    const [loading, setLoading] = useState(true);
    const [paused, setPaused] = useState(false);
    const [playerState, setPlayerState] = useState(PLAYER_STATES.PLAYING);
    const [screenType, setScreenType] = useState('content');

    const onSeek = (seek: any) => {
        //Handler for change in seekbar
        videoPlayer.current.seek(seek);
    };

    const onPaused = (playerState: any) => {
        //Handler for Video Pause
        setPaused(!paused);
        setPlayerState(playerState);
    };

    const onReplay = () => {
        //Handler for Replay
        setPlayerState(PLAYER_STATES.PLAYING);
        videoPlayer.current.seek(0);
    };

    const onProgress = (data: any) => {
        // Video Player will progress continue even if it ends
        if (!loading && playerState !== PLAYER_STATES.ENDED) {
            setCurrentTime(data.currentTime);
        }
    };

    const onLoad = (data: any) => {
        setDuration(data.duration);
        setLoading(false);
    };

    const onLoadStart = (data) => setLoading(true);

    const onEnd = () => setPlayerState(PLAYER_STATES.ENDED);

    const onError = () => alert('Oh! ', error);

    const exitFullScreen = () => {
        alert('Exit full screen');
    };

    const enterFullScreen = () => { };

    const onFullScreen = () => {
        setIsFullScreen(isFullScreen);
        if (screenType == 'cover') setScreenType('content');
        else setScreenType('cover');
    };

    const renderToolbar = () => (
        <View>
            <Text style={styles(theme).toolbar}> toolbar </Text>
        </View>
    );

    const onSeeking = (currentTime: any) => setCurrentTime(currentTime);

    return (
        <View style={styles(theme).container}>
            {loading && <ProgressView />}
            <Video
                onEnd={onEnd}
                onLoad={onLoad}
                onLoadStart={onLoadStart}
                onProgress={onProgress}
                paused={paused}
                ref={videoPlayer}
                resizeMode={screenType === 'cover' ? 'cover' : 'contain'}
                onFullScreen={isFullScreen}
                source={{ uri: uri }}
                style={styles(theme).mediaPlayer}
                volume={10}
            />
            <MediaControls
                duration={duration}
                isLoading={loading}
                mainColor={theme._000}
                onFullScreen={onFullScreen}
                onPaused={onPaused}
                onReplay={onReplay}
                onSeek={onSeek}
                onSeeking={onSeeking}
                playerState={playerState}
                progress={currentTime}
                toolbar={renderToolbar()}
            />
        </View>
    );
};

export default VideoComponent;

const styles = (theme: ThemeContextType['theme']) =>
    StyleSheet.create({
        container: {
            flex: 1,
            backgroundColor: theme._000,
            justifyContent: 'center',
        },
        toolbar: {
            marginTop: 30,
            backgroundColor: theme._FFF,
            padding: 10,
            borderRadius: 5,
        },
        mediaPlayer: {
            position: 'absolute',
            top: 0,
            left: 0,
            bottom: 0,
            right: 0,
            justifyContent: 'center',
            alignItems: 'center', // Center the content horizontally
            backgroundColor: theme._000,
        },
        videoFullScreen: {
            ...StyleSheet.absoluteFillObject,
            justifyContent: 'center',

        },
    });
