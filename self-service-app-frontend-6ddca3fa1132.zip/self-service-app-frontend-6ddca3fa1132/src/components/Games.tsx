import React, { useContext, useEffect, useState } from "react";
import { ActivityIndicator, FlatList, SafeAreaView, StyleSheet, TouchableOpacity, View } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//PACKAGES
import WebView from "react-native-webview";

//COMPONENTS
import { Header, List } from "../components";

//CONSTANTS
import { getScaleSize, showMessageToast } from "../constant";
import { API } from "../api";

function Games(props: any) {

    const [loading, setLoading] = useState(false);
    const [webviewUrl, setWebviewUrl] = useState('');

    useEffect(() => {
        games();
    }, []);

    const games = async () => {
        try {
            setLoading(true);
            const result = await API.transactionInstance.get('/games/information')
            setLoading(false);
            if (result.status == 200) {
                const url = result.data.url;
                setWebviewUrl(url);

            }
        } catch (error: any) {
            setLoading(false);
            showMessageToast(error?.message ?? '')
        }
    };

    const { theme } = useContext(ThemeContext)
    // if (loading) {
    //     return (
    //         <View style={[styles(theme).emptyContainer]}>
    //             <ActivityIndicator color={theme.MAIN_THEME_COLOR} size='large' />
    //         </View>
    //     )
    // }
    // else {
    return (
        <View style={styles(theme).container}>
            <List isLoading={loading}>
                <WebView
                    source={{ uri: webviewUrl }}
                    style={styles(theme).webviewContainer}
                    onError={(error: any) => {
                    }} />
                <SafeAreaView />
            </List>
        </View>
    )
}
// }


const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF
    },
    webviewContainer: {
        flex: 1,
    },
    emptyContainer: {
        flex: 1.0,
        backgroundColor: theme._FFF,
        justifyContent: 'center'
    }
})

export default Games