import React, { useContext, useEffect } from "react";
import { Image, ImageSourcePropType, SafeAreaView, StyleSheet, TouchableOpacity, View } from 'react-native'

//CONSTANT & ASSETS
import { STRINGS, getScaleSize } from "../constant";
import { FONTS, IMAGES } from "../assets";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//COMPONENTS
import Text from "./Text";
import MusicPlayer from "./MusicPlayer";

function Tabbar(props: any) {

    const { theme } = useContext(ThemeContext)

    function onPress(name: string, index: number) {
        props.navigation.navigate(name);
    }

    const images = [IMAGES.ic_tab_home, IMAGES.ic_tab_smart_home, IMAGES.ic_tab_play, IMAGES.ic_tab_more]
    const titles = [STRINGS.home, STRINGS.smart_home, STRINGS.play, STRINGS.more]
    return (
        <View style={styles(theme).container}>
            <MusicPlayer/>
            <View style={styles(theme).tabContainer}>
                {props.state.routes.map((route: any, index: number) => {
                    return (
                        <TabItem
                            key={index}
                            onPress={() => onPress(route.name, index)}
                            title={titles[index]}
                            selected={props.state.index == index}
                            image={images[index]} />
                    )
                })}
            </View>
            <SafeAreaView />
        </View >
    )
}

interface TabItemProps {
    title: string | undefined,
    onPress: () => void,
    selected: boolean,
    image: ImageSourcePropType
}

function TabItem(props: TabItemProps) {

    const { theme } = useContext(ThemeContext)

    const opicity = props.selected ? 1.0 : 0.5
    return (
        <TouchableOpacity style={styles(theme).tabItem} onPress={props.onPress}>
            <Image style={[styles(theme).tabImage, { opacity: opicity }]} source={props.image} />
            <Text
                style={{ opacity: opicity, marginTop: getScaleSize(4) }}
                font={FONTS.Roboto.Regular}
                color={theme.TEXT_COLOR_AS_THEME}
                size={10}>
                {props.title}
            </Text>
        </TouchableOpacity>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        backgroundColor: theme.MAIN_THEME_COLOR
    },
    tabContainer: {
        height: 50,
        flexDirection: 'row'
    },
    tabItem: {
        flex: 1.0,
        justifyContent: 'center',
        alignItems: 'center'
    },
    tabImage: {
        height: 18,
        width: 18,
        tintColor: theme.ICON_COLOR_AS_THEME
    }
})

export default Tabbar