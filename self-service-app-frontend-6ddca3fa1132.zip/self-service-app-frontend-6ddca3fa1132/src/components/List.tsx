import React, { useContext } from "react";

import { View, StyleSheet, ActivityIndicator } from 'react-native'

//COMPONENTS
import Text from "./Text"

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context"

//CONSTANT & ASSETS
import { getScaleSize } from '../constant'
import { FONTS } from "../assets"

const List = (props: any) => {

    const { theme } = useContext(ThemeContext)

    if (props.isLoading) {
        return (
            <View style={styles(theme).container}>
                <View style={styles(theme).indicatorContainer}>
                    <ActivityIndicator color={theme._000} />
                </View>

            </View>
        )
    }
    if (props.isError) {
        return (
            <View style={styles(theme).errorContainer}>              
                <Text
                    style={{ flex: 1.0, textAlign: 'center' }}
                    align='center'
                    font={FONTS.Roboto.Medium}
                    color={theme._333333}
                    size={getScaleSize(16)}>
                    {props?.isError ?? ''}
                </Text>
            </View>
        )
    }

    return (
        <View style={styles(theme).container}>
            {props.children}
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0
    },
    indicatorContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        height: getScaleSize(100)
    },
    errorContainer: {
        flex: 1.0,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: getScaleSize(16),
        paddingVertical: getScaleSize(16)
    }
})

export default List