import { Alert, Linking, PermissionsAndroid, Platform } from 'react-native'

//Packages
import { selectContactPhone } from 'react-native-select-contact';

async function PhoneBook() {

    const openSettings = () => {
        Linking.openSettings();
    };

    if (Platform.OS === 'android') {
        const request = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.READ_CONTACTS,
        );
        if (request === PermissionsAndroid.RESULTS.DENIED || request === PermissionsAndroid.RESULTS.NEVER_ASK_AGAIN) {
            Alert.alert(
                'Permission Denied',
                'To enable this feature, please go to app settings and enable contacts permission.',
                [
                    { text: 'Cancel' },
                    { text: 'Open Settings', onPress: openSettings },
                ],
                { cancelable: false }
            );
            throw new Error("Permission Denied");
        }
    }
    // Here we are sure permission is granted for android or that platform is not android
    const selection = await selectContactPhone();
    if (!selection) {
        return null;
    }

    let { contact, selectedPhone } = selection;
    let jsonInfo = { 'customer_name': contact.name, 'msisdn': selectedPhone.number.replace(/[^\d]/g, "") }
    return jsonInfo;
}

export default PhoneBook









