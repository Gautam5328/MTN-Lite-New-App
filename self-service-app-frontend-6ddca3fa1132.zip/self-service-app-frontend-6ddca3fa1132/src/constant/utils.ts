import Toast from "react-native-toast-message";

//SCREENS
import { SCREENS } from "../screens";

export function showMessageToast(message: string, visibilityTime?: number) {
    Toast.show({
        type: 'error',
        text1: message,
        position: 'bottom',
        visibilityTime: (visibilityTime ? visibilityTime : 3000),
    });
}

export const QuickLinksMenu = [
    {
        title: 'Recharge',
        image: 'credit-card',
        type: 'FontAwesome',
        color: '#FF0000',
        navigation: SCREENS.Recharge.identifier
    },
    {
        title: 'Fibernet',
        image: 'access-point-network',
        type: 'MaterialCommunityIcons',
        color: '#004764',
        navigation: SCREENS.MyFiberPlan.identifier
    },
    {
        title: 'Roaming',
        image: 'mobile-alt',
        type: 'Fontisto',
        color: '#ffbf00',
        navigation: SCREENS.Roaming.identifier
    },
    {
        title: 'Pay Bill',
        image: 'dollar-bill',
        type: 'Foundation',
        color: '#37c6ff',
        navigation: SCREENS.PayBill.identifier
    },
    {
        title: 'Shopping',
        image: 'shopping-cart',
        type: 'Feather',
        color: '#7FFFD4',
        navigation: SCREENS.Shopping.identifier
    },
    {
        title: 'News',
        image: 'newspaper',
        type: 'MaterialIcons',
        color: '#37c6ff',
        navigation: 'News'
    },
    {
        title: 'MoMo',
        image: 'bank',
        type: 'FontAwesome',
        color: '#0000FF'
    },
    {
        title: 'Music',
        image: 'music',
        type: 'FontAwesome',
        color: '#ff7f50',
        navigation: 'Music'
    },
    {
        title: 'Movies',
        image: 'video',
        type: 'Feather',
        color: '#ff4500',
        navigation: 'Movies'
    },
    {
        title: 'Share',
        image: 'data-exploration',
        type: 'MaterialIcons',
        color: '#37c6ff',
        navigation: SCREENS.TelecomShare.identifier
    },
    {
        title: 'Borrow',
        image: 'cloud-down',
        type: 'Fontisto',
        color: '#ffbf00',
        navigation: SCREENS.TelecomBorrow.identifier
    },
    // {
    //     title: 'Subscription',
    //     image: 'credit-card',
    //     type: 'FontAwesome',
    //     color: '#37c6ff'
    // },
    {
        title: 'History',
        image: 'history',
        type: 'FontAwesome',
        color: '#FF0000',
        navigation: SCREENS.TransactionHistory.identifier
    },
    {
        title: 'Contact us',
        image: 'phone',
        type: 'FontAwesome',
        color: '#37c6ff',
        navigation: SCREENS.ContactUs.identifier
    },
    {
        title: 'Buy Electricity',
        image: 'electric-bolt',
        type: 'MaterialIcons',
        color: '#FF0000',
    },
    // {
    //     title: 'Share App',
    //     image: 'share',
    //     type: 'FontAwesome',
    //     color: '#7FFFD4',
    // },
]
export const PaymentOptions = [
    {
        title: 'Pay by Credit/Debit Card'
    },
    {
        title: 'Pay by Voucher'
    },
    {
        title: 'Pay by Airtime'
    }
]
export const formatRawMobileNumber = (rawMobileNumber: any) => {
    let mobileNumber = rawMobileNumber;
    const prefix4 = mobileNumber?.substring(0, 3);
    const prefix3 = mobileNumber?.substring(0, 2);
    const prefix1 = mobileNumber?.substring(0, 1);
    if (prefix4 === '+91') {
        mobileNumber = `91${rawMobileNumber.substring(3)}`;
    } else if (prefix3 === '91') {
        mobileNumber = rawMobileNumber;
    } else if (prefix1 === '0') {
        mobileNumber = `91${rawMobileNumber.substring(1)}`;;
    } else {
        mobileNumber = `91${rawMobileNumber}`;
    }
    return mobileNumber;
};
export const formatToDecimalNumber = (rawNumber: any) => {
    let number = rawNumber;
    number = (Math.round(number * 100) / 100).toFixed(2);
    return number
}

export const opratorLogo = (oprator: string) => {
    if (oprator === 'MTN') {
        return { source: require('../assets/images/MTNLogo.png'), height: 45, width: 83, name: 'MTN' }
    } else if (oprator === 'DEMO') {
        return { source: require('../assets/images/telecom.png'), height: 40, width: 120, name: 'Telecom' }
    }
}

export const operator = 'MTN'
