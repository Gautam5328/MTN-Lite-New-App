import { getScaleSize } from './scaleSize'
import { STRINGS, getTranslation } from './strings'

//UTILS
import { showMessageToast, QuickLinksMenu, formatRawMobileNumber, formatToDecimalNumber, PaymentOptions, operator } from './utils'

//STORAGE
import Storage from './storage'

export {
    getScaleSize,

    //UTILS
    QuickLinksMenu,
    PaymentOptions,
    showMessageToast,
    formatRawMobileNumber,
    formatToDecimalNumber,
    operator,

    STRINGS,
    getTranslation,

    Storage
}