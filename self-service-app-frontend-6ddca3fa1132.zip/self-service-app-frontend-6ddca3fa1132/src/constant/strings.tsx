import { useTranslation } from 'react-i18next'

export const STRINGS = {
    //API STRINGS
    auth_flow: "CUSTOM_AUTH",
    refresh_token: 'REFRESH_TOKEN',
    currency: "R",
    currencyCode: "ZAR",

    //LEADING SCREEN
    your_one_stop_application: getTranslation('your_one_stop_application'),
    boost_your_life_enhance_your_world: getTranslation('boost_your_life_enhance_your_world'),
    let_get_started: getTranslation('let_get_started'),

    //LOGIN SCREEN
    welcome_to: getTranslation('welcome_to'),
    telecom: getTranslation('telecom'),
    insert_your_phone_number_to_continue: getTranslation('insert_your_phone_number_to_continue'),
    mobile_number: getTranslation('mobile_number'),
    continue: getTranslation('continue'),
    or: getTranslation('or'),
    continue_with_apple: getTranslation('continue_with_apple'),
    continue_with_facebook: getTranslation('continue_with_facebook'),
    continue_with_google: getTranslation('continue_with_google'),
    enter_mobile_number_message: getTranslation('enter_mobile_number_message'),
    enter_valid_number_error: getTranslation('enter_valid_number_error'),

    //VERIFY OTP
    verify_its_you: getTranslation("verify_its_you"),
    we_have_sent_verification_code: getTranslation("we_have_sent_verification_code"),
    resend_otp: getTranslation('resend_otp'),
    invalid_otp: getTranslation('invalid_otp'),

    //TABBAR
    home: getTranslation('home'),
    smart_home: getTranslation('smart_home'),
    play: getTranslation('play'),
    more: getTranslation('more'),

    //HOME
    search: getTranslation('search'),
    data_balance: getTranslation('data_balance'),
    airtime_balance: getTranslation('airtime_balance'),
    recharge: getTranslation('recharge'),
    recharge_for_friend: getTranslation('recharge_for_friend'),
    buy_bundle: getTranslation('buy_bundle'),
    buy_now: getTranslation('buy_now'),
    quick_links: getTranslation('quick_links'),

    //RECHARGE
    enter_number_and_select_recharge_amount: getTranslation('enter_number_and_select_recharge_amount'),
    invalid_mobile: getTranslation('invalid_mobile'),

    //Device
    add_device_header: getTranslation('add_device_header'),
    add_device_description: getTranslation('add_device_description'),
    smart_bulb: getTranslation('smart_bulb'),
    smart_tv: getTranslation('smart_tv'),
    smart_ac: getTranslation('smart_ac'),
    air_purifier: getTranslation('air_purifier'),
    smart_camera: getTranslation('smart_camera'),
    smart_fan: getTranslation('smart_fan'),
    cancel: getTranslation('cancel'),

    //paymentSuccess
    payment_success: getTranslation("payment_success"),
    payment_canceled: getTranslation("payment_canceled"),
    payment_failed: getTranslation("payment_failed"),
    payment_success_desc: getTranslation("payment_success_desc"),
    ok: getTranslation('ok'),

    //Buy Bundle
    buy_bundle_success: getTranslation('buy_bundle_success'),

    //Assign Room
    assign_room_header: getTranslation('assign_room_header'),
    assign_room_text: getTranslation('assign_room_text'),
    living_room: getTranslation('living_room'),
    bed_room1: getTranslation('bed_room1'),
    bed_room2: getTranslation('bed_room2'),
    kichen: getTranslation('kichen'),
    guest_room: getTranslation('guest_room'),
    add_new_room: getTranslation('add_new_room'),

    //Name Device
    congratulations: getTranslation('congratulations'),
    your_new_smart_device_added_successfully: getTranslation('your_new_smart_device_added_successfully'),
    now_lets_give_your_device_a_name: getTranslation('now_lets_give_your_device_a_name'),
    device_name: getTranslation('device_name'),
    name_your_device: getTranslation('name_your_device'),

    //Device Added
    hundred: getTranslation('hundred'),
    your_devices_added_successfully: getTranslation('your_devices_added_successfully'),
    your_device_has_successfully: getTranslation('your_device_has_successfully'),
    been_added: getTranslation('been_added'),
    finish: getTranslation('finish'),

    //Add Bulb1
    add_smart_bulb: getTranslation('add_smart_bulb'),
    please_follow_these_instructions: getTranslation('please_follow_these_instructions'),
    connect_the_bulb_in_the_holder: getTranslation('connect_the_bulb_in_the_holder'),
    switch_the_bulb_on_and_off_five_times: getTranslation('switch_the_bulb_on_and_off_five_times'),
    bulb_will_now_start_blinking: getTranslation('bulb_will_now_start_blinking'),
    press_continue: getTranslation('press_continue'),

    //Add Bulb2
    looking_for_nearby_devices: getTranslation('looking_for_nearby_devices'),
    having_trouble_finding_the_device: getTranslation('having_trouble_finding_the_device'),
    click_here: getTranslation('click_here'),
    twenty: getTranslation('twenty'),

    //SHARE DATA
    share_data: getTranslation('share_data'),
    proceed: getTranslation('proceed'),
    share: getTranslation('share'),
    from: getTranslation('from'),
    to: getTranslation('to'),
    data: getTranslation('data'),
    linked_number: getTranslation('linked_number'),
    confirm_your_share: getTranslation('confirm_your_share'),
    share_data_value: getTranslation('share_data_value'),

    //SHARE AIRTIME
    share_airtime: getTranslation('share_airtime'),
    share_amount: getTranslation('share_amount'),

    //BORROW DATA
    borrow_data: getTranslation('borrow_data'),
    borrow_for: getTranslation('borrow_for'),

    //BORROW AIRTIME
    borrow_airtime: getTranslation('borrow_airtime'),

    //SELECT NUMBER
    select_number: getTranslation('select_number'),

    //BORROW
    header_title: getTranslation('header_title'),
    choose_borrow_airtime: getTranslation('choose_borrow_airtime'),
    choose_borrow_data: getTranslation('choose_borrow_data'),
    airtime: getTranslation('airtime'),

    //Share Airtime Data
    telecom_share: getTranslation('telecom_share'),
    share_airtime_data_header: getTranslation('share_airtime_data_header'),
    choose_airtime: getTranslation('choose_airtime'),

    //Borrow Airtime Data
    telecom_borrow: getTranslation('telecom_borrow'),
    borrow_airtime_data_header: getTranslation('borrow_airtime_data_header'),
    enter_data_message: getTranslation('enter_data_message'),
    enter_amount_message: getTranslation('enter_amount_message'),

    //Privacy Policy
    privacy_policy_header: getTranslation('privacy_policy_header'),

    //Terms Condition
    terms_condiitons_header: getTranslation('terms_condiitons_header'),

    //Airtime History
    transaction_history_header: getTranslation('transaction_history_header'),

    //Logout
    logout: getTranslation('logout'),

    //CONTACT_US
    contact_us: getTranslation('contact_us'),
    contact_us_msg: getTranslation('contact_us_msg'),
    customer_support: getTranslation('customer_support'),
    contact_no: getTranslation('contact_no'),
    email_address: getTranslation('email_address'),
    address: getTranslation('Address'),

    //VOUCHER
    enter_voucher: getTranslation('enter_voucher'),

    //PAY BILL
    pay_bill: getTranslation('pay_bill'),
    current_invoice: getTranslation('current_invoice'),
    total_outstanding_amount: getTranslation('total_outstanding_amount'),
    download_invoice: getTranslation('download_invoice'),
    pay_now: getTranslation('pay_now'),
    invoice_id: getTranslation('invoice_id'),
    bill_date: getTranslation('bill_date'),
    amount_due: getTranslation('amount_due'),
    bill_payment_success: getTranslation('bill_payment_success'),
    bill_paid: getTranslation('bill_paid'),

    //FIBER
    buy_fiberplan: getTranslation('buy_fiberplan'),
    buy_fiberPlan_success: getTranslation('buy_fiberPlan_success'),
    current_plans: getTranslation('current_plans'),
    fiber: getTranslation('fiber'),

    //Fibrt Card
    upgrade: getTranslation('upgrade'),
    browse_plans: getTranslation('browse_plans'),
    data_speed: getTranslation('data_speed'),

    //Roaming
    roaming: getTranslation('roaming'),
    voice_roaming: getTranslation('voice_roaming'),
    sms_roaming: getTranslation('sms_roaming'),
    data_roaming: getTranslation('data_roaming'),

    //FASTMODE
    fast_mode: getTranslation('fast_mode'),
    press_and_hold: getTranslation('press_and_hold'),
    next: getTranslation('next'),
    switch_to_slow: getTranslation('switch_to_slow'),

    //SLOWMODE
    slow_mode: getTranslation('slow_mode'),
    switch_to_fast: getTranslation('switch_to_fast'),

    //FASTMODESEARCH
    searching_for_device: getTranslation('searching_for_device'),

    //SLOWMODE2
    clicking_next: getTranslation('clicking_next'),
    please_connect: getTranslation('please_connect'),
    once_connected: getTranslation('once_connected'),

    //DeviceFound
    devices: getTranslation('devices'),
    devices_found: getTranslation('devices_found'),
    no_devices_found: getTranslation('no_devices_found'),

    //WIFIDETAILS
    wifi_details: getTranslation('wifi_details'),
    lets_get_your_wifi_details: getTranslation('lets_get_your_wifi_details'),
    please_ensure_your_wifi: getTranslation('please_ensure_your_wifi')
    
}

export function getTranslation(str: string) {
    const { t } = useTranslation()
    return t(str)
}