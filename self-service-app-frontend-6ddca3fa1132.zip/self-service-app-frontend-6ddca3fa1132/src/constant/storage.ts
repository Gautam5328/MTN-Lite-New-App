import * as Keychain from 'react-native-keychain';

const Storage = {
    ACCESS_TOKEN: 'ACCESS_TOKEN',
    REFRESH_TOKEN: 'REFRESH_TOKEN',
    async save(key: string, value: string): Promise<boolean> {
        try {
            const res = await Keychain.setGenericPassword(key, value ?? '', { service: key });
            return true
        } catch (error) {
            return false
        }
    },
    async get(key: string): Promise<string | null> {
        try {
            const result = await Keychain.getGenericPassword({ service: key });
            if (result as Keychain.UserCredentials) {
                return (result as Keychain.UserCredentials)?.password ?? null
            }
            return null
        } catch (error) {
            return null
        }
    },
    async clear() {
        const result = await Keychain.getAllGenericPasswordServices()
        for (var item of result) {
            Keychain.resetGenericPassword({ service: item });
        }
    }
}

export default Storage
