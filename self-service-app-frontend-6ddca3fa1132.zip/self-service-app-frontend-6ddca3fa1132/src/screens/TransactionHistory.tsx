import React, { useContext, useEffect, useState } from "react";
import { StyleSheet, View, FlatList, SafeAreaView, Dimensions } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { STRINGS, formatRawMobileNumber, getScaleSize, showMessageToast } from "../constant";

//COMPONENT
import { Header, HistoryCard, HistoryMsisdnCard, ProgressView, Text, TransactionTabs } from "../components";

//API
import { API } from "../api";

//PACKAGES
import { useSelector } from "react-redux";


function TransactionHistory(props: any) {

    const { theme } = useContext(ThemeContext)


    return (
        <View style={styles(theme).container}>
            <Header
                title={STRINGS.transaction_history_header}
                onBack={() => { props.navigation.goBack() }} />
            {/* <View style={styles(theme).msisdnContainer}>
                    <FlatList
                        data={msisdnList}
                        horizontal={true}
                        showsHorizontalScrollIndicator={false}
                        scrollEventThrottle={16}
                        keyExtractor={(item, index) => index.toString()}
                        renderItem={({ item, index }) => {
                            return (
                                <TouchableOpacity onPress={() => { setMobileNumber(item) }}>
                                    <HistoryMsisdnCard selectedMsisdn={mobileNumber.msisdn} msisdn={item.msisdn} customer_name={item.customer_name.charAt(0)} />
                                </TouchableOpacity>
                            )
                        }}
                    />
            </View> */}
            {/* <View style={styles(theme).detailContainer}> */}
                <TransactionTabs />
                {/*  */}
            {/* </View> */}
            <SafeAreaView />

        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    msisdnContainer:{
        flexDirection: 'row',
        marginBottom: getScaleSize(10),
        backgroundColor: theme.MAIN_THEME_COLOR,
        paddingVertical: getScaleSize(20),
        borderBottomLeftRadius: getScaleSize(15),
        borderBottomRightRadius: getScaleSize(15),
    },
    detailContainer: {
        flex: 1,
    },
})


export default TransactionHistory