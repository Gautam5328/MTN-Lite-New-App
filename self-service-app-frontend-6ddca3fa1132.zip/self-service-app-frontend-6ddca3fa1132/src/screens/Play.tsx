import React, { useContext } from "react";
import { StyleSheet, View } from "react-native";

//Components
import { Header, PlayTabs } from "../components";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

function Play(props: any) {

    const { theme } = useContext(ThemeContext)

    const redirect = props?.route?.params?.redirect ?? ''

    return (
        <View style={styles(theme).container}>
            <Header
                isHome
                onNotification={() => { }}
                onProfile={() => { }} />
            <PlayTabs navigation={props.navigation} redirect={redirect} />
        </View>
    )
}

export default Play

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme._FFF
    },
});