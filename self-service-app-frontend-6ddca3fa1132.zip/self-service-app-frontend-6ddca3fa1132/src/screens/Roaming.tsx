import React, { useContext, useEffect, useState } from "react";
import { StyleSheet, View, FlatList, SafeAreaView, Switch, TouchableOpacity } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { STRINGS, formatRawMobileNumber, getScaleSize, showMessageToast } from "../constant";
import { FONTS } from "../assets";

//COMPONENT
import { Header, HistoryCard, HistoryMsisdnCard, MsisdnsList, ProgressView, Text, TransactionTabs } from "../components";

//API
import { API } from "../api";

//PACKAGES
import { useDispatch, useSelector } from "react-redux";
import _ from "lodash";
import { setCustomerData } from "../redux/actions/customerDataActions";




function Roaming(props: any) {

    const { theme } = useContext(ThemeContext)

    const dispatch = useDispatch()<any>;

    const customerdetails = useSelector((state: any) => state.customerData);

    const msisdndetails = customerdetails?.customer?.msisdns?.[0] ?? {};
    const [msisdnList, setMsisdnList] = useState<any[]>(customerdetails?.customer?.msisdns ?? [])
    const [mobileNumber, setMobileNumber] = useState<any>(msisdndetails)
    const [roamingData, setRoamingData] = useState<boolean>(msisdndetails?.roaming_data ?? false);
    const [roamingSMS, setRoamingSMS] = useState<boolean>(msisdndetails?.roaming_sms ?? false);
    const [roamingVoice, setRoamingVoice] = useState<boolean>(msisdndetails?.roaming_voice ?? false);
    const [initialRender, setInitialRender] = useState<boolean>(true);

    const [dataArray, setDataArray]=useState<any>([{title:STRINGS.voice_roaming, isEnabled:true}, {title:STRINGS.sms_roaming, isEnabled:true}, {title:STRINGS.data, isEnabled:true}])

    useEffect(()=>{
        if (!initialRender) {
            setRoaming()
        }
    }, [roamingData, roamingSMS, roamingVoice])

    const onMsisdnSelect = async (item: any) => {
        setMobileNumber(item)
    }

    const toggleSwitch = async() => {
        // setRoaming();
    };

    const setRoaming = async() => {
        try {

            let params = {
                "roaming_voice": roamingVoice,
                "roaming_sms": roamingSMS,
                "roaming_data": roamingData,
            };
            const result = await API.transactionInstance.put('/customer/roaming', params)
            if (result.status == 200) {
                showMessageToast(result?.data?.message ?? '')
                fetchCustomerBalance()
            }
        }
        catch (error: any) {
            showMessageToast(error?.message ?? '')
        }
    }
    const fetchCustomerBalance = async () => {
        try {
            const result = await API.transactionInstance.get('/customer/details')
            if (result.status == 200) {
                dispatch(setCustomerData(result?.data));
            }
            else {
            }
        }
        catch (error: any) {
        }
    };

    const setSwitchValue = (val: boolean, ind: number) => {
        const tempData = _.cloneDeep(dataArray);
        tempData[ind].isEnabled = val;
        setDataArray(tempData)
    }

    return (
        <View style={styles(theme).container}>
            <Header
                title={STRINGS.roaming}
                onBack={() => { props.navigation.goBack() }} />
            <MsisdnsList msisdn={mobileNumber} msisdnList={msisdnList} onPress={(item) => {
                onMsisdnSelect(item)
            }} />
             {/* <FlatList
                    data={dataArray}
                    ListHeaderComponent={() => <View style={{ height: getScaleSize(20) }} />}
                    ListFooterComponent={() => <View style={{ height: getScaleSize(20) }} />}
                    renderItem={({ item, index }) => {
                        return (
                                <View style={styles(theme).msisdnContainer}>
                                    <Text
                                        font={FONTS.Roboto.Bold}
                                        color={theme.TEXT_COLOR_AS_THEME}
                                        size={getScaleSize(14)}>
                                        {item.title}
                                    </Text>
                                    <View>
                                        <Switch
                                            trackColor={{ false: '#F04770', true: '#06D7A0' }}
                                            thumbColor={item.isEnabled ? '#fff' : '#fff'}
                                            ios_backgroundColor="#3e3e3e"
                                            onValueChange={(value) => { 
                                                setSwitchValue(value, index) 
                                            }}
                                            value={item.isEnabled}
                                            // disabled={true}
                                        />
                                    </View>
                                </View>
                        )
                    }} />  */}
             <View style={styles(theme).msisdnContainer}>
                    <Text
                        font={FONTS.Roboto.Bold}
                        color={theme.TEXT_COLOR_AS_THEME}
                        size={getScaleSize(14)}>
                        {STRINGS.voice_roaming}
                    </Text>
                    <View>
                        <Switch
                            trackColor={{ false: '#F04770', true: '#06D7A0' }}
                            thumbColor={roamingVoice ? '#fff' : '#fff'}
                            ios_backgroundColor="#3e3e3e"
                            onValueChange={(value)=>{
                                setInitialRender(false)
                                setRoamingVoice(value)
                                toggleSwitch()
                            }}
                            value={roamingVoice}
                            // disabled={true}
                        />
                    </View>
            </View>

            <View style={styles(theme).msisdnContainer}>
                    <Text
                        font={FONTS.Roboto.Bold}
                        color={theme.TEXT_COLOR_AS_THEME}
                        size={getScaleSize(14)}>
                        {STRINGS.sms_roaming}
                    </Text>
                    <View>
                        <Switch
                            trackColor={{ false: '#F04770', true: '#06D7A0' }}
                            thumbColor={roamingSMS ? '#fff' : '#fff'}
                            ios_backgroundColor="#3e3e3e"
                            onValueChange={(value)=>{
                                setInitialRender(false)
                                setRoamingSMS(value)
                                toggleSwitch()
                            }}
                            value={roamingSMS}
                            // disabled={true}
                        />
                    </View>
            </View>

            <View style={styles(theme).msisdnContainer}>
                    <Text
                        font={FONTS.Roboto.Bold}
                        color={theme.TEXT_COLOR_AS_THEME}
                        size={getScaleSize(14)}>
                        {STRINGS.data_roaming}
                    </Text>
                    <View>
                        <Switch
                            trackColor={{ false: '#F04770', true: '#06D7A0' }}
                            thumbColor={roamingData ? '#fff' : '#fff'}
                            ios_backgroundColor="#3e3e3e"
                            onValueChange={(value)=>{
                                setInitialRender(false)
                                setRoamingData(value)
                                toggleSwitch()
                            }}
                            value={roamingData}
                            // disabled={true}
                        />
                    </View>
            </View> 
            <SafeAreaView />

        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    msisdnContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: getScaleSize(10),
        backgroundColor: theme._F7F7F7,
        paddingVertical: getScaleSize(15),
        paddingHorizontal: getScaleSize(20),
        borderRadius: getScaleSize(15),
        marginHorizontal: getScaleSize(20),
        borderColor: theme._F5F5F5,
        borderWidth: getScaleSize(1),
    },
    detailContainer: {
        flex: 1,
    },
    switchContainer:{
        
    }
})


export default Roaming