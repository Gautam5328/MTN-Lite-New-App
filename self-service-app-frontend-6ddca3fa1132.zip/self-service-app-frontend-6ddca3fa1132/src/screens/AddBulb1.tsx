import { View, StyleSheet, SafeAreaView, Image } from 'react-native'
import React, { useContext } from 'react'
//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context"

//ASSETS & CONSTANT
import { FONTS, IMAGES } from "../assets"
import { STRINGS, getScaleSize } from "../constant"

//COMPONENTS
import { Button, Header, Text } from "../components"

//SCREENS
import { SCREENS } from "../screens"

function AddBulb1(props: any) {

    const { theme } = useContext(ThemeContext);

    const { logDetails } = useContext(ShipbookContext);

    function onContinue() {
        logDetails("Continue button clicked");
        
        props.navigation.navigate(SCREENS.AddBulb2.identifier);
    }
    
    return (
        <View style={style(theme).rootContainer}>
            <Header
                title={STRINGS.add_smart_bulb}
                onBack={() => { props.navigation.goBack() }} />
            <View style={style(theme).container}>
                <View style={style(theme).headContainer}>
                    <Image source={IMAGES.warning} style={style(theme).headImage} />
                    <Text
                        style={style(theme).heading}
                        font={FONTS.Roboto.Regular}
                        color={theme._000}
                        size={getScaleSize(20)}>
                        {STRINGS.please_follow_these_instructions}
                    </Text>
                </View>
                <View style={style(theme).instContainer}>
                    <Text
                        style={style(theme).instructions}
                        font={FONTS.Roboto.Regular}
                        color={theme._000}
                        size={getScaleSize(17)}>
                        {STRINGS.connect_the_bulb_in_the_holder}
                    </Text>
                    <Text
                        style={style(theme).instructions}
                        font={FONTS.Roboto.Regular}
                        color={theme._000}
                        size={getScaleSize(17)}>
                        {STRINGS.switch_the_bulb_on_and_off_five_times}
                    </Text>
                    <Text
                        style={style(theme).instructions}
                        font={FONTS.Roboto.Regular}
                        color={theme._000}
                        size={getScaleSize(17)}>
                        {STRINGS.bulb_will_now_start_blinking}
                    </Text>
                    <Text
                        style={style(theme).instructions}
                        font={FONTS.Roboto.Regular}
                        color={theme._000}
                        size={getScaleSize(17)}>
                        {STRINGS.press_continue}
                    </Text>
                </View>
                <View style={style(theme).btnContainer}>
                    <Button
                        style={style(theme).btnGetStarted}
                        title={STRINGS.continue}
                        onPress={() => onContinue()}
                    />
                    <Text
                        style={style(theme).subtitle}
                        font={FONTS.Roboto.Regular}
                        color={theme._AFAFAF}
                        size={getScaleSize(15)}>
                        {STRINGS.cancel}
                    </Text>
                </View>
            </View>
            <SafeAreaView />
        </View>
    )
}

export default AddBulb1

const style = (theme: ThemeContextType['theme']) => StyleSheet.create({

    rootContainer: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    container: {
        flex: 1.0,
        paddingHorizontal: getScaleSize(24)
    },
    subtitle: {
        alignSelf: 'center'
    },
    btnGetStarted: {
        marginTop: getScaleSize(40),
        marginBottom: getScaleSize(30)
    },
    headContainer: { flex: 0.1, flexDirection: 'row', alignItems: 'center' },
    heading: { color: 'black', fontWeight: 'bold' },
    headImage: { width: 20, height: 20, marginRight: 10 },
    instructions: { color: 'black' },
    instContainer: { flex: 0.3, justifyContent: 'space-evenly' },
    cancel: { marginTop: 20, alignSelf: 'center', color: 'grey' },
    btnContainer: { flex: 0.55, justifyContent: 'flex-end' },
})
