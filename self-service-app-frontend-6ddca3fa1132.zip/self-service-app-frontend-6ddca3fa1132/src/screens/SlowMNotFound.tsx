import { View, StyleSheet, SafeAreaView, Image } from 'react-native'
import React, { useContext } from 'react'
//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context"

//ASSETS & CONSTANT
import { FONTS, IMAGES } from "../assets"
import { STRINGS, getScaleSize } from "../constant"

//COMPONENTS
import { Button, Header, Text } from "../components"

//SCREENS
import { SCREENS } from "../screens"

function SlowMNotFound(props: any) {

    const { theme } = useContext(ThemeContext);

    const { logDetails } = useContext(ShipbookContext);

    function onNext() {
        logDetails("Next button clicked");
        props.navigation.navigate(SCREENS.SlowMode2.identifier);
    }
    function onSwitch() {
        logDetails("Switch button clicked");
        props.navigation.navigate(SCREENS.FastMode.identifier);
    }

    return (
        <View style={style(theme).rootContainer}>
            <Header
                title={STRINGS.devices}
                onBack={() => { props.navigation.goBack() }} />
            <View style={style(theme).container}>

                <View style={style(theme).instruction}>
                    <Text
                        font={FONTS.Roboto.Bold}
                        color={theme._000}
                        size={getScaleSize(21)}>
                        {STRINGS.no_devices_found}
                    </Text>
                </View>
                <View style={style(theme).btnContainer}>
                    <Button
                        style={style(theme).btnGetStarted}
                        title={STRINGS.next}
                    // onPress={() => onNext()}
                    />
                    <Button
                        style={style(theme).btnGetStarted}
                        title={STRINGS.switch_to_fast}
                        onPress={() => onSwitch()}
                    />
                </View>
            </View>
            <SafeAreaView />
        </View>
    )
}

export default SlowMNotFound

const style = (theme: ThemeContextType['theme']) => StyleSheet.create({

    rootContainer: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    container: {
        flex: 1.0,
        paddingHorizontal: getScaleSize(24)
    },
    btnGetStarted: {
        marginBottom: getScaleSize(20)
    },
    instruction: {
        flex: 0.55,
        justifyContent: 'center',
        alignItems: 'center'
    },
    btnContainer: {
        flex: 0.4,
        justifyContent: 'flex-end'
    },
})
