import React, { useContext, useEffect, useState } from "react";
import {
  Dimensions,
  Image,
  Keyboard,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

//ASSETS & CONSTANT
import { FONTS, IMAGES } from "../assets";
import { STRINGS, getScaleSize, showMessageToast } from "../constant";

//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context"

//SCREENS
import { SCREENS } from "../screens"

//API
import { API } from "../api";

//COMPONENTS
import { Button, CountryCodePicker, Header, Text } from "../components";
import { Country, CountryCode } from "react-native-country-picker-modal";
import KeysTurbo from "react-native-keys";
import { opratorLogo } from "../constant/utils";

function Login(props: any) {

  const [isCountryPickerVisible, setCountryPickerVisible] = useState<boolean>(false);
  const [countryCode, setCountryCode] = useState<CountryCode>("IN");
  const [countryCallingCode, setCountryCallingCode] = useState("91");
  const [mobileNumber, setMobileNumber] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { theme, operator } = useContext(ThemeContext)
  const { logDetails, logScreen } = useContext(ShipbookContext);

  useEffect(() => {
    logScreen('Login');
  }, []);

  async function onContinue() {
    logDetails("Continue button clicked");

    Keyboard.dismiss();

    if (!mobileNumber) {
      showMessageToast(STRINGS.enter_mobile_number_message);
      return;
    } else if (mobileNumber.length < 10) {
      showMessageToast(STRINGS.enter_valid_number_error);
      return;
    }

    // Strip leading '0' if present
    let strippedNumber = mobileNumber.startsWith('0') ? mobileNumber.slice(1) : mobileNumber;

    let number = `+${countryCallingCode + strippedNumber}`;

    const params = {
      AuthFlow: STRINGS.auth_flow,
      ClientId: KeysTurbo.secureFor('amazon_client_id'),
      AuthParameters: {
        USERNAME: number,
      },
    };

    try {
      setIsLoading(true);
      const result = await API.authInstance.post('', params, {
        headers: { 'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth' },
      });
      setIsLoading(false);

      if (result.status == 200) {
        props.navigation.navigate(SCREENS.OtpVerification.identifier, {
          verificationData: result?.data,
          mobileNumber: number,
        });
      }
    } catch (error: any) {
      setIsLoading(false);
      showMessageToast(error?.message ?? '');
    }
  }

  function onApple() {
    logDetails("Apple sign-in clicked");
  }

  function onFacebook() {
    logDetails("Facebook sign-in clicked");
  }

  function onGoogle() {
    logDetails("Google sign-in clicked");
  }


  return (
    <View style={styles(theme).container}>
      <Header
        isDisableShadow
        onBack={() => {
          props.navigation.goBack();
        }}
      />
      <View style={styles(theme).detailsContainer}>
        <Image
          style={[styles(theme).imgLogo, { height: opratorLogo(operator)?.height * 1.2, width: opratorLogo(operator)?.width * 1.2 }]}
          resizeMode="contain"
          source={opratorLogo(operator)?.source} />
        <Text
          style={styles(theme).titleText}
          font={FONTS.Roboto.Regular}
          color={theme._333333}
          size={getScaleSize(18)}
        >
          {STRINGS.welcome_to}
          <Text
            font={FONTS.Roboto.Black}
            color={theme.MAIN_THEME_COLOR}
            size={getScaleSize(18)}
          >
            {opratorLogo(operator)?.name}
          </Text>
        </Text>
        <Text
          style={styles(theme).subtitleText}
          font={FONTS.Roboto.Medium}
          color={theme._AFAFAF}
          size={getScaleSize(16)}
        >
          {STRINGS.insert_your_phone_number_to_continue}
        </Text>
        <View style={styles(theme).inputContainer}>
          <CountryCodePicker
            countryCode={countryCode}
            visible={isCountryPickerVisible}
            onOpen={() => setCountryPickerVisible(true)}
            onClose={() => setCountryPickerVisible(false)}
            onSelect={(country: Country) => {
              setCountryCode(country.cca2);
              setCountryCallingCode(`${country.callingCode}`);
            }}
          />
          <TouchableOpacity onPress={() => setCountryPickerVisible(true)}>
            <Image style={styles(theme).inputDropDown} source={IMAGES.down} />
          </TouchableOpacity>
          <TextInput
            keyboardType="phone-pad"
            value={mobileNumber}
            onChangeText={(e) => setMobileNumber(e)}
            maxLength={11}
            placeholderTextColor={theme._333333}
            style={styles(theme).numberInput}
            placeholder={STRINGS.mobile_number}
          />
        </View>
        <Button
          isDisable={mobileNumber.length < 10 ? true : false}
          loading={isLoading}
          title={STRINGS.continue}
          onPress={() => onContinue()} />
        {/* Social login is disabled for now */}
        {/* <View style={styles(theme).orDeviderContainer}>
                    <View style={styles(theme).orDevider} />
                    <Text
                        style={styles(theme).orText}
                        font={FONTS.Roboto.Regular}
                        color={theme._AFAFAF}
                        size={getScaleSize(14)}>
                        {STRINGS.or}
                    </Text>
                    <View style={styles(theme).orDevider} />
                </View>
                <Button
                    type="social"
                    leftIcon={IMAGES.apple}
                    title={STRINGS.continue_with_apple}
                    onPress={() => onApple()} />
                <Button
                    type="social"
                    style={styles(theme).socialButton}
                    leftIcon={IMAGES.facebook}
                    title={STRINGS.continue_with_facebook}
                    onPress={() => onFacebook()} />
                <Button
                    type="social"
                    style={styles(theme).socialButton}
                    leftIcon={IMAGES.google}
                    title={STRINGS.continue_with_google}
                    onPress={() => onGoogle()} /> */}
      </View>
    </View>
  );
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
  container: {
    flex: 1.0,
    backgroundColor: theme._FFF,
  },
  detailsContainer: {
    flex: 1.0,
    paddingHorizontal: getScaleSize(24),
  },
  titleText: {
    marginTop: getScaleSize(20),
  },
  subtitleText: {
    marginTop: getScaleSize(4),
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: getScaleSize(40),
    height: getScaleSize(40)
  },
  inputCountryContainer: {
    flexDirection: "row",
    height: getScaleSize(40),
  },
  inputCountry: {
    height: getScaleSize(40),
    width: getScaleSize(40),
    borderRadius: getScaleSize(20),
    backgroundColor: theme._D3D3D3,
  },
  inputDropDown: {
    height: getScaleSize(15),
    width: getScaleSize(15),
  },
  numberInput: {
    flex: 1.0,
    borderWidth: 1,
    borderColor: theme._D3D3D3,
    height: "100%",
    color: theme._000,
    marginLeft: getScaleSize(12),
    paddingHorizontal: getScaleSize(8),
    fontFamily: FONTS.Roboto.Regular,
  },
  socialButton: {
    marginTop: getScaleSize(12),
  },
  orDeviderContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginVertical: getScaleSize(30),
  },
  orDevider: {
    height: 1,
    backgroundColor: theme._D3D3D3,
    width: Dimensions.get("window").width / 6,
  },
  orText: {
    marginHorizontal: getScaleSize(12),
  },
  imgLogo: {
    alignSelf: 'center',

    marginVertical: getScaleSize(40)
  }
});

export default Login;
