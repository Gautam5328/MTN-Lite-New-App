import React, { useContext, useEffect, useState } from "react";
import { StyleSheet, View, Image, Dimensions } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { STRINGS, getScaleSize } from "../constant";
import { FONTS, IMAGES } from "../assets";

//COMPONENT
import { Header, List, Text } from "../components";
import Icons from "../components/Icons";

//API
import { API } from "../api";


function ContactUs(props: any) {

    const { theme } = useContext(ThemeContext)

    const [contactItems, setContactItems] = useState<any>({ isLoading: true, contactList: [] })
    const [refreshing, setRefreshing] = useState<boolean>(false);

    useEffect(() => {
        fetchContactUs()
    }, [])

    const fetchContactUs = async () => {
        try {
            const result = await API.transactionInstance.get('/customer/contact-us')
            if (result.status == 200) {
                setContactItems({ isLoading: false, contactList: result?.data })
            }
            else {
                setContactItems({ isLoading: false, contactList: [] })
                setRefreshing(false)
            }
        }
        catch (error: any) {
            setContactItems({ isLoading: false, contactList: [] })
            setRefreshing(false)
            setContactItems(error?.message ?? '')
        }
    }

    return (
        <View style={styles(theme).container}>
            <Header
                title={STRINGS.contact_us}
                onBack={() => { props.navigation.goBack() }} />
            <List isLoading={contactItems?.isLoading}>
                <Text
                    style={styles(theme).txtContactUsMsg}
                    font={FONTS.Roboto.Medium}
                    color={theme._333333}
                    size={getScaleSize(16)}>
                    {STRINGS.contact_us_msg}
                </Text>
                <View style={styles(theme).inputContainer}>
                    <Text
                        font={FONTS.Roboto.Bold}
                        color={theme._333333}
                        size={getScaleSize(16)}>
                        {STRINGS.customer_support}
                    </Text>
                    <View style={styles(theme).detailsContainer}>
                        <Icons
                            name={'phone'}
                            color={theme.MAIN_THEME_COLOR}
                            type={'MaterialIcons'}
                            size={25} />
                        <View style={styles(theme).detailsView}>
                            <Text
                                font={FONTS.Roboto.Regular}
                                color={theme._333333}
                                size={getScaleSize(14)}>
                                {STRINGS.contact_no}
                            </Text>
                            <Text
                                font={FONTS.Roboto.Medium}
                                color={theme._333333}
                                size={getScaleSize(14)}>
                                {contactItems?.contactList?.phone_number ?? '-'}
                            </Text>
                        </View>
                    </View>
                    <View style={styles(theme).detailsContainer}>
                        <Icons
                            name={'map-pin'}
                            color={theme.MAIN_THEME_COLOR}
                            type={'Feather'}
                            size={25} />
                        <View style={styles(theme).detailsView}>
                            <Text
                                font={FONTS.Roboto.Regular}
                                color={theme._333333}
                                size={getScaleSize(14)}>
                                {STRINGS.address}
                            </Text>
                            <Text
                                font={FONTS.Roboto.Medium}
                                color={theme._333333}
                                size={getScaleSize(14)}>
                                {contactItems?.contactList?.address ?? '-'}
                            </Text>
                            <Image source={IMAGES.mapDummy} style={styles(theme).mapDummy} />
                        </View>
                    </View>
                </View>
            </List>
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF
    },
    txtContactUsMsg: {
        marginHorizontal: getScaleSize(16),
        marginVertical: getScaleSize(16)
    },
    inputContainer: {
        backgroundColor: theme._FFF,
        borderRadius: getScaleSize(16),
        borderWidth: 1,
        borderColor: theme._828282,
        marginHorizontal: getScaleSize(16),
        paddingVertical: getScaleSize(16),
        paddingHorizontal: getScaleSize(16)
    },
    detailsContainer: {
        flexDirection: 'row',
        marginTop: getScaleSize(16)
    },
    image: {
        height: getScaleSize(25),
        width: getScaleSize(25),
        alignSelf: 'center'
    },
    detailsView: {
        marginLeft: getScaleSize(16),
        alignSelf: 'center'
    },
    mapDummy: {
        height: Dimensions.get('window').width / 2,
        width: Dimensions.get('window').width / 2,
        marginTop: getScaleSize(10),
        borderRadius: getScaleSize(12)
    }

})

export default ContactUs