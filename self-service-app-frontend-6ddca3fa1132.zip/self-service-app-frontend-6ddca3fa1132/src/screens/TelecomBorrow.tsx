import React, { useContext, useState } from "react";
import { FlatList, StyleSheet, TouchableOpacity, View } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { STRINGS, getScaleSize, showMessageToast } from "../constant";
import { FONTS } from "../assets";

//COMPONENT
import { Header, ShareItem, Text } from "../components";
import { SCREENS } from ".";

//PACKAGES
import { useSelector } from "react-redux";

function TelecomBorrow(props: any) {

  const { theme } = useContext(ThemeContext)

  const customerDetails = useSelector((state: any) => state.customerData);


  return (
    <View style={styles(theme).container}>
      <Header
        title={STRINGS.telecom_borrow}
        onBack={() => { props.navigation.goBack() }} />
      <View style={styles(theme).detailContainer}>
        <FlatList
          data={[{ 'screen': SCREENS.BorrowDataForm.identifier, 'icon': 'currency-exchange', 'title': STRINGS.borrow_data, 'description': 'Borrow upto 100MB of data' }, { 'screen': SCREENS.BorrowAirtimeForm.identifier, 'icon': 'emergency-share', 'title': STRINGS.borrow_airtime, 'description': 'Borrow upto 100 units' }]}
          renderItem={({ item, index }) => {
            return (
              <ShareItem
                title={item.title}
                description={item.description}
                iconName={item.icon}
                onPress={() => {
                  if (customerDetails?.customer?.msisdns?.length > 0) {
                    props.navigation.navigate(item.screen)
                  }
                  else {
                    showMessageToast("You don't have any valid msisdn")
                  }
                }} />
            )
          }} />
      </View>
    </View>
  )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
  container: {
    flex: 1.0,
    backgroundColor: theme._FFF,
  },
  detailContainer: {
    marginHorizontal: getScaleSize(24),
    marginTop: getScaleSize(10),
  },
})


export default TelecomBorrow