import React, { useContext, useEffect, useRef, useState } from "react";
import {
  View, TextInput,
  StyleSheet,
  Dimensions,
  Keyboard,
  Alert,
  TouchableOpacity,
} from "react-native";

//ASSETS & CONSTANTS
import { FONTS } from "../assets";
import { getScaleSize, showMessageToast, Storage, STRINGS } from "../constant";

//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context";

//COMPONENTS
import { Button, Header, ProgressView, Text } from "../components";

//API
import { API } from "../api";

//SCREENS
import { SCREENS } from "../screens";

//PACKAGES
import OTPTextInput from "react-native-otp-textinput";
import { CommonActions } from "@react-navigation/native";
import KeysTurbo from "react-native-keys";

const OtpVerification = (props: any) => {

  const verificationData = props?.route?.params?.verificationData ?? null
  const mobileNumber = props?.route?.params?.mobileNumber ?? ''

  const { theme } = useContext(ThemeContext);
  const { logDetails } = useContext(ShipbookContext);

  const otpInput = useRef(null);

  const [verificationDetails, setVerificationDetails] = useState(verificationData)
  const [counter, setCounter] = React.useState(60);
  const [otpText, setOtpText] = useState('')
  const [isLoading, setLoading] = useState(false)

  let timer: any;

  const refCounter = useRef<number>(0)
  refCounter.current = counter

  useEffect(() => {
    startTimer()
  }, [])

  function startTimer() {
    timer = setInterval(() => {
      if (refCounter.current > 0) {
        setCounter(prev => prev - 1)
      }
      else {
        stopTimer()
      }
    }, 1000)
  }

  function stopTimer() {
    timer && clearInterval(timer)
  }

  async function onContinue() {
    if(!otpText){
      Keyboard.dismiss();
      showMessageToast('Enter otp')
      return
    }
    logDetails(`Verify OTP ${mobileNumber} - OTP: ${otpText}`)

    Keyboard.dismiss();

    let params = {
      "ClientId": KeysTurbo.secureFor('amazon_client_id'),
      "ChallengeName": verificationDetails.ChallengeName,
      "ChallengeResponses": {
        "USERNAME": mobileNumber,
        "ANSWER": otpText
      },
      "Session": verificationDetails?.Session
    };

    try {
      setLoading(true);
      const result = await API.authInstance.post('', params, {
        headers: {
          'X-Amz-Target': 'AWSCognitoIdentityProviderService.RespondToAuthChallenge',
        }
      })
      setLoading(false)

      if (result.status == 200) {
        if (result?.data?.AuthenticationResult && result?.data?.AuthenticationResult?.IdToken) {
          await Storage.save(Storage.ACCESS_TOKEN, result?.data?.AuthenticationResult?.IdToken);
          await Storage.save(Storage.REFRESH_TOKEN, result?.data?.AuthenticationResult?.RefreshToken);

          props.navigation.dispatch(
            CommonActions.reset({
              index: 0,
              routes: [
                { name: SCREENS.BottomBar.identifier }
              ],
            })
          );
        }
        else {
          setVerificationDetails(result?.data)
          showMessageToast(STRINGS.invalid_otp)
        }
      }
    }
    catch (error: any) {
      setLoading(false)
      showMessageToast(error?.message ?? '')
    }
  }

  // async function resendOtp() {
  //   logDetails(`Resend OTP ${mobileNumber}`)

  //   Keyboard.dismiss();

  //   const params = {
  //     AuthFlow: STRINGS.auth_flow,
  //     ClientId: KeysTurbo.secureFor('amazon_client_id'),
  //     AuthParameters: {
  //       USERNAME: mobileNumber,
  //     },
  //   }

  //   try {
  //     setLoading(true);
  //     const result = await API.authInstance.post('', params, {
  //       headers: { 'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth' }
  //     })
  //     setLoading(false)

  //     if (result.status == 200) {
  //       setVerificationDetails(result?.data)
  //     }
  //   }
  //   catch (error: any) {
  //     setLoading(false)
  //     showMessageToast(error?.message ?? '')
  //   }
  // }

  async function resendOtp() {
    logDetails(`Resend OTP ${mobileNumber}`);
  
    Keyboard.dismiss();
  
    const params = {
      AuthFlow: STRINGS.auth_flow,
      ClientId: KeysTurbo.secureFor('amazon_client_id'),
      AuthParameters: {
        USERNAME: mobileNumber,
      },
    };
  
    try {
      setLoading(true);
      const result = await API.authInstance.post('', params, {
        headers: { 'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth' },
      });
      setLoading(false);
  
      if (result.status === 200) {
        setVerificationDetails(result?.data);
        
        // Reset the timer
        setCounter(60);
        startTimer();
      }
    } catch (error: any) {
      setLoading(false);
      showMessageToast(error?.message ?? '');
    }
  }


  return (
    <View style={styles(theme).container}>
      <Header
        isDisableShadow
        onBack={() => {
          props.navigation.goBack();
        }} />
      <View style={styles(theme).mainContainer}>
        <Text
          style={{ marginLeft: 30, marginBottom: 5, marginTop: 30 }}
          font={FONTS.Roboto.Bold}
          color={theme.MAIN_THEME_COLOR}
          size={getScaleSize(24)}>
          {STRINGS.verify_its_you}
        </Text>
        <Text
          style={{ marginHorizontal: 30, marginBottom: 50 }}
          font={FONTS.Roboto.Medium}
          color={theme._AFAFAF}
          size={getScaleSize(14)}>
          {`${STRINGS.we_have_sent_verification_code + "XXXXXXXX" + mobileNumber?.substring(mobileNumber.length - 2)}`}
        </Text>
        <View style={{ flexDirection: "row", justifyContent: "center" }}>
          <OTPTextInput ref={otpInput}
            handleTextChange={(text) => { setOtpText(text) }}
            tintColor={theme.MAIN_THEME_COLOR}
            autoFocus={true}
            textInputStyle={styles(theme).input} />
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
          <TouchableOpacity onPress={() => counter <= 0 && resendOtp()}>
            <Text
              style={{ textAlign: "center", marginTop: 30 }}
              font={FONTS.Roboto.Medium}
              color={counter <= 0 ? theme.MAIN_THEME_COLOR : theme._AFAFAF}
              size={getScaleSize(20)}>
              {`${STRINGS.resend_otp}`}
            </Text>
          </TouchableOpacity>
          {counter > 0 &&
            <Text
              style={{ textAlign: "center", marginTop: 30 }}
              font={FONTS.Roboto.Medium}
              color={theme._AFAFAF}
              size={getScaleSize(20)}>
              {` in 00:${counter < 10 ? `0${counter}` : counter}`}
            </Text>
          }
        </View>
        <Button
          style={styles(theme).btnVerify}
          isDisable={otpText.length != 4 ? true : false}
          title={STRINGS.verify_its_you}
          onPress={() => onContinue()} />
      </View>
      {isLoading && <ProgressView />}
    </View>
  );
};

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme._FFF,
  },
  mainContainer: {
    flex: 1,
    backgroundColor: theme._FFF,
  },
  btnVerify: {
    marginHorizontal: getScaleSize(20),
    marginTop: getScaleSize(40)
  },
  input: {
    borderColor: theme._333333,
    borderWidth: 2,
    borderBottomWidth: 2,
    borderRadius: 5
  }
});

export default OtpVerification;
