import { View, StyleSheet, SafeAreaView } from 'react-native'
import React, { useContext } from 'react'

//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context"

//ASSETS & CONSTANT
import { FONTS } from "../assets"
import { STRINGS, getScaleSize } from "../constant"

//COMPONENTS
import { Button, Header, Text } from "../components"

//SCREENS
import { SCREENS } from "../screens"

function WifiDetails(props: any) {

    const { theme } = useContext(ThemeContext);

    const { logDetails } = useContext(ShipbookContext);

    function onNext() {
        logDetails("Next button clicked");
        props.navigation.navigate(SCREENS.FastMode.identifier);
    }
    function onCancel() {
        logDetails("Switch button clicked");
        props.navigation.navigate(SCREENS.BottomBar.identifier);
    }

    return (
        <View style={style(theme).rootContainer}>
            <Header
                title={STRINGS.wifi_details}
                onBack={() => { props.navigation.goBack() }} />
            <View style={style(theme).container}>
                <View style={style(theme).instruction}>
                    <Text
                        font={FONTS.Roboto.Bold}
                        color={theme._000}
                        size={getScaleSize(20)}>
                        {STRINGS.lets_get_your_wifi_details}
                    </Text>
                    <Text
                        font={FONTS.Roboto.Bold}
                        color={theme._000}
                        size={getScaleSize(20)}>
                        {STRINGS.please_ensure_your_wifi}
                    </Text>
                </View>
                <View style={style(theme).btnContainer}>
                    <Button
                        style={style(theme).btnGetStarted}
                        title={STRINGS.next}
                        onPress={() => onNext()}
                    />
                    <Button
                        style={style(theme).btnGetStarted}
                        title={STRINGS.cancel}
                        onPress={() => onCancel()}
                    />
                </View>
            </View>
            <SafeAreaView />
        </View>
    )
}

export default WifiDetails

const style = (theme: ThemeContextType['theme']) => StyleSheet.create({
    rootContainer: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    container: {
        flex: 1.0,
        paddingHorizontal: getScaleSize(24)
    },
    btnGetStarted: {
        marginBottom: getScaleSize(20)
    },
    instruction: {
        flex: 0.2,
        justifyContent: 'space-evenly',
        alignItems: 'center'
    },
    btnContainer: {
        flex: 0.75,
        justifyContent: 'flex-end'
    },
})
