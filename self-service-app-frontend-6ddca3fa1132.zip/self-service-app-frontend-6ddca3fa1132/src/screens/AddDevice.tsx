import React, { useContext, useRef, useState } from "react";
import { Dimensions, FlatList, Image, StyleSheet, TouchableOpacity, View } from "react-native";

//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { STRINGS, getScaleSize } from "../constant";
import { FONTS, IMAGES } from "../assets";

//COMPONENT
import { Header, Text, Button } from "../components";
import { SCREENS } from "../screens";


function AddDevice(props: any) {

  const { theme } = useContext(ThemeContext)
  const { logDetails } = useContext(ShipbookContext);

  const devicessData = [{ deviceName: STRINGS.smart_bulb, isSelected: false, image: IMAGES.smart_bulb, activeImage: IMAGES.active_smart_bulb }, { deviceName: STRINGS.smart_tv, isSelected: false, image: IMAGES.smart_TV, activeImage: IMAGES.smart_TV },
  { deviceName: STRINGS.smart_ac, isSelected: false, image: IMAGES.smart_ac, activeImage: IMAGES.smart_ac }, { deviceName: STRINGS.air_purifier, isSelected: false, image: IMAGES.air_purifier, activeImage: IMAGES.air_purifier },
  { deviceName: STRINGS.smart_camera, isSelected: false, image: IMAGES.smart_camera, activeImage: IMAGES.smart_camera }, { deviceName: STRINGS.smart_fan, isSelected: false, image: IMAGES.smart_fan, activeImage: IMAGES.smart_fan }]
  const [devices, setDevices] = useState(devicessData);
  

  const selectDevice = (selectedItemIndex: any) => {
    const itemsToSelect = devices.map((item, index) => {
      if (selectedItemIndex === index) {
        item.isSelected = !item.isSelected;
      } else {
        item.isSelected = false;
      }
      return item;
    }, []);

    setDevices(itemsToSelect);
  };
  function onContinue() {
    logDetails("Continue button clicked");
    props.navigation.navigate(SCREENS.AddBulb1.identifier);
  }

  return (
    <View style={styles(theme).container}>
      <Header
        title={STRINGS.add_device_header}
        onBack={() => { props.navigation.goBack() }} />
      <View style={styles(theme).deviceContainer}>
        <View style={styles(theme).detailContainer}>
          <View style={styles(theme).header}>
            <Text
              font={FONTS.Roboto.Bold}
              color={theme._333333}
              size={getScaleSize(20)}>
              {STRINGS.add_device_description}
            </Text>
          </View>
        </View>
        <FlatList
          data={devices}
          numColumns={2}
          ListFooterComponent={() => {
            return (
              <View style={styles(theme).buttonContainer}>
                <Button
                  title={STRINGS.continue}
                  onPress={() => onContinue()} />
                <TouchableOpacity onPress={() => { props.navigation.goBack() }} style={{ alignItems: 'center', marginTop: 20 }}>
                  <Text color={theme._AFAFAF}
                    font={FONTS.Roboto.Medium}
                    size={getScaleSize(18)}>
                    {STRINGS.cancel}
                  </Text>
                </TouchableOpacity>
              </View>
            )
          }}
          renderItem={({ item, index }) => {
            return (
              <TouchableOpacity onPress={() => { selectDevice(index) }} style={[styles(theme).deviceItem, { backgroundColor: item.isSelected ? theme.MAIN_THEME_COLOR : theme._F5F5F5 }]}>
                <View style={styles(theme).deviceIconContainer}>
                  <Image source={item.isSelected ? item.activeImage : item.image} />
                </View>
                <Text
                  font={FONTS.Roboto.Medium}
                  color={item.isSelected ? theme.TEXT_COLOR_AS_THEME : theme._828282}
                  size={getScaleSize(12)}>
                  {item.deviceName}
                </Text>
              </TouchableOpacity>
            )
          }} />

      </View>
    </View>
  )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
  container: {
    flex: 1.0,
    backgroundColor: theme._FFF,
  },
  detailContainer: {
    marginHorizontal: getScaleSize(30)
  },
  deviceContainer: { backgroundColor: '#fbfbfb', height: Dimensions.get('window').height },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',

    paddingTop: getScaleSize(15),
  },
  deviceItem: {
    width: (Dimensions.get('window').width - getScaleSize(60)) / 2,
    backgroundColor: theme._F5F5F5,
    paddingHorizontal: getScaleSize(12),
    paddingVertical: getScaleSize(12),
    marginLeft: getScaleSize(20),
    marginTop: getScaleSize(20),
    borderRadius: getScaleSize(12),
    justifyContent: 'center',
    alignItems: 'center'
  },
  deviceIconContainer: {
    // // height: getScaleSize(30),
    // // width: getScaleSize(30),
    // borderRadius: getScaleSize(15),
    // justifyContent: 'center',
    // alignItems: 'center',
    // backgroundColor: theme._FFF,
    marginBottom: getScaleSize(12)
  },
  buttonContainer: {
    marginTop: getScaleSize(70),
    marginHorizontal: getScaleSize(30)
  },
})


export default AddDevice