import Splash from './Splash'
import Leading from './Leading'
import Login from './Login'
import OtpVerification from './OtpVerification'
import BottomBar from './BottomBar'
import Recharge from './Recharge'
import AddBulb1 from './AddBulb1'
import AddBulb2 from './AddBulb2'
import NameDevice from './NameDevice'
import DeviceAdded from './DeviceAdded'
import AddDevice from './AddDevice'
import AssignRoom from './AssignRoom'
import ShareDataFrom from './ShareDataFrom'
import ShareDataConfirm from './ShareDataConfirm'
import SelectNumber from './SelectNumber'
import BorrowDataForm from './BorrowDataForm'
import BorrowDataConfirm from './BorrowDataConfirm'
import TelecomShare from './TelecomShare'
import TelecomBorrow from './TelecomBorrow'
import PrivacyPolicy from './PrivacyPolicy'
import TermsConditions from './TermsConditions'
import ShareAirtimeForm from './ShareAirtimeForm'
import ShareAirtimeConfirm from './ShareAirtimeConfirm'
import BorrowAirtimeForm from './BorrowAirtimeForm'
import BorrowAirtimeConfirm from './BorrowAirtimeConfirm'
import TransactionHistory from './TransactionHistory'
import BuyBundle from './BuyBundle'
import Shopping from './Shopping'
import ContactUs from './ContactUs'
import NewsDetails from './NewsDetails'
import PlayVideo from './PlayVideo'
import PayBill from './PayBill'
import Roaming from './Roaming'
import BuyFiberPlan from './BuyFiberPlan'
import MyFiberPlan from './MyFiberPlan'
import FastMode from './FastMode'
import SlowMode from './SlowMode'
import FastModeSearch from './FastModeSearch'
import SlowMode2 from './SlowMode2'
import SlowModeSearch from './SlowModeSearch'
import DeviceFound from './DeviceFound'
import FastMNotFound from './FastMNotFound'
import SlowMNotFound from './SlowMNotFound'
import WifiDetails from './WifiDetails'

export const SCREENS = {
    Splash: {
        identifier: 'Splash',
        component: Splash
    },
    Leading: {
        identifier: 'Leading',
        component: Leading
    },
    Login: {
        identifier: 'Login',
        component: Login
    },
    OtpVerification: {
        identifier: 'OtpVerification',
        component: OtpVerification
    },
    BottomBar: {
        identifier: 'BottomBar',
        component: BottomBar
    },
    Recharge: {
        identifier: 'Recharge',
        component: Recharge
    },
    AddBulb1: {
        identifier: 'AddBulb1',
        component: AddBulb1
    },
    AddBulb2: {
        identifier: 'AddBulb2',
        component: AddBulb2
    },
    NameDevice: {
        identifier: 'NameDevice',
        component: NameDevice
    },
    DeviceAdded: {
        identifier: 'DeviceAdded',
        component: DeviceAdded
    },
    AddDevice: {
        identifier: 'AddDevice',
        component: AddDevice
    },
    AssignRoom: {
        identifier: 'AssignRoom',
        component: AssignRoom
    },
    ShareDataFrom: {
        identifier: 'ShareDataFrom',
        component: ShareDataFrom
    },
    ShareDataConfirm: {
        identifier: 'ShareDataConfirm',
        component: ShareDataConfirm
    },
    SelectNumber: {
        identifier: 'SelectNumber',
        component: SelectNumber
    },
    BorrowDataForm: {
        identifier: 'BorrowDataForm',
        component: BorrowDataForm
    },
    BorrowDataConfirm: {
        identifier: 'BorrowDataConfirm',
        component: BorrowDataConfirm
    },
    TelecomShare: {
        identifier: 'TelecomShare',
        component: TelecomShare
    },
    TelecomBorrow: {
        identifier: 'TelecomBorrow',
        component: TelecomBorrow
    },
    PrivacyPolicy: {
        identifier: 'PrivacyPolicy',
        component: PrivacyPolicy
    },
    TermsConditions: {
        identifier: 'TermsConditions',
        component: TermsConditions
    },
    ShareAirtimeForm: {
        identifier: 'ShareAirtimeForm',
        component: ShareAirtimeForm
    },
    ShareAirtimeConfirm: {
        identifier: 'ShareAirtimeConfirm',
        component: ShareAirtimeConfirm
    },
    BorrowAirtimeForm: {
        identifier: 'BorrowAirtimeForm',
        component: BorrowAirtimeForm
    },
    BorrowAirtimeConfirm: {
        identifier: 'BorrowAirtimeConfirm',
        component: BorrowAirtimeConfirm
    },
    TransactionHistory: {
        identifier: 'TransactionHistory',
        component: TransactionHistory
    },
    BuyBundle: {
        identifier: 'BuyBundle',
        component: BuyBundle
    },
    Shopping: {
        identifier: 'Shopping',
        component: Shopping
    },
    ContactUs: {
        identifier: 'ContactUs',
        component: ContactUs
    },
    NewsDetails: {
        identifier: 'NewsDetails',
        component: NewsDetails
    },
    PlayVideo: {
        identifier: 'PlayVideo',
        component: PlayVideo
    },
    PayBill: {
        identifier: 'PayBill',
        component: PayBill
    },
    Roaming: {
        identifier: 'Roaming',
        component: Roaming
    },
    BuyFiberPlan: {
        identifier: 'BuyFiberPlan',
        component: BuyFiberPlan
    },
    MyFiberPlan: {
        identifier: 'MyFiberPlan',
        component: MyFiberPlan
    },
    FastMode: {
        identifier: 'FastMode',
        component: FastMode
    },
    SlowMode: {
        identifier: 'SlowMode',
        component: SlowMode
    },
    FastModeSearch: {
        identifier: 'FastModeSearch',
        component: FastModeSearch
    },
    SlowMode2: {
        identifier: 'SlowMode2',
        component: SlowMode2
    },
    SlowModeSearch: {
        identifier: 'SlowModeSearch',
        component: SlowModeSearch
    },
    DeviceFound: {
        identifier: 'DeviceFound',
        component: DeviceFound
    },  
    FastMNotFound: {
        identifier: 'FastMNotFound',
        component: FastMNotFound
    },
    SlowMNotFound: {
        identifier: 'SlowMNotFound',
        component: SlowMNotFound
    },
    WifiDetails: {
        identifier: 'WifiDetails',
        component: WifiDetails
    },
}