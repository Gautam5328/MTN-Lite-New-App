import React, { useContext, useEffect, useState } from "react";
import { FlatList, SafeAreaView, StyleSheet, TouchableOpacity, View } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//CONSTANT & UTILS
import { STRINGS, getScaleSize } from "../constant";
import { FONTS } from "../assets";

//COMPONENTS
import { Button, Header, Icons, Text } from "../components";


function SelectNumber(props: any) {

    const selectedItem = props?.route?.params?.selectedItem ?? null
    const ItemList = props?.route?.params?.msisdnList ?? null

    const [selectedNumber, setSelectedNumber] = useState<any>(selectedItem)
    const [msisdnList, setMsisdnList] = useState<any[]>(ItemList)

    const { theme } = useContext(ThemeContext)

    function onContinue() {
        props?.route?.params?.onSelect(selectedNumber);
        props.navigation.goBack()
    }

    return (
        <View style={styles(theme).container}>
            <Header
                title={STRINGS.select_number}
                onBack={() => { props.navigation.goBack() }} />
            <FlatList data={msisdnList}
                renderItem={({ item, index }) => {
                    return (

                        <TouchableOpacity style={styles(theme).numberItem}
                            onPress={() => setSelectedNumber(item)}>
                            <View style={styles(theme).userImage}>
                                <Text
                                    font={FONTS.Roboto.Bold}
                                    color={theme._333333}
                                    size={getScaleSize(16)}>
                                    {item?.customer_name?.charAt(0)}
                                </Text>
                            </View>
                            <View style={styles(theme).numberContainer}>
                                <Text
                                    font={FONTS.Roboto.Medium}
                                    color={theme._333333}
                                    size={getScaleSize(12)}>
                                    {item?.customer_name}
                                </Text>
                                <Text
                                    style={{ marginTop: getScaleSize(3) }}
                                    font={FONTS.Roboto.Medium}
                                    color={theme._333333}
                                    size={getScaleSize(12)}>
                                    {item?.msisdn}
                                </Text>
                            </View>
                            <Icons
                                name={selectedNumber?.msisdn == item?.msisdn ? 'checkbox-active' : 'checkbox-passive'}
                                color={selectedNumber?.msisdn == item?.msisdn ? theme.MAIN_THEME_COLOR : theme._D3D3D3}
                                size={15}
                                type='Fontisto' />
                        </TouchableOpacity>
                    )
                }} />
            <Button
                style={styles(theme).btnContinue}
                title={STRINGS.continue}
                onPress={() => onContinue()} />
            <SafeAreaView />
        </View>
    )
}


const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF
    },
    numberItem: {
        height: getScaleSize(70),
        borderBottomWidth: 1,
        borderColor: theme._F5F5F5,
        flexDirection: 'row',
        paddingHorizontal: getScaleSize(20),
        alignItems: 'center'
    },
    userImage: {
        backgroundColor: theme._F5F5F5,
        height: getScaleSize(40),
        width: getScaleSize(40),
        borderRadius: getScaleSize(20),
        justifyContent: 'center',
        alignItems: 'center'
    },
    numberContainer: {
        flex: 1.0,
        marginHorizontal: getScaleSize(12)
    },
    btnContinue: {
        marginVertical: getScaleSize(40),
        marginHorizontal: getScaleSize(24),
    },
})

export default SelectNumber