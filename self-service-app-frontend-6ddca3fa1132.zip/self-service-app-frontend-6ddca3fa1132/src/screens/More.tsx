import React, { useContext, useEffect, useState } from "react";
import { Image, SafeAreaView, StyleSheet, View } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//CONSTANT
import { STRINGS, Storage, getScaleSize } from "../constant";

//COMPONENT
import { Button, Text, Header, CustomItem } from "../components";
import Icons from "../components/Icons";

//PACKAGES
import { CommonActions } from "@react-navigation/native";

//SCREENS
import { SCREENS } from "../screens";

//ASSETS
import { FONTS, IMAGES } from "../assets";
import { useSelector } from "react-redux";
import { opratorLogo } from "../constant/utils";

function More(props: any) {

    const { theme, operator } = useContext(ThemeContext)

    const customerDetails = useSelector((state: any) => state.customerData);

    return (
        <View style={styles(theme).container}>

            <Header
                isHome
                onNotification={() => { }}
                onProfile={() => { }} />
            <View style={styles(theme).profileMainContainer}>
                <View style={styles(theme).profileContainer}>
                    <View style={styles(theme).profileImage}>
                        <Icons
                            name={'user'}
                            color={theme._D3D3D3}
                            type={'Feather'}
                            size={40} />
                    </View>
                    <View style={styles(theme).profileTextContainer}>
                        <Text
                            style={styles(theme).profileText}
                            font={FONTS.Roboto.Medium}
                            color={theme.TEXT_COLOR_AS_THEME}
                            size={getScaleSize(18)}>
                            {customerDetails?.customer?.name ?? ''}
                        </Text>
                        <Text
                            font={FONTS.Roboto.Medium}
                            color={theme.TEXT_COLOR_AS_THEME}
                            size={getScaleSize(14)}>
                            {customerDetails?.customer?.msisdns?.[0]?.msisdn ?? ''}
                        </Text>
                    </View>
                </View>
            </View>
            <View style={styles(theme).menuContainer}>
                <View style={styles(theme).detailContainer}>
                    <CustomItem iconName="share" iconType="MaterialIcons" title={STRINGS.share_airtime_data_header} onPress={() => { props.navigation.navigate(SCREENS.TelecomShare.identifier) }} />
                </View>

                <View style={styles(theme).detailContainer}>
                    <CustomItem iconName="currency-exchange" iconType="MaterialIcons" title={STRINGS.borrow_airtime_data_header} onPress={() => { props.navigation.navigate(SCREENS.TelecomBorrow.identifier) }} />
                </View>
                <View style={styles(theme).detailContainer}>
                    <CustomItem iconName="security" iconType="MaterialIcons" title={STRINGS.privacy_policy_header} onPress={() => { props.navigation.navigate(SCREENS.PrivacyPolicy.identifier) }} />
                </View>
                <View style={styles(theme).detailContainer}>
                    <CustomItem iconName="file-text-o" iconType="FontAwesome" title={STRINGS.terms_condiitons_header} onPress={() => { props.navigation.navigate(SCREENS.TermsConditions.identifier) }} />
                </View>
                <View style={styles(theme).detailContainer}>
                    <CustomItem iconName="file-text-o" iconType="FontAwesome" title={STRINGS.contact_us} onPress={() => { props.navigation.navigate(SCREENS.ContactUs.identifier) }} />
                </View>
                <View style={styles(theme).detailContainer}>
                    <CustomItem iconName="logout" iconType="MaterialIcons" title={STRINGS.logout} onPress={() => {
                        Storage.clear()

                        props.navigation.dispatch(
                            CommonActions.reset({
                                index: 0,
                                routes: [
                                    { name: SCREENS.Leading.identifier }
                                ],
                            })
                        );
                    }} />
                </View>
            </View>
            <SafeAreaView />
            <View style={styles(theme).versionContainer}>
                {/* <Image
                    style={styles(theme).versionLogo}
                    resizeMode="contain"
                    source={IMAGES.logo} /> */}
                <Image
                    style={[styles(theme).versionLogo, { height: opratorLogo(operator)?.height, width: opratorLogo(operator)?.width }]}
                    resizeMode="contain"
                    source={opratorLogo(operator)?.source} />
                <Text
                    font={FONTS.Roboto.Medium}
                    color={theme._AFAFAF}
                    size={getScaleSize(14)}>
                    {'Version 1.0.0'}
                </Text>
            </View>
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        // justifyContent: 'center',
        backgroundColor: theme._FFF,
    },
    profileMainContainer: {
        backgroundColor: theme.MAIN_THEME_COLOR,
        paddingTop: getScaleSize(20),
        paddingHorizontal: getScaleSize(20),
        marginBottom: getScaleSize(20),
        height: getScaleSize(100),
    },
    profileContainer: { flexDirection: 'row', },
    profileImage: {
        backgroundColor: theme._F5F5F5,
        borderColor: theme.MAIN_THEME_COLOR,
        borderWidth: getScaleSize(2),
        borderRadius: getScaleSize(50),
        height: getScaleSize(100), width: getScaleSize(100),
        alignItems: 'center',
        justifyContent: 'center'
    },
    profileTextContainer: {
        marginLeft: getScaleSize(20),
        justifyContent: 'center',
        paddingBottom: getScaleSize(10)
    },
    profileText: { marginBottom: getScaleSize(5) },
    menuContainer: { flex: 1 },
    detailContainer: {
        backgroundColor: theme._FFF,
        padding: getScaleSize(20),
        borderBottomColor: theme._F5F5F5,
        borderBottomWidth: getScaleSize(1),
    },
    versionContainer: {
        justifyContent: 'flex-end',
        alignItems: 'center',
        marginBottom: getScaleSize(20)
    },
    versionLogo: {
        height: getScaleSize(40),
        width: getScaleSize(80)
    }
})
export default More