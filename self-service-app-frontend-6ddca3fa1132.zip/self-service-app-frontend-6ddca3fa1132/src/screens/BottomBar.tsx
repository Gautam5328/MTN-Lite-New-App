import React from "react";
import View from 'react-native'

//SCREENS
import Home from './Home'
import SmartHome from "./SmartHome";
import Play from "./Play";
import More from "./More";

//PACKAGES
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

//COMPONENTS
import { Tabbar } from "../components";

const Tab = createBottomTabNavigator();

function BottomBar(props: any) {

    return (
        <Tab.Navigator screenOptions={{ headerShown: false }}
            tabBar={props => (
                <Tabbar {...props} />
            )}>
            <Tab.Screen name={'Home'} component={Home} />
            <Tab.Screen name={'SmartHome'} component={SmartHome} />
            <Tab.Screen name={'Play'} component={Play} />
            <Tab.Screen name={'More'} component={More} />
        </Tab.Navigator>
    )
}

export default BottomBar