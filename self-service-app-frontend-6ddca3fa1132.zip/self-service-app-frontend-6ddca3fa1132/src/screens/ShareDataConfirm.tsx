import React, { useContext, useEffect, useState } from "react";
import { SafeAreaView, StyleSheet, TouchableOpacity, View } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//CONSTANT & UTILS
import { STRINGS, formatRawMobileNumber, getScaleSize, showMessageToast } from "../constant";
import { FONTS } from "../assets";

//COMPONENTS
import { AlertModal, Button, Header, NumberBox, ProgressView, Text } from "../components";

//SCREENS
import { SCREENS } from "../screens";

//API
import { API } from "../api";
import { CommonActions } from "@react-navigation/native";


function ShareDataConfirm(props: any) {

    const [selectedData, setSelectedData] = useState<any>(props?.route?.params?.data??'')
    const [fromMsisdn, setFromMsisdn] = useState<any>(props?.route?.params?.frommsisdn??'')
    const [toMsisdn, setToMsisdn] = useState<any>(props?.route?.params?.tomsisdn??'')
    const [loading, setLoading] = useState(false);
    const [isAlertVisible, setAlertVisible] = useState(false);
    const [shareStatus, setShareStatus] = useState({ type: '', title: '', message: '' });

    const { theme } = useContext(ThemeContext)

    const buttonArray = [{ 'title': 'Ok', 'color': theme.MAIN_THEME_COLOR }]

    async function onContinue() {
        
        try {
            let sharedata='';
            if (selectedData) {
                sharedata = selectedData;
                if (sharedata.includes(' MB')) {
                    sharedata = sharedata.replace(' MB', "");
                } else if (sharedata.includes(' GB')) {
                    sharedata = sharedata.replace(' GB', "");
                    sharedata = (Number(sharedata) * 1024).toString();
                }
            }
            let params = {
                "data": sharedata,
                "from_msisdn": '+' + formatRawMobileNumber(fromMsisdn.msisdn),
                "to_msisdn": '+' + formatRawMobileNumber(toMsisdn.msisdn)
            };
            setLoading(true);
            const result = await API.transactionInstance.post('/share/data', params)
            setLoading(false)
            if (result.status == 200) {
                setShareStatus({ type: 'SUCCESS', 'message': 'Data has been shared successfully', 'title': STRINGS.payment_success })
                setAlertVisible(true);
            }
        }
        catch (error: any) {
            setLoading(false)
            setShareStatus({ type: 'FAIL', 'message': error?.message ?? '', 'title': 'Failed' })
            setAlertVisible(true);

        }
    }

    const okClick = async () => {
        setAlertVisible(false);
        props.navigation.dispatch(
            CommonActions.reset({
                index: 0,
                routes: [
                    { name: SCREENS.BottomBar.identifier }
                ],
            })
        );
    }

    return (
        <View style={styles(theme).container}>
            <Header
                title={STRINGS.share_data}
                onBack={() => { props.navigation.goBack() }} />
            <Text
                style={styles(theme).headerText}
                font={FONTS.Roboto.Bold}
                color={theme._000}
                size={getScaleSize(16)}>
                {STRINGS.confirm_your_share + STRINGS.share_data}
            </Text>
            <View style={styles(theme).detailContainer}>
                <Text
                    style={styles(theme).fromText}
                    font={FONTS.Roboto.Bold}
                    color={theme._828282}
                    size={getScaleSize(16)}>
                    {STRINGS.from}
                </Text>
                <NumberBox isDisable={true} item={fromMsisdn}/>
                <Text
                    style={styles(theme).toText}
                    font={FONTS.Roboto.Bold}
                    color={theme._828282}
                    size={getScaleSize(16)}>
                    {STRINGS.to}
                </Text>
                <NumberBox isDisable={true} item={toMsisdn}/>
                <Text
                    style={styles(theme).dataText}
                    font={FONTS.Roboto.Bold}
                    color={theme._828282}
                    size={getScaleSize(16)}>
                    {STRINGS.data}
                </Text>
                <View style={styles(theme).dataContainer}>
                    <View
                        style={styles(theme).selectedDataBox}>
                        <Text
                            font={FONTS.Roboto.Bold}
                            color={theme.TEXT_COLOR_AS_THEME}
                            size={getScaleSize(12)}>
                            {selectedData}
                        </Text>
                    </View>
                </View>
            </View>

            <View style={styles(theme).container} />
            <Button
                style={styles(theme).btnContinue}
                title={STRINGS.share}
                onPress={() => onContinue()} />
            <SafeAreaView />
            {loading && <ProgressView />}

            <AlertModal title={shareStatus.title}
                description={shareStatus.message}
                isVisible={isAlertVisible}
                imageType={shareStatus.type}
                actions={buttonArray}
                onClose={() => { setAlertVisible(false) }}
                onPress={(e: any, index: number) => {
                    if (index == 0) {
                        okClick()
                    }
                }}
            />
        </View>
    )
}


const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF
    },
    detailContainer: {
        backgroundColor: theme._F5F5F5,
        marginHorizontal: getScaleSize(24),
        marginVertical: getScaleSize(20),
        borderRadius: getScaleSize(20),
        padding: getScaleSize(20),
    },
    headerText: {
        marginHorizontal: getScaleSize(26),
        marginTop: getScaleSize(20),
    },
    fromText: {
        marginBottom: getScaleSize(10),
    },
    toText: {
        marginTop: getScaleSize(10),
        marginBottom: getScaleSize(10),
    },
    dataText: {
        marginTop: getScaleSize(10),
        marginBottom: getScaleSize(2),
    },
    dataContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    dataBox: {
        marginTop: getScaleSize(8),
        marginLeft: getScaleSize(8),
        paddingHorizontal: getScaleSize(8),
        paddingVertical: getScaleSize(4),
        backgroundColor: theme._F5F5F5,
        borderRadius: getScaleSize(8),
    },
    selectedDataBox: {
        marginTop: getScaleSize(8),
        paddingHorizontal: getScaleSize(8),
        paddingVertical: getScaleSize(4),
        backgroundColor: theme.MAIN_THEME_COLOR,
        borderRadius: getScaleSize(8),
    },
    btnContinue: {
        marginVertical: getScaleSize(40),
        marginHorizontal: getScaleSize(24),
    }
})

export default ShareDataConfirm