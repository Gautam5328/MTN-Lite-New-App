import React, { useContext, useEffect, useState } from "react";
import { FlatList, SafeAreaView, StyleSheet, TouchableOpacity, View } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//PACKAGES
import WebView from "react-native-webview";

//COMPONENTS
import { Header } from "../components";

//CONSTANTS
import { getScaleSize } from "../constant";


function NewsDetails(props: any) {

    const url = props?.route?.params?.url ?? null

    const { theme } = useContext(ThemeContext)

    return (
        <View style={styles(theme).container}>

            <Header
                title={''}
                onBack={() => { props.navigation.goBack() }}
            />
            <WebView source={{ uri: url }} style={styles(theme).webviewContainer} onError={(error:any)=>{
            }}/>
            <SafeAreaView />
        </View>
    )
}


const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF
    },
    webviewContainer:{
        flex:1,
        // marginHorizontal:getScaleSize(24)
    }
})

export default NewsDetails