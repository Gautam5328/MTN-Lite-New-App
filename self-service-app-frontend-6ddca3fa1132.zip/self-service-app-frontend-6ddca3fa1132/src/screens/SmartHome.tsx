import React, { useContext, useRef, useState } from "react";
import { Dimensions, FlatList, Image, StyleSheet, TouchableOpacity, View } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { STRINGS, getScaleSize } from "../constant";
import { FONTS, IMAGES } from "../assets";

//COMPONENT
import { Header, Text, WatherCard } from "../components";


function SmartHome(props: any) {

    const { theme } = useContext(ThemeContext)

    const menulistRef = useRef<FlatList>(null);

    const [selectedMenu, setSelectedMenu] = useState<number>(0)

    return (
        <View style={styles(theme).container}>
            <Header
                isHome
                onNotification={() => { }}
                onProfile={() => { }} />
            <View style={styles(theme).detailContainer}>
                <View style={styles(theme).header}>
                    <Text
                        font={FONTS.Roboto.Black}
                        color={theme._828282}
                        size={getScaleSize(16)}>
                        {"John's Home"}
                    </Text>
                    <TouchableOpacity onPress={() => { props.navigation.navigate("WifiDetails") }} style={styles(theme).addDeviceContainer}>
                        <Image style={styles(theme).addDeviceIcon} source={IMAGES.ic_add_device} />
                        <Text
                            font={FONTS.Roboto.Medium}
                            color={theme._828282}
                            size={getScaleSize(14)}>
                            {"Add Device"}
                        </Text>
                    </TouchableOpacity>
                </View>
                <WatherCard />
            </View>
            <View style={styles(theme).deviceMenuContainer}>
                <FlatList
                    data={['All', 'Living Room', 'Bed Room', 'Kitchen', 'Child Room', 'Storage Room']}
                    horizontal={true}
                    ref={menulistRef}
                    ListHeaderComponent={() => <View style={{ width: getScaleSize(20) }} />}
                    ListFooterComponent={() => <View style={{ width: getScaleSize(20) }} />}
                    showsHorizontalScrollIndicator={false}
                    renderItem={({ item, index }) => {
                        return (
                            <TouchableOpacity style={styles(theme).deviceMenuItem}
                                onPress={() => {
                                    setSelectedMenu(index)
                                    menulistRef?.current?.scrollToIndex({ index: index, viewPosition: 0.5 })
                                }}>
                                <Text
                                    font={FONTS.Roboto.Medium}
                                    color={theme._828282}
                                    size={getScaleSize(14)}>
                                    {item}
                                </Text>
                                {selectedMenu == index &&
                                    <View style={styles(theme).deviceMenuDevider} />
                                }
                            </TouchableOpacity>
                        )
                    }} />
            </View>
            <FlatList
                data={["Smart Lighting", "Smart TV", "Smart AC", "Air Purifier"]}
                numColumns={2}
                ListFooterComponent={() => {
                    return (
                        <View style={styles(theme).listFotter}>
                            <TouchableOpacity onPress={() => { props.navigation.navigate("AssignRoom") }} style={styles(theme).addDeviceContainer}>
                                <Image style={styles(theme).addDeviceIcon} source={IMAGES.ic_add_device} />
                                <Text
                                    font={FONTS.Roboto.Medium}
                                    color={theme._828282}
                                    size={getScaleSize(14)}>
                                    {"Add a Room"}
                                </Text>
                            </TouchableOpacity>
                        </View>
                    )
                }}
                renderItem={({ item, index }) => {
                    return (
                        <View style={styles(theme).deviceItem}>
                            <View style={styles(theme).deviceIconContainer}>
                                <Image style={styles(theme).deviceIcon} source={IMAGES.ic_tab_smart_home} />
                            </View>
                            <Text
                                font={FONTS.Roboto.Medium}
                                color={theme._828282}
                                size={getScaleSize(12)}>
                                {item}
                            </Text>
                            <Text
                                style={{ marginTop: getScaleSize(3) }}
                                font={FONTS.Roboto.Regular}
                                color={theme._828282}
                                size={getScaleSize(10)}>
                                {'4 Lamps'}
                            </Text>
                            <View style={styles(theme).devider} />
                            <TouchableOpacity style={styles(theme).deviceItemFooter}>
                                <Text
                                    font={FONTS.Roboto.Medium}
                                    color={theme._828282}
                                    size={getScaleSize(12)}>
                                    {'On'}
                                </Text>
                                <Image
                                    style={styles(theme).deviceStatusSwitch}
                                    source={IMAGES.on_switch} />
                            </TouchableOpacity>
                        </View>
                    )
                }} />
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    detailContainer: {
        backgroundColor: theme._FFF,
        marginHorizontal: getScaleSize(20)
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: getScaleSize(24)
    },
    addDeviceContainer: {
        flexDirection: 'row',
        alignItems: 'center'
    },
    addDeviceIcon: {
        height: getScaleSize(15),
        width: getScaleSize(15),
        marginRight: getScaleSize(5)
    },
    deviceMenuContainer: {
        paddingTop: getScaleSize(16),
        paddingBottom: getScaleSize(4),
    },
    deviceMenuItem: {
        paddingVertical: getScaleSize(2),
        alignItems: 'center',
        marginRight: getScaleSize(12)
    },
    deviceMenuDevider: {
        height: getScaleSize(2),
        borderRadius: getScaleSize(2),
        marginTop: getScaleSize(2),
        width: '40%',
        backgroundColor: theme.MAIN_THEME_COLOR
    },
    deviceItem: {
        width: (Dimensions.get('window').width - getScaleSize(60)) / 2,
        backgroundColor: theme._F7F7F7,
        paddingHorizontal: getScaleSize(12),
        paddingTop: getScaleSize(12),
        marginLeft: getScaleSize(20),
        marginTop: getScaleSize(12),
        borderRadius: getScaleSize(12),
    },
    deviceIconContainer: {
        height: getScaleSize(30),
        width: getScaleSize(30),
        borderRadius: getScaleSize(15),
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: theme._FFF,
        marginBottom: getScaleSize(12)
    },
    deviceIcon: {
        height: getScaleSize(15),
        width: getScaleSize(15),
        tintColor: theme.MAIN_THEME_COLOR
    },
    deviceItemFooter: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    deviceStatusSwitch: {
        height: getScaleSize(30),
        width: getScaleSize(30)
    },
    devider: {
        height: 1,
        backgroundColor: 'rgba(0,0,0,0.1)',
        marginTop: getScaleSize(12),
    },
    listFotter: {
        marginVertical: getScaleSize(12),
        alignItems: 'flex-end',
        marginHorizontal: getScaleSize(20)
    }
})


export default SmartHome