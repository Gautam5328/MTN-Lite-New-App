import React, { useContext, useRef, useState, useEffect } from 'react';
import { StyleSheet, View, StatusBar, TouchableOpacity, Text, SafeAreaView } from 'react-native';
//Packages
import Video from 'react-native-video';
import Orientation from 'react-native-orientation-locker';
import { useNavigation } from '@react-navigation/native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Slider from '@react-native-community/slider';
import SystemNavigationBar from 'react-native-system-navigation-bar';

// Constants
import { getScaleSize } from '../constant';

// Context
import { ThemeContext, ThemeContextType } from '../context';
//Components
import { ProgressView, VideoComponent } from '../components';

const PlayVideo = (props: any) => {
    const { theme } = useContext(ThemeContext);
    const videoRef = useRef<Video>(null);
    const navigation = useNavigation();
    const [loading, setLoading] = useState(true);
    const [volume, setVolume] = useState(1);

    const url = props?.route?.params?.url ?? null;

    useEffect(() => {
        StatusBar.setHidden(true);
        Orientation.lockToLandscape();
        // SystemNavigationBar.navigationHide();
        SystemNavigationBar.fullScreen(true);
        return () => {
            Orientation.lockToPortrait();
            StatusBar.setHidden(false);
            // SystemNavigationBar.navigationShow();
            SystemNavigationBar.fullScreen(false);
        };
    }, []);

    const onLoad = () => {
        setLoading(false);
    };

    const onBackPress = () => {
        Orientation.lockToPortrait();
        // SystemNavigationBar.navigationShow();
        SystemNavigationBar.fullScreen(false);
        // navigation.goBack();
        setTimeout(() => {
            navigation.goBack();
        }, 1000);
    };

    const onSliderValueChange = (value: number) => {
        setVolume(value);
    };

    const onSliderSlidingComplete = (value: number) => {
        if (videoRef.current) {
            // On sliding completion, set the volume directly
            videoRef.current.setNativeProps({ volume: value });
        }
    };

    return (
        <View style={style(theme).rootContainer}>
            <VideoComponent uri={url}/>
            {/* <Video
                ref={videoRef}
                source={{ uri: url }}
                style={style(theme).videoFullScreen}
                controls
                resizeMode='cover'
                onLoad={onLoad}
                volume={volume} // Set initial volume
            />
            {loading && <ProgressView />} */}
            <TouchableOpacity style={style(theme).backButton} onPress={onBackPress}>
                <Ionicons name='arrow-back' size={22} color={theme._FFF} />
            </TouchableOpacity>
            <View style={style(theme).audioSliderContainer}>
                {/* <Slider
                    style={style(theme).audioSlider}
                    minimumValue={0}
                    maximumValue={1}
                    value={volume}
                    onValueChange={onSliderValueChange}
                    onSlidingComplete={onSliderSlidingComplete}
                    thumbTintColor={theme._FFF}
                    minimumTrackTintColor={theme._FFF}
                    maximumTrackTintColor={theme._FFF}
                    vertical  // Set the slider to vertical mode
                    thumbTouchSize={{ width: 40, height: 40 }}  // Increase the touch area
                /> */}
            </View>
            <SafeAreaView />
        </View>
    );
};

export default PlayVideo;

const style = (theme: ThemeContextType['theme']) =>
    StyleSheet.create({
        rootContainer: {
            backgroundColor: theme._000,
            flex: 1.0,
            // justifyContent: 'center',
            // alignItems: 'center',
        },
        videoFullScreen: {
            // ...StyleSheet.absoluteFillObject,
            marginRight: 50,
            width: '100%',
            height: '100%',
        },
        loaderContainer: {
            ...StyleSheet.absoluteFillObject,
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
        },
        backButton: {
            position: 'absolute',
            top: 25,
            left: 15,
            zIndex: 1,
        },
        audioSliderContainer: {
            position: 'absolute',
            bottom: '35%',
            left: -10,
            right: 0,
            zIndex: 1,
        },
        audioSlider: {
            width: 120,
            height: 100,
            transform: [{ rotate: '270deg' }],
        },
    });
