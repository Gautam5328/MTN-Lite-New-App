import { View, TouchableOpacity, StyleSheet, Image, SafeAreaView } from 'react-native'
import React, { useContext, useState } from 'react'
//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context"

//ASSETS & CONSTANT
import { FONTS, IMAGES } from "../assets"
import { STRINGS, getScaleSize } from "../constant"

//COMPONENTS
import { Button, Header, Text } from "../components"

//SCREENS
import { SCREENS } from "../screens"

//PACKAGES
import ProgressCircle from 'react-native-progress-circle'

function FastModeSearch(props: any) {

    const { theme } = useContext(ThemeContext);

    const { logDetails } = useContext(ShipbookContext);

    function onCancel() {
        logDetails("Continue button clicked");
        props.navigation.navigate(SCREENS.FastMode.identifier);
    }

    return (
        <View style={style(theme).rootContainer}>
            <Header
                title={STRINGS.fast_mode}
                onBack={() => { props.navigation.goBack() }} />
            <View style={style(theme).container}>
                <View style={style(theme).progressContainer}>
                    <ProgressCircle
                        percent={20}
                        radius={70}
                        borderWidth={8}
                        color={theme._3399FF}
                        shadowColor={theme._D3D3D3}
                        bgColor={theme._FFF}
                    >
                        <Text
                            font={FONTS.Roboto.Bold}
                            color={theme._000}
                            size={getScaleSize(20)}>
                            {STRINGS.twenty}
                        </Text>
                    </ProgressCircle>
                </View>
                <View style={style(theme).headContainer}>
                    <Text
                        font={FONTS.Roboto.Bold}
                        color={theme._000}
                        size={getScaleSize(21)}>
                        {STRINGS.searching_for_device}
                    </Text>
                </View>
                <View style={style(theme).btnContainer}>
                    <Button
                        style={style(theme).btnGetStarted}
                        title={STRINGS.cancel}
                        onPress={() => onCancel()}
                    />
                </View>
                <SafeAreaView />
            </View>
        </View>
    )
}

export default FastModeSearch

const style = (theme: ThemeContextType['theme']) => StyleSheet.create({

    rootContainer: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    container: {
        paddingHorizontal: getScaleSize(24),
        flex: 1.0
    },
    subtitle: {
        alignSelf: 'center'
    },
    btnGetStarted: {
        marginBottom: getScaleSize(30)
    },
    progressContainer: {
        justifyContent: 'flex-end',
        alignItems: 'center',
        flex: 0.3
    },
    headContainer: {
        flex: 0.2,
        justifyContent: 'center',
        alignItems: 'center'
    },
    btnContainer: {
        justifyContent: 'flex-end',
        flex: 0.4
    },

})