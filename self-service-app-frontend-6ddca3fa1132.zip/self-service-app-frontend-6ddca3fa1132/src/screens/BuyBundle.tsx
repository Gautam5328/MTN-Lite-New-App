import React, { useContext, useEffect, useState } from "react";
import { FlatList, SafeAreaView, StyleSheet, View } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { STRINGS, formatRawMobileNumber, getScaleSize, showMessageToast } from "../constant";

//COMPONENT
import { AlertModal, BundleCard, Header, PaymentOptionModal, ProgressView, Text, VoucherModal } from "../components";

//API
import { API } from "../api";

//PACKAGES
import { StripeProvider, useStripe } from "@stripe/stripe-react-native"
import { CommonActions } from "@react-navigation/native";
import { useSelector } from "react-redux";
import _ from 'lodash';

//SCREENS
import { SCREENS } from "../screens";
import { FONTS } from "../assets";


function BuyBundle(props: any) {

    const customerDetails = useSelector((state: any) => state.customerData);

    const { theme } = useContext(ThemeContext)

    const { initPaymentSheet, presentPaymentSheet } = useStripe();

    const [loading, setLoading] = useState(false);
    const [bundleList, setBundleList] = useState<any[]>([])
    const [selectedBundle, setSelectedBundle] = useState<any>()
    const [isAlertVisible, setAlertVisible] = useState(false);
    const [paymentStatus, setPaymentStatus] = useState({ type: '', title: '', message: '' });
    const [showPaymentOptions, setShowPaymentOptions] = useState(false);
    const [showVoucherModal, setShowVoucherModal] = useState(false);
    const [showErrorMessage, setShowErrorMessage] = useState(false);

    const buttonArray = [{ 'title': 'Ok', 'color': theme.MAIN_THEME_COLOR }]

    const initializePaymentSheet = async (intent: any) => {
        const { payment_intent, ephemeral_key, customer_id, publishable_key } =
            intent;
        const { error } = await initPaymentSheet({
            merchantDisplayName: "Telecom",
            customerId: customer_id,
            customerEphemeralKeySecret: ephemeral_key?.secret,
            paymentIntentClientSecret: payment_intent,
            allowsDelayedPaymentMethods: true,
            defaultBillingDetails: {
                name: "Jane Doe",
            },
        });


        if (!error) {
            setLoading(true);
        } else {
            showMessageToast(error?.message ?? '')
        }
    };

    useEffect(() => {
        getBundleData();
    }, [])

    const getBundleData = async () => {
        try {
            setLoading(true);
            const result = await API.transactionInstance.get('/plans/list')
            setLoading(false)
            if (result.status == 200) {
                if (result?.data) {
                    const planList = result?.data?.allPlans ?? []
                    const array = planList.map((e: any) => {
                        var output1 = Object.entries(e).map(([key, value]) => ({ title: key, data: value }));
                        return output1[0]
                    })
                    var planData = _.filter(array, function (o) {
                        return o.title != 'Fiber';
                    });
                    setBundleList(planData)
                }
            }
        }
        catch (error: any) {
            setLoading(false)
            showMessageToast(error?.message ?? '')
        }
    }
    const buyBundlebyCard = async () => {
        try {
            let params = {
                "amount": Number(selectedBundle?.price),
                "currency": STRINGS.currencyCode,
                "msisdn": '+' + formatRawMobileNumber(props?.route?.params?.msisdn),
                "product_id": selectedBundle?.product_id,
            };
            setLoading(true);
            const result = await API.transactionInstance.post('/customer/recharge/bundle/by-card', params)

            initializePaymentSheet(result?.data);
            setTimeout(async () => {
                const { error } = await presentPaymentSheet();
                if (error) {
                    if (error.message == "The payment flow has been canceled") {
                        setPaymentStatus({ type: 'FAIL', 'message': error.message, 'title': STRINGS.payment_canceled })
                    } else {
                        setPaymentStatus({ type: 'FAIL', 'message': error.message, 'title': STRINGS.payment_failed })
                    }

                    setShowPaymentOptions(false)
                    setAlertVisible(true);
                    setLoading(false);
                } else {
                    setPaymentStatus({ type: 'SUCCESS', 'message': STRINGS.buy_bundle_success, 'title': STRINGS.payment_success })

                    setShowPaymentOptions(false)
                    setAlertVisible(true);
                    setLoading(false);
                }
            }, 1000);

        }
        catch (error: any) {
            setShowPaymentOptions(false)
            setLoading(false)
            showMessageToast(error?.message ?? '')
        }

    }
    const buyBundlebyVoucher = async(item:any) => {
        try {
            let params = {
                "voucher": item,
                "msisdn": '+' + formatRawMobileNumber(props?.route?.params?.msisdn),
                "product_id": selectedBundle?.product_id,
            };
            setLoading(true);
            const result = await API.transactionInstance.post('/customer/recharge/bundle/by-voucher', params)
            if (result.status == 200) {
                setPaymentStatus({ type: 'SUCCESS', 'message': result?.data?.message, 'title': STRINGS.payment_success })
                setAlertVisible(true);
            }
            setLoading(false)
            setShowPaymentOptions(false);
        }
        catch (error: any) {
            setLoading(false)
            setShowPaymentOptions(false)
            showMessageToast(error?.message ?? '')
        }
    }
    const buyBundlebyAirtime = async(frommsisdn: any) => {
        try {

            let params = {
                "to_msisdn": '+' + formatRawMobileNumber(props?.route?.params?.msisdn),
                "from_msisdn": '+' + formatRawMobileNumber(frommsisdn?.msisdn),
                "product_id": selectedBundle?.product_id,
            };
            setLoading(true);
            const result = await API.transactionInstance.post('/customer/recharge/bundle/by-airtime', params)
            if (result.status == 200) {
                setPaymentStatus({ type: 'SUCCESS', 'message': result?.data?.message, 'title': STRINGS.payment_success })
                setAlertVisible(true);
            }
            setLoading(false)
            setShowPaymentOptions(false);
        }
        catch (error: any) {
            setLoading(false)
            setShowPaymentOptions(false)
            showMessageToast(error?.message ?? '')
        }
    }
    const onContinue = async () => {
        setShowPaymentOptions(true);
    }

    const okClick = async () => {
        setAlertVisible(false);
        props.navigation.dispatch(
            CommonActions.reset({
                index: 0,
                routes: [
                    { name: SCREENS.BottomBar.identifier }
                ],
            })
        );
    }

    return (

        <StripeProvider publishableKey="pk_test_51OFd0jL4Cr6vAwq9tFeceN6CXG8DsaeVgkwPumExbc3tpPl3P459OzQ7qHBWli3piR4O6vINgIfCyuqwr3Xl1RiD00jFscF7YQ">
            <View style={styles(theme).container}>
                <Header
                    title={STRINGS.buy_bundle}
                    onBack={() => { props.navigation.goBack() }} />
                <View style={styles(theme).detailContainer}>
                    {bundleList.map((category, index) => (
                        <View key={index}>
                            <Text font={FONTS.Roboto.Bold} color={theme._000} size={getScaleSize(20)}>
                                {category.title}
                            </Text>
                            <FlatList
                                data={category.data}
                                renderItem={({ item, index }) => {
                                    return (
                                        <BundleCard
                                            plan_name={item['plan_name']}
                                            plan_description={item['plan_description']}
                                            price={item['price'] / 100}
                                            onPress={() => {
                                                setSelectedBundle(item);
                                                onContinue()
                                            }} />
                                    )
                                }} />
                        </View>

                    ))}
                </View>
                <SafeAreaView />

                {loading && <ProgressView />}

                <AlertModal title={paymentStatus.title}
                    description={paymentStatus.message}
                    isVisible={isAlertVisible}
                    imageType={paymentStatus.type}
                    actions={buttonArray}
                    onClose={() => { setAlertVisible(false) }}
                    onPress={(e: any, index: number) => {
                        if (index == 0) {
                            okClick()
                        }
                    }}
                />
                <PaymentOptionModal
                    visible={showPaymentOptions}
                    onClose={() => { setShowPaymentOptions(false) }}
                    onPress={(item: any, index: number) => {
                        if (index == 0) {
                            buyBundlebyCard()
                        } else if (index == 1) {
                            setShowVoucherModal(true)
                        }
                        else if (index == 2) {
                            if (customerDetails?.customer?.msisdns?.length > 0) {
                                props.navigation.navigate(SCREENS.SelectNumber.identifier, {
                                    selectedItem: customerDetails?.customer?.msisdns?.[0] ?? {},
                                    msisdnList: customerDetails?.customer?.msisdns ?? [],
                                    onSelect: (item: any) => {
                                        buyBundlebyAirtime(item)
                                    }
                                })
                            } else {
                                showMessageToast("You don't have any valid msisdn")
                            }
                        }
                    }}
                />

                <VoucherModal
                    visible={showVoucherModal}
                    errorMessage={showErrorMessage}
                    onClose={() => { setShowVoucherModal(false) }}
                    onPress={(item: any) => {
                        if (!item) {
                            setShowErrorMessage(true)
                            return;
                        }
                        setShowPaymentOptions(false);
                        setShowErrorMessage(false)
                        setShowVoucherModal(false);
                        buyBundlebyVoucher(item);
                    }} />
            </View>
        </StripeProvider>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    detailContainer: {
        flex: 1,
        marginHorizontal: getScaleSize(24),
    },
})


export default BuyBundle