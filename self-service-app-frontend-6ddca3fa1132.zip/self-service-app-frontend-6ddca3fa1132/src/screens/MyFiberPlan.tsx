import React, { useContext, useEffect, useState } from "react";
import { StyleSheet, View, FlatList, SafeAreaView, Dimensions, ScrollView } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { STRINGS, formatRawMobileNumber, formatToDecimalNumber, getScaleSize, showMessageToast } from "../constant";
import { FONTS } from "../assets";

//API
import { API } from "../api";

//COMPONENT
import { AlertModal, BundleCard, Header, PaymentOptionModal, ProgressView, Text, VoucherModal } from "../components";

//SCREENS
import { SCREENS } from "../screens";

//PACKAGES
import { useSelector } from "react-redux";
import moment from "moment";
import { initPaymentSheet, presentPaymentSheet } from "@stripe/stripe-react-native";
import _ from 'lodash'
import { CommonActions } from "@react-navigation/native";

function MyFiberPlan(props: any) {

    const { theme } = useContext(ThemeContext)

    const customerDetails = useSelector((state: any) => state.customerData);

    const msisdndetails = customerDetails?.customer?.msisdns?.[0];

    const buttonArray = [{ 'title': 'Ok', 'color': theme.MAIN_THEME_COLOR }]

    const [loading, setLoading] = useState(false);
    const [fiberPlanList, setFiberPlanList] = useState<any[]>(customerDetails?.customer?.fiber_data ?? [])
    const [planList, setPlanList] = useState<any[]>([])
    const [selectedPlan, setSelectedPlan] = useState<any>()
    const [isAlertVisible, setAlertVisible] = useState(false);
    const [paymentStatus, setPaymentStatus] = useState({ type: '', title: '', message: '' });
    const [showPaymentOptions, setShowPaymentOptions] = useState(false);
    const [showVoucherModal, setShowVoucherModal] = useState(false);
    const [showErrorMessage, setShowErrorMessage] = useState(false);

    const initializePaymentSheet = async (intent: any) => {
        const { payment_intent, ephemeral_key, customer_id, publishable_key } = intent;

        const { error } = await initPaymentSheet({
            merchantDisplayName: "Example, Inc.",
            customerId: customer_id,
            customerEphemeralKeySecret: ephemeral_key?.secret,
            paymentIntentClientSecret: payment_intent,
            allowsDelayedPaymentMethods: true,
            defaultBillingDetails: {
                name: "Jane Doe",
            },
        });

        if (!error) {
            setLoading(true);
        } else {
            showMessageToast(error?.message ?? '')
        }
    };

    useEffect(() => {
        getPlanData();
    }, [])

    const getPlanData = async () => {
        try {
            setLoading(true);
            const result = await API.transactionInstance.get('/plans/list')
            setLoading(false)
            if (result.status == 200) {
                if (result?.data) {
                    const planList = result?.data?.allPlans ?? []
                    const array = planList.map((e: any) => {
                        var output1 = Object.entries(e).map(([key, value]) => ({ title: key, data: value }));
                        return output1[0]
                    })
                    var planData = _.filter(array, function (o) {
                        return o.title == 'Fiber';
                    });
                    setPlanList(planData)
                }
            }
        }
        catch (error: any) {
            setLoading(false)
            showMessageToast(error?.message ?? '')
        }
    }

    const buyFiberPlanbyCard = async () => {
        try {
            let params = {
                "amount": Number(selectedPlan?.price),
                "currency": "USD",
                "msisdn": props?.route?.params?.fiber_id,
                "product_id": selectedPlan?.product_id,
            };
            setLoading(true);
            const result = await API.transactionInstance.post('/customer/recharge/bundle/by-card', params)

            initializePaymentSheet(result?.data);
            setTimeout(async () => {
                const { error } = await presentPaymentSheet();
                if (error) {
                    if (error.message == "The payment flow has been canceled") {
                        setPaymentStatus({ type: 'FAIL', 'message': error.message, 'title': STRINGS.payment_canceled })
                    } else {
                        setPaymentStatus({ type: 'FAIL', 'message': error.message, 'title': STRINGS.payment_failed })
                    }

                    setShowPaymentOptions(false)
                    setAlertVisible(true);
                    setLoading(false);
                } else {
                    setPaymentStatus({ type: 'SUCCESS', 'message': STRINGS.buy_fiberPlan_success, 'title': STRINGS.payment_success })

                    setShowPaymentOptions(false)
                    setAlertVisible(true);
                    setLoading(false);
                }
            }, 1000);

        }
        catch (error: any) {
            setShowPaymentOptions(false)
            setLoading(false)
            showMessageToast(error?.message ?? '')
        }

    }
    const buyFiberPlanbyVoucher = async (item: any) => {
        try {
            let params = {
                "voucher": item,
                "msisdn": props?.route?.params?.fiber_id,
                "product_id": selectedPlan?.product_id,
            };
            setLoading(true);
            const result = await API.transactionInstance.post('/customer/recharge/bundle/by-voucher', params)
            if (result.status == 200) {
                setPaymentStatus({ type: 'SUCCESS', 'message': result?.data?.message, 'title': STRINGS.payment_success })
                setAlertVisible(true);
            }
            setLoading(false)
            setShowPaymentOptions(false);
        }
        catch (error: any) {
            setLoading(false)
            setShowPaymentOptions(false)
            showMessageToast(error?.message ?? '')
        }
    }

    const buyFiberPlanbyAirtime = async (frommsisdn: any) => {
        try {

            let params = {
                "to_msisdn": props?.route?.params?.fiber_id,
                "from_msisdn": '+' + formatRawMobileNumber(frommsisdn?.msisdn),
                "product_id": selectedPlan?.product_id,
            };
            setLoading(true);
            const result = await API.transactionInstance.post('/customer/recharge/bundle/by-airtime', params)
            if (result.status == 200) {
                setPaymentStatus({ type: 'SUCCESS', 'message': result?.data?.message, 'title': STRINGS.payment_success })
                setAlertVisible(true);
            }
            setLoading(false)
            setShowPaymentOptions(false);
        }
        catch (error: any) {
            setLoading(false)
            setShowPaymentOptions(false)
            showMessageToast(error?.message ?? '')
        }
    }

    const onContinue = async () => {
        setShowPaymentOptions(true);
    }

    const okClick = async () => {
        setAlertVisible(false);
        props.navigation.dispatch(
            CommonActions.reset({
                index: 0,
                routes: [
                    { name: SCREENS.BottomBar.identifier }
                ],
            })
        );
    }

    return (
        <View style={styles(theme).container}>
            <Header
                title={STRINGS.buy_fiberplan}
                onBack={() => { props.navigation.goBack() }} />
            <ScrollView showsVerticalScrollIndicator={false} nestedScrollEnabled={true}>
                <View style={styles(theme).headerView}>
                    <Text
                        font={FONTS.Roboto.Medium}
                        color={theme._000}
                        size={getScaleSize(16)}>
                        {STRINGS.current_plans}
                    </Text>
                </View>
                {fiberPlanList?.map((item, index) => {
                    return (
                        <View
                            key={index}
                            style={styles(theme).fiberPlanBox}>
                            <View>
                                <Text
                                    style={{ marginBottom: getScaleSize(4) }}
                                    font={FONTS.Roboto.Medium}
                                    color={theme.MAIN_THEME_COLOR}
                                    size={getScaleSize(12)}>
                                    {item?.fiber_id ?? ''}
                                </Text>
                                <Text
                                    style={{ marginBottom: getScaleSize(8) }}
                                    font={FONTS.Roboto.Bold}
                                    color={theme.SUB_TEXT_COLOR_AS_THEME}
                                    size={getScaleSize(14)}>
                                    {item?.fiber_name ?? ''}
                                </Text>
                                <Text
                                    font={FONTS.Roboto.Medium}
                                    color={theme.SUB_TEXT_COLOR_AS_THEME}
                                    size={getScaleSize(10)}>
                                    {'Expired on ' + moment.unix(item?.validity).format("DD MMM YYYY")}
                                </Text>
                            </View>
                            <Text
                                font={FONTS.Roboto.Medium}
                                color={theme.TEXT_COLOR_AS_THEME}
                                size={getScaleSize(14)}>
                                {STRINGS.currency + `${formatToDecimalNumber(item?.price)}`}
                            </Text>
                        </View>
                    )
                })}
                <View style={styles(theme).headerView}>
                    <Text
                        style={{ marginTop: getScaleSize(10) }}
                        font={FONTS.Roboto.Medium}
                        color={theme._000}
                        size={getScaleSize(16)}>
                        {STRINGS.buy_fiberplan}
                    </Text>
                </View>
                {planList.map((category, index) => (
                    <View key={index}>
                        <FlatList
                            data={category.data}
                            renderItem={({ item, index }) => {
                                return (
                                    <BundleCard
                                        style={styles(theme).box}
                                        plan_name={item['plan_name']}
                                        plan_description={item['plan_description']}
                                        price={item['price'] / 100}
                                        onPress={() => {
                                            setSelectedPlan(item);
                                            onContinue()
                                        }} />
                                )
                            }} />
                    </View>
                ))}
            </ScrollView>
            <SafeAreaView />
            {loading && <ProgressView />}

            <AlertModal title={paymentStatus.title}
                description={paymentStatus.message}
                isVisible={isAlertVisible}
                imageType={paymentStatus.type}
                actions={buttonArray}
                onClose={() => { setAlertVisible(false) }}
                onPress={(e: any, index: number) => {
                    if (index == 0) {
                        okClick()
                    }
                }}
            />
            <PaymentOptionModal
                visible={showPaymentOptions}
                onClose={() => { setShowPaymentOptions(false) }}
                onPress={(item: any, index: number) => {
                    if (index == 0) {
                        buyFiberPlanbyCard()
                    } else if (index == 1) {
                        setShowVoucherModal(true)
                    }
                    else if (index == 2) {
                        if (customerDetails?.customer?.msisdns?.length > 0) {
                            props.navigation.navigate(SCREENS.SelectNumber.identifier, {
                                selectedItem: customerDetails?.customer?.msisdns?.[0] ?? {},
                                msisdnList: customerDetails?.customer?.msisdns ?? [],
                                onSelect: (item: any) => {
                                    buyFiberPlanbyAirtime(item)
                                }
                            })
                        } else {
                            showMessageToast("You don't have any valid msisdn")
                        }
                    }
                }}
            />

            <VoucherModal
                visible={showVoucherModal}
                errorMessage={showErrorMessage}
                onClose={() => { setShowVoucherModal(false) }}
                onPress={(item: any) => {
                    if (!item) {
                        setShowErrorMessage(true)
                        return;
                    }
                    setShowPaymentOptions(false);
                    setShowErrorMessage(false)
                    setShowVoucherModal(false);
                    buyFiberPlanbyVoucher(item);
                }} />
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    headerView: {
        flexDirection: 'row',
        paddingHorizontal: getScaleSize(15),
        paddingTop: getScaleSize(12),
        alignItems: 'center'
    },
    fiberPlanBox: {
        backgroundColor: theme._F5F5F5,
        marginHorizontal: getScaleSize(12),
        marginTop: getScaleSize(12),
        borderRadius: getScaleSize(12),
        padding: getScaleSize(12),
        flexDirection: 'row',
        alignItems: 'flex-end',
        justifyContent: 'space-between'
    },
    box: {
        marginHorizontal: getScaleSize(12),
        marginTop: getScaleSize(12),
        marginBottom: getScaleSize(0)
    }
})


export default MyFiberPlan