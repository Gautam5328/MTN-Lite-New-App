import React, { useContext, useState } from "react";
import { SafeAreaView, StyleSheet, TouchableOpacity, View } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//CONSTANT & UTILS
import { STRINGS, formatRawMobileNumber, getScaleSize } from "../constant";
import { FONTS } from "../assets";

//COMPONENTS
import { AlertModal, Button, Header, NumberBox, ProgressView, Text } from "../components";

//SCREENS
import { SCREENS } from "../screens";
import { CommonActions } from "@react-navigation/native";
import { API } from "../api";


function BorrowDataConfirm(props: any) {

    const data=props?.route?.params?.data
    const item=props?.route?.params?.selectedItem

    const [selectedData, setSelectedData] = useState<any>(data)
    const [selectedItem, setSelectedItem] = useState<any>(item)
    const [loading, setLoading] = useState(false);
    const [isAlertVisible, setAlertVisible] = useState(false);
    const [borrowStatus, setBorrowStatus] = useState({ type: '', title: '', message: '' });

    const { theme } = useContext(ThemeContext)

    const buttonArray = [{ 'title': 'Ok', 'color': theme.MAIN_THEME_COLOR }]

    async function onContinue() {

        let borrowdata='';
        if (selectedData) {
            borrowdata = selectedData;
            if (borrowdata.includes(' MB')) {
                borrowdata = borrowdata.replace(' MB', "");
            } else if (borrowdata.includes(' GB')) {
                borrowdata = borrowdata.replace(' GB', "");
                borrowdata = (Number(borrowdata) * 1024).toString();
            }
        }
        let params = {
            "data": Number(borrowdata),
            "to_msisdn": '+' + formatRawMobileNumber(selectedItem.msisdn)
        };
        try {
            setLoading(true);
            const result = await API.transactionInstance.post('/borrow/data', params)
            setLoading(false)
            if (result?.status == 200) {
                setBorrowStatus({ type: 'SUCCESS', 'message': result?.data?.message, 'title': STRINGS.payment_success })
                setAlertVisible(true);
            }
        }
        catch (error: any) {
            setLoading(false)
            setBorrowStatus({ type: 'FAIL', 'message': error?.message ?? '', 'title': 'Failed' })
            setAlertVisible(true);
        }
    }

    const okClick = async () => {
        setAlertVisible(false);
        props.navigation.dispatch(
            CommonActions.reset({
                index: 0,
                routes: [
                    { name: SCREENS.BottomBar.identifier }
                ],
            })
        );
    }

    return (
        <View style={styles(theme).container}>
            <Header
                title={STRINGS.header_title}
                onBack={() => { props.navigation.goBack() }} />
            <Text
                style={styles(theme).headerText}
                font={FONTS.Roboto.Bold}
                color={theme._000}
                size={getScaleSize(16)}>
                {STRINGS.confirm_your_share + STRINGS.borrow_data}
            </Text>
            <View style={styles(theme).detailContainer}>
                <Text
                    style={styles(theme).fromText}
                    font={FONTS.Roboto.Bold}
                    color={theme._828282}
                    size={getScaleSize(16)}>
                    {STRINGS.borrow_for}
                </Text>
                <NumberBox isDisable={true} item={selectedItem} />            
                <Text
                    style={styles(theme).dataText}
                    font={FONTS.Roboto.Bold}
                    color={theme._828282}
                    size={getScaleSize(16)}>
                    {STRINGS.data}
                </Text>
                <View style={styles(theme).dataContainer}>
                    <View
                        style={styles(theme).selectedDataBox}>
                        <Text
                            font={FONTS.Roboto.Bold}
                            color={theme.TEXT_COLOR_AS_THEME}
                            size={getScaleSize(12)}>
                            {data}
                        </Text>
                    </View>
                </View>
            </View>

            <View style={styles(theme).container} />
            <Button
                style={styles(theme).btnContinue}
                title={STRINGS.proceed}
                onPress={() => onContinue()} />
            <SafeAreaView />
            {loading && <ProgressView />}

            <AlertModal title={borrowStatus.title}
                description={borrowStatus.message}
                isVisible={isAlertVisible}
                imageType={borrowStatus.type}
                actions={buttonArray}
                onClose={() => { setAlertVisible(false) }}
                onPress={(e: any, index: number) => {
                    if (index == 0) {
                        okClick()
                    }
                }}
            />
        </View>
    )
}


const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF
    },
    detailContainer: {
        backgroundColor: theme._F5F5F5,
        marginHorizontal: getScaleSize(24),
        marginVertical: getScaleSize(20),
        borderRadius: getScaleSize(20),
        padding: getScaleSize(20),
    },
    headerText: {
        marginHorizontal: getScaleSize(26),
        marginTop: getScaleSize(20),
    },
    fromText: {
        marginBottom: getScaleSize(10),
    },
    toText: {
        marginTop: getScaleSize(10),
        marginBottom: getScaleSize(10),
    },
    dataText: {
        marginTop: getScaleSize(10),
        marginBottom: getScaleSize(2),
    },
    dataContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    dataBox: {
        marginTop: getScaleSize(8),
        marginLeft: getScaleSize(8),
        paddingHorizontal: getScaleSize(8),
        paddingVertical: getScaleSize(4),
        backgroundColor: theme._F5F5F5,
        borderRadius: getScaleSize(8),
    },
    selectedDataBox: {
        marginTop: getScaleSize(8),
        paddingHorizontal: getScaleSize(8),
        paddingVertical: getScaleSize(4),
        backgroundColor: theme.MAIN_THEME_COLOR,
        borderRadius: getScaleSize(8),
    },
    btnContinue: {
        marginVertical: getScaleSize(40),
        marginHorizontal: getScaleSize(24),
    }
})

export default BorrowDataConfirm