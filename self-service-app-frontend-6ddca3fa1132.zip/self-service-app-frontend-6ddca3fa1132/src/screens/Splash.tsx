import React, { useContext, useEffect } from "react"
import { Dimensions, Image, ImageBackground, StyleSheet, View } from 'react-native'

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context"

//ASSETS & CONSTANT
import { IMAGES } from "../assets"
import { STRINGS, Storage, getScaleSize, operator } from "../constant"

//PACKAGES
import { CommonActions } from "@react-navigation/native"

//SCREENS
import { SCREENS } from "../screens"
import { opratorLogo } from "../constant/utils"

function Splash(props: any) {

    const { theme } = useContext(ThemeContext)

    useEffect(() => {
        getUserDetails()
    }, [])

    async function getUserDetails() {
        const idToken = await Storage.get(Storage.ACCESS_TOKEN)

        setTimeout(() => {
            if (idToken) {
                props.navigation.dispatch(
                    CommonActions.reset({
                        index: 0,
                        routes: [
                            { name: SCREENS.BottomBar.identifier }
                        ],
                    })
                );
            }
            else {
                props.navigation.dispatch(
                    CommonActions.reset({
                        index: 0,
                        routes: [
                            { name: SCREENS.Leading.identifier }
                        ],
                    })
                );
            }
        }, 2000);
    }
    const windowWidth = Dimensions.get('window').width;

    return (
        <View style={styles(theme).container}>
            <ImageBackground
                style={{
                    ...styles(theme).imgContainer,
                    width: windowWidth,
                    height: windowWidth * 2.2,
                }}
                source={IMAGES.background}>
                <Image
                    style={[styles(theme).imgLogo, { height: opratorLogo(operator)?.height * 1.3, width: opratorLogo(operator)?.width * 1.3 }]}
                    resizeMode="contain"
                    source={opratorLogo(operator)?.source} />
            </ImageBackground>
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF
    },
    imgContainer: {
        flex: 1.0,
        backgroundColor: theme._FFF,
        justifyContent: 'center',
        alignItems: 'center'
    },
    imgLogo: {
        height: getScaleSize(50),
        width: getScaleSize(183)
    }
})

export default Splash