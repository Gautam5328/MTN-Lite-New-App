import React, { useContext, useEffect } from "react"
import { Dimensions, Image, ImageBackground, SafeAreaView, StyleSheet, View } from 'react-native'

//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context"

//ASSETS & CONSTANT
import { FONTS, IMAGES } from "../assets"
import { STRINGS, getScaleSize } from "../constant"

//COMPONENTS
import { Button, Text } from "../components"

//SCREENS
import { SCREENS } from "../screens"

//PACKAGES
import { useNavigation } from "@react-navigation/native"

import { opratorLogo } from "../constant/utils"

function Leading(props: any) {
  const { theme, operator } = useContext(ThemeContext);
  const { logDetails, logScreen } = useContext(ShipbookContext);

  useEffect(() => {
    logScreen('Leading');
  }, []);

  function onGetStarted() {
    logDetails("Let's get started button clicked");
    props.navigation.navigate(SCREENS.Login.identifier);
  }
  const windowWidth = Dimensions.get('window').width;
  return (
    <View style={styles(theme).container}>
      <ImageBackground
        style={{
          ...styles(theme).imgContainer,
          width: windowWidth,
          height: windowWidth * 2.2,
        }}
        source={IMAGES.background}>
        <Image
          style={[styles(theme).imgLogo, { height: opratorLogo(operator)?.height * 1.1, width: opratorLogo(operator)?.width * 1.1}]}
          resizeMode="contain"
          source={opratorLogo(operator)?.source} />
        <Text
          font={FONTS.Roboto.Bold}
          color={theme._000}
          size={getScaleSize(34)}>
          {STRINGS.your_one_stop_application}
        </Text>
        <Text
          style={styles(theme).subtitle}
          font={FONTS.Roboto.Regular}
          color={theme._AFAFAF}
          size={getScaleSize(16)}>
          {STRINGS.your_one_stop_application}
        </Text>
        <Button
          style={styles(theme).btnGetStarted}
          title={STRINGS.let_get_started}
          onPress={() => onGetStarted()} />

        <SafeAreaView />
      </ImageBackground>
    </View>
  )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
  container: {
    flex: 1.0,
    backgroundColor: theme._FFF
  },
  imgContainer: {
    flex: 1.0,
    backgroundColor: theme._FFF,
    justifyContent: 'flex-end',
    paddingHorizontal: getScaleSize(24),
  },
  subtitle: {
    marginTop: getScaleSize(16)
  },
  btnGetStarted: {
    marginTop: getScaleSize(40),
    marginBottom: getScaleSize(30)
  },
  imgLogo: {
    marginLeft: getScaleSize(-5),

    marginBottom: getScaleSize(50)
  }
})

export default Leading