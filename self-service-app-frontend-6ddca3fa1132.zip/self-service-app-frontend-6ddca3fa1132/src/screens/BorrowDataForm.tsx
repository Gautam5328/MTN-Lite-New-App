import React, { useContext, useEffect, useState } from "react";
import { Alert, Image, SafeAreaView, StyleSheet, TextInput, TouchableOpacity, View } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//CONSTANT & UTILS
import { STRINGS, getScaleSize, showMessageToast } from "../constant";
import { FONTS, IMAGES } from "../assets";

//COMPONENTS
import { Button, Header, NumberBox, Text } from "../components";

//SCREENS
import { SCREENS } from "../screens";

//PACKAGES
import { useSelector } from "react-redux";

function BorrowDataForm(props: any) {

    const customerDetails = useSelector((state:any) => state.customerData);

    const [borrowData, setBorrowData] = useState<any>()
    const [selectedData, setSelectedData] = useState<any>('')
    const [mobileNumber, setMobileNumber] = useState<any>(customerDetails?.customer?.msisdns?.[0] ?? {})

    const { theme } = useContext(ThemeContext)

    function onContinue() {
        if (!selectedData) {
            showMessageToast(STRINGS.enter_data_message);
            return;
        }
        props.navigation.navigate(SCREENS.BorrowDataConfirm.identifier, { selectedItem: mobileNumber, data: selectedData })
    }

    function checkData(value: any) {
        setBorrowData(value)
        if (value >= 1024) {
            let data = Math.round(Number(value / 1024) * 100) / 100
            setSelectedData(data + ' GB')
        } else {
            setSelectedData(value + ' MB')
        }
    }

    return (
        <View style={styles(theme).container}>
            <Header
                title={STRINGS.header_title}
                onBack={() => { props.navigation.goBack() }} />
            <Text
                style={styles(theme).fromText}
                font={FONTS.Roboto.Bold}
                color={theme._828282}
                size={getScaleSize(16)}>
                {STRINGS.borrow_for}
            </Text>
            <NumberBox item={mobileNumber}
                style={styles(theme).numberBox}
                isDisable={true}
                onPress={() => {
                    props.navigation.navigate(SCREENS.SelectNumber.identifier, {
                        selectedItem: customerDetails?.customer?.msisdns?.[0] ?? {},
                        msisdnList: customerDetails?.customer?.msisdns ?? [],
                        onSelect: (item: any) => {
                            setMobileNumber(item)
                        }
                    })
                }} />
            <Text
                style={styles(theme).dataText}
                font={FONTS.Roboto.Bold}
                color={theme._828282}
                size={getScaleSize(16)}>
                {STRINGS.choose_borrow_data}
            </Text>
            <View style={styles(theme).dataContainer}>
                {['50 MB', '100 MB', '200 MB', '500 MB', '1 GB', '2 GB', '3 GB'].map((e, index) => {
                    return (
                        <TouchableOpacity
                            key={index}
                            style={selectedData == e ? styles(theme).selectedDataBox : styles(theme).dataBox}
                            onPress={() => {
                                setSelectedData(e)
                            }}>
                            <Text
                                font={FONTS.Roboto.Bold}
                                color={selectedData == e ? theme.TEXT_COLOR_AS_THEME : theme._333333}
                                size={getScaleSize(12)}>
                                {e}
                            </Text>
                        </TouchableOpacity>
                    )
                })}
            </View><Text
                style={styles(theme).orText}
                font={FONTS.Roboto.Bold}
                color={theme._D3D3D3}
                size={getScaleSize(16)}>
                {'OR'}
            </Text>

            <View style={[styles(theme).inputContainer, {
                marginTop: getScaleSize(20),
            }]}>
                <TextInput
                    keyboardType="number-pad"
                    value={borrowData}
                    onChangeText={(value) => { checkData(value) }}
                    style={styles(theme).numberInput}
                    placeholder={STRINGS.share_data_value}
                    placeholderTextColor={theme._333333} />
            </View>
            <View style={styles(theme).container} />
            <Button
                isDisable={!selectedData ? true : false}
                style={styles(theme).btnContinue}
                title={STRINGS.proceed}
                onPress={() => onContinue()} />
            <SafeAreaView />
        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF
    },
    fromText: {
        marginTop: getScaleSize(20),
        marginBottom: getScaleSize(10),
        marginHorizontal: getScaleSize(28),
    },
    numberBox: {
        marginHorizontal: getScaleSize(24),
    },
    dataText: {
        marginTop: getScaleSize(20),
        marginBottom: getScaleSize(2),
        marginHorizontal: getScaleSize(28),
    },
    dataContainer: {
        marginLeft: getScaleSize(18),
        marginHorizontal: getScaleSize(24),
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    dataBox: {
        marginTop: getScaleSize(8),
        marginLeft: getScaleSize(8),
        paddingHorizontal: getScaleSize(8),
        paddingVertical: getScaleSize(4),
        backgroundColor: theme._F5F5F5,
        borderRadius: getScaleSize(8),
    },
    selectedDataBox: {
        marginTop: getScaleSize(8),
        marginLeft: getScaleSize(8),
        paddingHorizontal: getScaleSize(8),
        paddingVertical: getScaleSize(4),
        backgroundColor: theme.MAIN_THEME_COLOR,
        borderRadius: getScaleSize(8),
    },
    btnContinue: {
        marginVertical: getScaleSize(40),
        marginHorizontal: getScaleSize(24),
    },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: theme._D3D3D3,
        marginHorizontal: getScaleSize(24),
        paddingHorizontal: getScaleSize(10),
    },
    numberInput: {
        flex: 1.0,
        height: getScaleSize(40),
        color: theme._333333
    },
    phoneBookImage: {
        height: getScaleSize(20),
        width: getScaleSize(20),
    },
    shareOthers: {
        alignSelf: 'flex-end',
        marginHorizontal: getScaleSize(24),
        marginTop: getScaleSize(8),
    },
    orText: {
        marginTop: getScaleSize(20),
        marginBottom: getScaleSize(2),
        marginHorizontal: getScaleSize(28),
        alignSelf:'center'
    },
})

export default BorrowDataForm