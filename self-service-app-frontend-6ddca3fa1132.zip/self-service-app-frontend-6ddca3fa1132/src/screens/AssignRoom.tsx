import React, { useContext, useRef, useState } from "react";
import { Dimensions, FlatList, Image, StyleSheet, TouchableOpacity, View } from "react-native";

//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { STRINGS, getScaleSize } from "../constant";
import { FONTS, IMAGES } from "../assets";

//COMPONENT
import { Header, Text, Button } from "../components";

//SCREENS
import { SCREENS } from "../screens";

function AssignRoom(props: any) {

    const { theme } = useContext(ThemeContext)

    const { logDetails } = useContext(ShipbookContext);

    function onContinue() {
        logDetails("Continue button clicked");
        props.navigation.navigate(SCREENS.DeviceAdded.identifier);
    }

    const roomssData = [{ roomName: STRINGS.living_room, isSelected: false, image: IMAGES.smart_bulb, activeImage: IMAGES.active_smart_bulb }, { roomName: STRINGS.bed_room1, isSelected: false, image: IMAGES.smart_TV, activeImage: IMAGES.smart_TV },
    { roomName: STRINGS.bed_room2, isSelected: false, image: IMAGES.smart_ac, activeImage: IMAGES.smart_ac }, { roomName: STRINGS.kichen, isSelected: false, image: IMAGES.air_purifier, activeImage: IMAGES.air_purifier },
    { roomName: STRINGS.guest_room, isSelected: false, image: IMAGES.smart_camera, activeImage: IMAGES.smart_camera }, { roomName: STRINGS.add_new_room, isSelected: false, image: IMAGES.smart_fan, activeImage: IMAGES.smart_fan }]
    const [rooms, setDevices] = useState(roomssData);

    const selectDevice = (selectedItemIndex: any) => {
        const itemsToSelect = rooms.map((item, index) => {
            if (selectedItemIndex === index) {
                item.isSelected = !item.isSelected;
            } else {
                item.isSelected = false;
            }
            return item;
        }, []);

        setDevices(itemsToSelect);
    };

    return (
        <View style={styles(theme).container}>
            <Header
                title={STRINGS.assign_room_header}
                onBack={() => { props.navigation.goBack() }} />
            <View style={styles(theme).roomContainer}>
                <View style={styles(theme).detailContainer}>
                    <View style={styles(theme).header}>
                        <Text
                            font={FONTS.Roboto.Bold}
                            color={theme._333333}
                            size={getScaleSize(20)}>
                            {STRINGS.assign_room_text}
                        </Text>
                    </View>
                </View>
                <FlatList
                    data={rooms}
                    numColumns={2}
                    ListFooterComponent={() => {
                        return (
                            <View style={styles(theme).buttonContainer}>
                                <Button
                                    title={STRINGS.continue}
                                    onPress={() => onContinue()} />
                                <TouchableOpacity onPress={() => { props.navigation.goBack() }} style={{ alignItems: 'center', marginTop: 20 }}>
                                    <Text color={theme._AFAFAF}
                                        font={FONTS.Roboto.Medium}
                                        size={getScaleSize(18)}>
                                        {STRINGS.cancel}
                                    </Text>
                                </TouchableOpacity>
                            </View>
                        )
                    }}
                    renderItem={({ item, index }) => {
                        return (
                            <TouchableOpacity onPress={() => { selectDevice(index) }} style={[styles(theme).roomItem, { backgroundColor: item.isSelected ? theme.MAIN_THEME_COLOR : theme._F5F5F5 }]}>
                                <View style={[styles(theme).roomIconContainer]}>
                                    {/* <Image source={item.isSelected ? item.activeImage : item.image} /> */}
                                </View>
                                <Text
                                    font={FONTS.Roboto.Medium}
                                    color={item.isSelected ? theme.TEXT_COLOR_AS_THEME : theme._828282}
                                    size={getScaleSize(12)}>
                                    {item.roomName}
                                </Text>
                            </TouchableOpacity>
                        )
                    }} />
            </View>

        </View>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    detailContainer: {
        backgroundColor: theme._FFF,
        marginHorizontal: getScaleSize(30)
    },
    roomContainer: { backgroundColor: '#fbfbfb', height: Dimensions.get('window').height },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingTop: getScaleSize(24),
        paddingBottom: getScaleSize(4)
    },
    roomItem: {
        width: (Dimensions.get('window').width - getScaleSize(60)) / 2,
        backgroundColor: theme._F5F5F5,
        paddingHorizontal: getScaleSize(12),
        paddingVertical: getScaleSize(12),
        marginLeft: getScaleSize(20),
        marginTop: getScaleSize(20),
        borderRadius: getScaleSize(12),
        justifyContent: 'center',
        alignItems: 'center'
    },
    roomIconContainer: {
        height: getScaleSize(60),
        width: getScaleSize(60),
        borderRadius: getScaleSize(30),
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: theme._FFF,
        marginBottom: getScaleSize(12)
    },
    buttonContainer: {
        marginTop: getScaleSize(70),
        marginHorizontal: getScaleSize(30)
    },
})


export default AssignRoom