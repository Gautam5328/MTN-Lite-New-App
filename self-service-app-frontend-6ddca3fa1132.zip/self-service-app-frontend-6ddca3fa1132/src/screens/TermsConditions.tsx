import React, { useContext } from "react";
import {StyleSheet, View } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { STRINGS, getScaleSize } from "../constant";

//COMPONENT
import { Header, Text } from "../components";


function TermsConditions(props: any) {

  const { theme } = useContext(ThemeContext)


  return (
    <View style={styles(theme).container}>
      <Header
        title={STRINGS.terms_condiitons_header}
        onBack={() => { props.navigation.goBack() }} />
        <View style={styles(theme).detailContainer}>
        </View>
    </View>
  )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
  container: {
    flex: 1.0,
    backgroundColor: theme._FFF,
  },
  detailContainer: {
    marginHorizontal: getScaleSize(30)
  },
})


export default TermsConditions