import React, { useContext, useEffect, useState } from "react";
import { StyleSheet, View, FlatList, Dimensions, ScrollView, RefreshControl } from "react-native";

//ASSETS & CONSTANTS
import { QuickLinksMenu, getScaleSize, showMessageToast } from "../constant";

//COMPONENTS
import { Header, HomeCard, Banner, Pager, QuickLinks, List, HomeFiberCard } from "../components";

//API
import { API } from "../api";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//SCREENS
import { SCREENS } from "../screens";

//REDUX
import { useDispatch } from "react-redux";
import { setCustomerData } from "../redux/actions/customerDataActions";

//PACKAGES
import _, { iteratee } from 'lodash'
import Carousel from 'react-native-snap-carousel';

function Home(props: any) {

    const { theme } = useContext(ThemeContext)

    const dispatch = useDispatch()<any>;

    const [currentBanerPage, setCurrentBannerPage] = useState<number>(0)
    const [bannerItems, setBannerItems] = useState<any>({ isLoading: true, bannerList: [] })
    const [advertiseItems, setAdvertiseItems] = useState<any>({ isLoading: true, advertiseList: [] })
    const [refreshing, setRefreshing] = useState<boolean>(false);

    useEffect(() => {
        fetchCustomerBalance();
        fetchAdvertise();
    }, []);

    const fetchAdvertise = async () => {
        try {
            const result = await API.transactionInstance.get('/advertisement/information')
            if (result.status == 200) {
                setAdvertiseItems({ isLoading: false, advertiseList: result?.data })
            }
            else {
                setAdvertiseItems({ isLoading: false, advertiseList: [] })
                setRefreshing(false)
            }
        }
        catch (error: any) {
            setAdvertiseItems({ isLoading: false, advertiseList: [] })
            setRefreshing(false)
            showMessageToast(error?.message ?? '')
        }
    }

    const fetchCustomerBalance = async () => {
        try {
            const result = await API.transactionInstance.get('/customer/details')
            if (result.status == 200) {
                setBannerItems({ isLoading: false, bannerList: result?.data })
                setRefreshing(false)
                dispatch(setCustomerData(result?.data));
            }
            else {
                setBannerItems({ isLoading: false, bannerList: null })
                setRefreshing(false)
            }
        }
        catch (error: any) {
            setBannerItems({ isLoading: false, bannerList: null })
            setRefreshing(false)
            showMessageToast(error?.message ?? '')
        }
    };

    const onRefresh = React.useCallback(() => {
        setRefreshing(true);
        fetchCustomerBalance()
    }, []);

    return (
        <View style={styles(theme).container}>
            <Header
                isHome
                onNotification={() => { }}
                onProfile={() => { }} />
            <ScrollView showsVerticalScrollIndicator={false}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh} />
                }>
                <View style={{ height: getScaleSize(10) }} />
                {bannerItems?.isLoading ?
                    <View style={[styles(theme).card, {}]}>
                        <HomeCard
                            isLoading={true}
                        />
                    </View>
                    :
                    <Carousel
                        data={[...(bannerItems?.bannerList?.msisdns ?? []), ...(bannerItems?.bannerList?.fiber_data ?? [])]}
                        renderItem={({item}) => {
                            if (item?.fiber_id) {
                                return (
                                    <View style={styles(theme).card}>
                                        <HomeFiberCard
                                            isLoading={false}
                                            item={item}
                                            onRefresh={() => {
                                                setBannerItems({ isLoading: true, bannerList: null })
                                                fetchCustomerBalance();
                                            }} 
                                            onBuyFiberPlan={() => props.navigation.navigate(SCREENS.BuyFiberPlan.identifier, { fiber_id: item?.fiber_id })} 
                                            />
                                    </View>
                                )
                            } else {
                                return (
                                    <View style={styles(theme).card}>
                                        <HomeCard
                                            isLoading={false}
                                            item={item}
                                            onRefresh={() => {
                                                setBannerItems({ isLoading: true, bannerList: null })
                                                fetchCustomerBalance();
                                            }}
                                            onPayBill={() => props.navigation.navigate(SCREENS.PayBill.identifier, { msisdn: item?.msisdn })}
                                            onRecharge={() => props.navigation.navigate(SCREENS.Recharge.identifier, { msisdn: item?.msisdn })}
                                            onBuyBundle={() => props.navigation.navigate(SCREENS.BuyBundle.identifier, { msisdn: item?.msisdn })} />
                                    </View>
                                )
                            }
                        }}
                        sliderWidth={Dimensions.get('window').width}
                        itemWidth={Dimensions.get('window').width - getScaleSize(30)}
                        inactiveSlideOpacity={1}
                        inactiveSlideScale={1}
                        layout={'default'}
                        loop={false}
                    />
                }
                <View>
                    <Carousel
                        data={advertiseItems?.advertiseList?.advertisements}
                        renderItem={({ item }) => {
                            return (
                                <View style={styles(theme).card}>
                                    <Banner item={item} />
                                </View>
                            )
                        }}
                        onSnapToItem={(index: number) => {
                            setCurrentBannerPage(index)
                        }}
                        sliderWidth={Dimensions.get('window').width}
                        itemWidth={Dimensions.get('window').width - getScaleSize(30)}
                        inactiveSlideOpacity={1}
                        inactiveSlideScale={1}
                        layout={'default'}
                        loop={true}
                        autoplay={true}
                    />
                </View>
                <View style={styles(theme).pageContainer}>
                    <Pager currentPage={currentBanerPage} totalPages={advertiseItems?.advertiseList?.advertisements?.length??0} />
                </View>
                <QuickLinks data={QuickLinksMenu} />
            </ScrollView>
        </View>
    )

}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF
    },
    card: {
        paddingHorizontal: getScaleSize(4),
        marginVertical: getScaleSize(10),
    },
    pageContainer: {
        height: getScaleSize(50),
        justifyContent: 'center',
        alignItems: 'center'
    },
    indecatorView: {
        marginVertical: getScaleSize(16),
        justifyContent: 'center'
    }
})

export default Home