import { View, StyleSheet, Image, SafeAreaView } from 'react-native'
import React, { useContext } from 'react'
import { TextInput } from 'react-native-gesture-handler'
//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context"

//ASSETS & CONSTANT
import { FONTS } from "../assets"
import { STRINGS, getScaleSize } from "../constant"

//COMPONENTS
import { Button, Header, Text } from "../components"

//SCREENS
import { SCREENS } from "../screens"

function NameDevice(props: any) {

    const { theme } = useContext(ThemeContext);

    const { logDetails } = useContext(ShipbookContext);

    function onContinue() {
        logDetails("Continue button clicked");
        props.navigation.navigate(SCREENS.AssignRoom.identifier);
    }

    return (
        <View style={style(theme).rootContainer}>
            <Header
                title={STRINGS.name_your_device}
                onBack={() => { props.navigation.goBack() }}
            />
            <View style={style(theme).container}>
                <View style={style(theme).headContainer}>
                    <Text
                        font={FONTS.Roboto.Bold}
                        color={theme.TEXT_COLOR_AS_THEME}
                        size={getScaleSize(21)}>
                        {STRINGS.now_lets_give_your_device_a_name}
                    </Text>
                    <View style={style(theme).inputContainer}>
                        <TextInput
                            style={style(theme).input}
                            placeholderTextColor={theme.SUB_TEXT_COLOR_AS_THEME}
                            placeholder={STRINGS.device_name} />
                    </View>
                </View>
                <View style={style(theme).btnContainer}>
                    <Button
                        title={STRINGS.next}
                        onPress={() => onContinue()}
                    />
                </View>
            </View>
            <SafeAreaView />
        </View>

    )
}

export default NameDevice

const style = (theme: ThemeContextType['theme']) => StyleSheet.create({

    rootContainer: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    subtitle: {
        alignSelf: 'center'
    },
    container: {
        flex: 1.0,
        paddingHorizontal: getScaleSize(24),
        justifyContent: 'center'
    },
    btnContainer: {
        flex: 0.45,
        justifyContent: 'flex-end'
    },
    headContainer: {
        flex: 0.3,
        justifyContent: 'space-evenly'
    },
    input: {
        borderRadius: 10,
        backgroundColor: theme._FFF,
        padding: 7, fontSize: 13,
        color: theme._000,
        height: 45
    },
    inputContainer: {
        height: 90,
        backgroundColor: theme.MAIN_THEME_COLOR,
        borderRadius: 10,
        justifyContent: 'center',
        padding: 10
    },
})