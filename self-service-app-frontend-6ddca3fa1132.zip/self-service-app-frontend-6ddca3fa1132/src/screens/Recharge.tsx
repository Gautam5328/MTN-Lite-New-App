import React, { useContext, useState, useEffect } from "react";
import { Dimensions, Image, StyleSheet, TouchableOpacity, View, Keyboard, ActivityIndicator, Modal, FlatList } from "react-native";

//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { getScaleSize, showMessageToast, STRINGS, formatRawMobileNumber, formatToDecimalNumber } from "../constant";
import { FONTS, IMAGES } from "../assets";

//COMPONENTS
import { Button, Header, Text, AlertModal, ProgressView, Icons, PhoneBook, ShareItem, PaymentOptionModal, VoucherModal } from "../components";
import { TextInput } from "react-native-gesture-handler";

//PACKAGES
import Slider from '@react-native-community/slider';
import { StripeProvider, useStripe } from "@stripe/stripe-react-native"
import { useSelector } from "react-redux";

//API
import { API } from "../api";
import { SCREENS } from "../screens";
import { CommonActions } from "@react-navigation/native";
import { set } from "lodash";

function Recharge(props: any) {

    const customerDetails = useSelector((state: any) => state.customerData);

    const { theme } = useContext(ThemeContext)
    const { logDetails } = useContext(ShipbookContext);

    const { initPaymentSheet, presentPaymentSheet } = useStripe();

    let msisdn = '';
    if (props?.route?.params?.msisdn) {
        msisdn = props?.route?.params?.msisdn
    }

    const [amount, setAmount] = useState<number>(10)
    const [rechargeAmount, setRechargeAmount] = useState('')
    const [mobileNumber, setMobileNumber] = useState(msisdn)
    const [validMSISDN, setvalidMSISDN] = useState(false);
    const [loading, setLoading] = useState(false);
    const [paymentStatus, setPaymentStatus] = useState({ type: '', title: '', message: '' });
    const [isAlertVisible, setAlertVisible] = useState(false);
    const [showPaymentOptions, setShowPaymentOptions] = useState(false);
    const [showVoucherModal, setShowVoucherModal] = useState(false);
    const [showErrorMessage, setShowErrorMessage] = useState(false);

    const handleSelectPhoneNumber = async () => {
        try {
            const phoneNumber = await PhoneBook();
            setMobileNumber(phoneNumber?.msisdn ?? '');
        } catch (error) {
            console.error('Error selecting phone number:');
        }
    };

    const buttonArray = [{ 'title': 'Ok', 'color': theme.MAIN_THEME_COLOR }]

    const initializePaymentSheet = async (intent: any) => {
        const { payment_intent, ephemeral_key, customer_id, publishable_key } =
            intent;
        const { error } = await initPaymentSheet({
            merchantDisplayName: "Telecom",
            customerId: customer_id,
            customerEphemeralKeySecret: ephemeral_key?.secret,
            paymentIntentClientSecret: payment_intent,
            allowsDelayedPaymentMethods: true,
            defaultBillingDetails: {
                name: "Jane Doe",
            },
        });


        if (!error) {
            setLoading(true);
        } else {
            showMessageToast(error?.message ?? '')
        }
    };

    const openPaymentSheet = async () => {
        logDetails(`Airtime Recharge ${mobileNumber} - Amount: ${amount}`)
        let paymentAmount = amount;
        if (rechargeAmount != '' && rechargeAmount != '0') {
            paymentAmount = Number(rechargeAmount)
        }
        let params = {
            "amount": Number(paymentAmount) * 100,
            "currency": STRINGS.currencyCode,
            "msisdn": formatRawMobileNumber(mobileNumber),
        };
        try {
            setLoading(true);
            const result = await API.transactionInstance.post('/customer/recharge/airtime/by-card', params)

            initializePaymentSheet(result?.data);
            setTimeout(async () => {
                const { error } = await presentPaymentSheet();
                if (error) {
                    if (error.message == "The payment flow has been canceled") {
                        setPaymentStatus({ type: 'FAIL', 'message': error.message, 'title': STRINGS.payment_canceled })
                    } else {
                        setPaymentStatus({ type: 'FAIL', 'message': error.message, 'title': STRINGS.payment_failed })
                    }

                    setAlertVisible(true);
                    setLoading(false);
                } else {
                    setPaymentStatus({ type: 'SUCCESS', 'message': STRINGS.payment_success_desc, 'title': STRINGS.payment_success })

                    setAlertVisible(true);
                    setLoading(false);
                }
            }, 1000);
        }
        catch (error: any) {
            setShowPaymentOptions(false);
            setLoading(false)
            showMessageToast(error?.message ?? '')
        }
    }
    const rechargeByCard = async () => {
        openPaymentSheet();
        setShowPaymentOptions(false);
    }
    const rechargeByVoucher = async (item: any) => {
        try {
            let params = {
                "voucher": item,
                "msisdn": '+' + formatRawMobileNumber(mobileNumber),
            };

            setLoading(true);
            const result = await API.transactionInstance.post('/customer/recharge/airtime/by-voucher', params)
            if (result.status == 200) {
                setPaymentStatus({ type: 'SUCCESS', 'message': result?.data?.message, 'title': STRINGS.payment_success })
                setAlertVisible(true);
            }
            setLoading(false)
            setShowPaymentOptions(false);
        }
        catch (error: any) {
            setShowPaymentOptions(false);
            setLoading(false)
            showMessageToast(error?.message ?? '')

        }
    }
    const rechargeByAirtime = async (frommsisdn: any) => {
        try {
            let paymentAmount = amount;
            if (rechargeAmount != '' && rechargeAmount != '0') {
                paymentAmount = Number(rechargeAmount)
            }
            let params = {
                "amount": Number(paymentAmount) * 100,
                "currency": STRINGS.currencyCode,
                "to_msisdn": '+' + formatRawMobileNumber(mobileNumber),
                "from_msisdn": '+' + formatRawMobileNumber(frommsisdn?.msisdn),
            };

            setLoading(true);
            const result = await API.transactionInstance.post('/customer/recharge/airtime/by-airtime', params)

            if (result?.status == 200) {
                setPaymentStatus({ type: 'SUCCESS', 'message': result?.data?.message, 'title': STRINGS.payment_success })
                setAlertVisible(true);
            }
            setLoading(false)
            setShowPaymentOptions(false);
        }
        catch (error: any) {
            setShowPaymentOptions(false);
            setLoading(false)
            showMessageToast(error?.message ?? '')

        }
    }

    const onContinue = async () => {
        if (!mobileNumber) {
            showMessageToast(STRINGS.enter_mobile_number_message);
            return;
        } else if (mobileNumber.length < 10) {
            showMessageToast(STRINGS.enter_valid_number_error);
            return;
        }
        try {
            setLoading(true);
            const result = await API.transactionInstance.get('/msisdn/validate-number/' + formatRawMobileNumber(mobileNumber))
            if (result.status == 200) {
                if (result?.data.is_valid) {
                    setvalidMSISDN(true);
                    setShowPaymentOptions(true);
                } else {
                    setvalidMSISDN(false);
                    setShowPaymentOptions(false);
                    showMessageToast(STRINGS.invalid_mobile)
                }
                setLoading(false)
            }
        }
        catch (error: any) {
            setLoading(false)
            showMessageToast(error?.message ?? '')
        }
    };

    const okClick = async () => {
        setAlertVisible(false);
        props.navigation.dispatch(
            CommonActions.reset({
                index: 0,
                routes: [
                    { name: SCREENS.BottomBar.identifier }
                ],
            })
        );
    }

    return (
        <StripeProvider publishableKey="pk_test_51OFd0jL4Cr6vAwq9tFeceN6CXG8DsaeVgkwPumExbc3tpPl3P459OzQ7qHBWli3piR4O6vINgIfCyuqwr3Xl1RiD00jFscF7YQ">
            <View style={styles(theme).container}>
                <Header
                    onBack={() => props.navigation.goBack()}
                    title={STRINGS.recharge} />
                <View style={styles(theme).detailsContainer}>
                    <Text
                        style={styles(theme).titleText}
                        font={FONTS.Roboto.Bold}
                        color={theme._333333}
                        size={getScaleSize(20)}>
                        {STRINGS.enter_number_and_select_recharge_amount}
                    </Text>
                    <View style={styles(theme).inputContainer}>
                        <TextInput
                            keyboardType="number-pad"
                            onChangeText={setMobileNumber}
                            maxLength={13}
                            value={mobileNumber}
                            style={styles(theme).numberInput}
                            placeholder={STRINGS.mobile_number}
                            placeholderTextColor={theme._333333} />
                        <TouchableOpacity onPress={handleSelectPhoneNumber} >
                            <Image style={styles(theme).phoneBookImage} source={IMAGES.contact_book} />
                        </TouchableOpacity>
                        {mobileNumber.length > 0 &&
                            <TouchableOpacity onPress={() => { setMobileNumber('') }}>
                                <Icons
                                    name={'close'}
                                    color={theme._AFAFAF}
                                    type={'MaterialIcons'}
                                    size={20} />
                            </TouchableOpacity>
                        }
                    </View>
                    <View style={styles(theme).amountContainer}>
                        <View style={styles(theme).amountHeader}>
                            <TouchableOpacity style={styles(theme).amountButton}
                                onPress={() => {
                                    if (amount > 10) {
                                        setAmount((prev) => prev - 10)
                                    }
                                }}>
                                <Image style={styles(theme).amountButtonImage}
                                    source={IMAGES.minus_round} />
                            </TouchableOpacity>
                            <Text
                                style={styles(theme).amountText}
                                font={FONTS.Roboto.Medium}
                                color={theme.TEXT_COLOR_AS_THEME}
                                size={getScaleSize(35)}>
                                {STRINGS.currency + formatToDecimalNumber(amount)}
                            </Text>
                            <TouchableOpacity style={styles(theme).amountButton}
                                onPress={() => {
                                    if (amount < 200) {
                                        setAmount((prev) => prev + 10)
                                    }
                                }}>
                                <Image style={styles(theme).amountButtonImage}
                                    source={IMAGES.plus_round} />
                            </TouchableOpacity>
                        </View>
                        <Slider
                            style={{ width: '100%', height: 40 }}
                            minimumValue={10}
                            maximumValue={200}
                            step={10}
                            thumbTintColor={theme._FFF}
                            minimumTrackTintColor={theme.TEXT_COLOR_AS_THEME}
                            maximumTrackTintColor={theme.SUB_TEXT_COLOR_AS_THEME}
                            value={amount}
                            onValueChange={(value: number) => {
                                setAmount(value)
                            }} />
                        <View style={styles(theme).amountFotter}>
                            {[10, 20, 30, 50, 70, 100, 150, 200].map((e, index) => {
                                const isSelected = e == amount
                                return (
                                    <TouchableOpacity
                                        key={index}
                                        style={[styles(theme).amountBox, {
                                            opacity: isSelected ? 1 : 0.8
                                        }]}
                                        onPress={() => {
                                            setAmount(e)
                                        }}>
                                        <Text
                                            font={FONTS.Roboto.Bold}
                                            color={isSelected ? theme.MAIN_THEME_COLOR : theme._000}
                                            size={getScaleSize(18)}>
                                            {STRINGS.currency + e}
                                        </Text>
                                    </TouchableOpacity>
                                )
                            })}
                        </View>
                    </View>
                    <Text
                        style={styles(theme).orText}
                        font={FONTS.Roboto.Bold}
                        color={theme._D3D3D3}
                        size={getScaleSize(16)}>
                        {'OR'}
                    </Text>

                    <View style={[styles(theme).inputContainer, {
                        marginTop: getScaleSize(20),
                    }]}>
                        <TextInput
                            keyboardType="number-pad"
                            value={rechargeAmount}
                            onChangeText={(value: any) => { setRechargeAmount((value)) }}
                            style={styles(theme).numberInput}
                            placeholder={STRINGS.share_amount}
                            placeholderTextColor={theme._333333} />
                    </View>
                    <Button
                        isDisable={mobileNumber.length < 10 ? true : false}
                        style={styles(theme).btnContinue}
                        title={STRINGS.continue}
                        onPress={() => { onContinue() }} />
                    <TouchableOpacity onPress={() => { props.navigation.navigate(SCREENS.BottomBar.identifier) }}>
                        <Text

                            style={styles(theme).cancelText}
                            font={FONTS.Roboto.Bold}
                            color={theme._AFAFAF}
                            size={getScaleSize(15)}>
                            {'Cancel'}
                        </Text>
                    </TouchableOpacity>
                </View>
                {loading && <ProgressView />}
            </View>
            <AlertModal title={paymentStatus.title}
                description={paymentStatus.message}
                isVisible={isAlertVisible}
                imageType={paymentStatus.type}
                actions={buttonArray}
                onClose={() => { setAlertVisible(false) }}
                onPress={(e: any, index: number) => {
                    if (index == 0) {
                        okClick()
                    }
                }}
            />
            <PaymentOptionModal
                visible={showPaymentOptions}
                onClose={() => { setShowPaymentOptions(false) }}
                onPress={(item: any, index: number) => {
                    if (index == 0) {
                        rechargeByCard()
                    } else if (index == 1) {
                        setShowVoucherModal(true)
                    }
                    else if (index == 2) {
                        if (customerDetails?.customer?.msisdns?.length > 0) {
                            props.navigation.navigate(SCREENS.SelectNumber.identifier, {
                                selectedItem: customerDetails?.customer?.msisdns?.[0] ?? {},
                                msisdnList: customerDetails?.customer?.msisdns ?? [],
                                onSelect: (item: any) => {
                                    rechargeByAirtime(item);
                                }
                            })
                        } else {
                            showMessageToast("You don't have any valid msisdn")
                        }
                    }
                }} />
            <VoucherModal
                visible={showVoucherModal}
                errorMessage={showErrorMessage}
                onClose={() => { setShowVoucherModal(false) }}
                onPress={(item: any) => {
                    if (!item) {
                        setShowErrorMessage(true)
                        return;
                    }
                    setShowPaymentOptions(false);
                    setShowErrorMessage(false)
                    setShowVoucherModal(false);
                    rechargeByVoucher(item);
                }} />
        </StripeProvider>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF
    },
    detailsContainer: {
        flex: 1.0,
        paddingVertical: getScaleSize(20)
    },
    titleText: {
        marginHorizontal: getScaleSize(24)
    },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: getScaleSize(20),
        borderWidth: 1,
        borderColor: theme._D3D3D3,
        marginHorizontal: getScaleSize(24),
        paddingHorizontal: getScaleSize(10),
    },
    numberInput: {
        flex: 1.0,
        height: getScaleSize(40),
        color: theme._000
    },
    phoneBookImage: {
        height: getScaleSize(20),
        width: getScaleSize(20),
    },
    actionContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginHorizontal: getScaleSize(24),
        marginTop: getScaleSize(10),
    },
    choosePlanText: {
        alignSelf: 'flex-end',
        textDecorationLine: 'underline',
    },
    amountContainer: {
        marginTop: getScaleSize(20),
        marginHorizontal: getScaleSize(24),
        padding: getScaleSize(24),
        backgroundColor: theme.MAIN_THEME_COLOR,
        borderRadius: getScaleSize(12)
    },
    amountHeader: {
        flexDirection: 'row',
        height: getScaleSize(60),
        alignItems: 'center'
    },
    amountFotter: {
        flexDirection: 'row',
        flexWrap: 'wrap'
    },
    amountButton: {
        height: getScaleSize(40),
        width: getScaleSize(60),
        justifyContent: 'center',
        alignItems: 'center'
    },
    amountButtonImage: {
        height: getScaleSize(40),
        width: getScaleSize(40),
        opacity: 0.9,
        tintColor: theme.ICON_COLOR_AS_THEME
    },
    amountText: {
        flex: 1.0,
        textAlign: 'center',
        opacity: 0.9
    },
    amountBox: {
        width: (Dimensions.get('window').width - getScaleSize(96) - getScaleSize(50)) / 4,
        height: (Dimensions.get('window').width - getScaleSize(96) - getScaleSize(50)) / 4,
        borderRadius: getScaleSize(8),
        elevation: 2,
        shadowColor: '#000',
        shadowOpacity: 0.2,
        shadowRadius: 2,
        shadowOffset: { width: 0, height: 1 },
        backgroundColor: theme._FFF,
        marginLeft: getScaleSize(10),
        marginTop: getScaleSize(10),
        justifyContent: 'center',
        alignItems: 'center'
    },
    btnContinue: {
        marginTop: getScaleSize(40),
        marginHorizontal: getScaleSize(24),
    },
    cancelText: {
        marginTop: getScaleSize(20),
        alignSelf: 'center',
        marginHorizontal: getScaleSize(24)
    },
    btnLoader: {
        backgroundColor: theme.MAIN_THEME_COLOR,
        marginTop: getScaleSize(40),
        marginHorizontal: getScaleSize(24), height: getScaleSize(40),
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: getScaleSize(20)
    },
    orText: {
        marginTop: getScaleSize(20),
        marginBottom: getScaleSize(2),
        marginHorizontal: getScaleSize(28),
        alignSelf: 'center'
    },
    optionCardContainer: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center", backgroundColor: 'rgba(52, 52, 52, 0.9)'
    },
    optioncard: {
        backgroundColor: "#fff",
        borderRadius: getScaleSize(10),
        paddingTop: getScaleSize(20),
        paddingBottom: getScaleSize(20),
        width: Dimensions.get('window').width - getScaleSize(60),
        alignItems: "center",
        justifyContent: "center",
        alignContent: "center",
        paddingHorizontal: getScaleSize(15),
        position: 'relative'
    },
    iconContainer: { marginRight: getScaleSize(15), marginTop: getScaleSize(4) },
    optionCOntainer: { flexDirection: 'row', margin: getScaleSize(10) }
})

export default Recharge