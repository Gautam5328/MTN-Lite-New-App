import React, { useContext, useEffect, useState } from "react";
import { StyleSheet, View, FlatList, SafeAreaView } from "react-native";

//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context";

//ASSETS & CONSTANT
import { STRINGS, formatRawMobileNumber, getScaleSize, showMessageToast } from "../constant";
import { FONTS } from "../assets";

//COMPONENT
import { AlertModal, Button, Header, Icons, MsisdnsList, ProgressView, Text } from "../components";

//API
import { API } from "../api";

//SCREENS
import { SCREENS } from "../screens";

//PACKAGES
import { useSelector } from "react-redux";
import _ from 'lodash';
import moment from "moment";
import { StripeProvider, useStripe } from "@stripe/stripe-react-native";
import { CommonActions } from "@react-navigation/native";

function PayBill(props: any) {

    const { theme } = useContext(ThemeContext)
    const customerdetails = useSelector((state: any) => state.customerData);
    const msisdndetails = customerdetails?.customer?.msisdns?.[0];
    const [msisdnList, setMsisdnList] = useState<any[]>(customerdetails?.customer?.msisdns ?? [])
    const [mobileNumber, setMobileNumber] = useState<any>(msisdndetails)
    const [loading, setLoading] = useState(false);
    const [billDetails, setBillDetails] = useState<any[]>([])
    const postpaidMsisdns = _.filter(msisdnList, { billing_type: 'Postpaid' });

    const [isAlertVisible, setAlertVisible] = useState(false);
    const [showPaymentOptions, setShowPaymentOptions] = useState(false);
    const [paymentStatus, setPaymentStatus] = useState({ type: '', title: '', message: '' });
    const buttonArray = [{ 'title': 'Ok', 'color': theme.MAIN_THEME_COLOR }]

    const { initPaymentSheet, presentPaymentSheet } = useStripe();

    useEffect(() => {
        getBill();
    }, []);

    const getBill = async () => {
        try {
            setLoading(true);
            const result = await API.transactionInstance.get('/customer/bill/' + formatRawMobileNumber(mobileNumber?.msisdn))
            if (result?.status == 200) {
                if (result?.data) {
                    let sortedInput = (result?.data).slice().sort((a: any, b: any) => b.timestamp - a.timestamp);
                    setBillDetails(sortedInput);
                    setLoading(false);
                }
            }
        } catch (error: any) {
            setLoading(false);
            showMessageToast(error?.message ?? '')
        }
    };

    const initializePaymentSheet = async (intent: any) => {
        const { payment_intent, ephemeral_key, customer_id, publishable_key } =
            intent;
        const { error } = await initPaymentSheet({
            merchantDisplayName: "Telecom",
            customerId: customer_id,
            customerEphemeralKeySecret: ephemeral_key?.secret,
            paymentIntentClientSecret: payment_intent,
            allowsDelayedPaymentMethods: true,
            defaultBillingDetails: {
                name: "Jane Doe",
            },
        });
        if (!error) {
            setLoading(true);
        } else {
            showMessageToast(error?.message ?? '')
        }
    };

    const openPaymentSheet = async (item: any) => {

        let params = {
            "amount": Number(item?.amount ?? 0),
            "currency": STRINGS.currencyCode,
            "msisdn": formatRawMobileNumber(item?.msisdn),
            "bill_id": item?.bill_id
        };
        try {
            setLoading(true);
            const result = await API.transactionInstance.post('/customer/pay-bill', params)

            initializePaymentSheet(result?.data);
            setTimeout(async () => {
                const { error } = await presentPaymentSheet();
                if (error) {
                    if (error.message == "The payment flow has been canceled") {
                        setPaymentStatus({ type: 'FAIL', 'message': error.message, 'title': STRINGS.payment_canceled })
                    } else {
                        setPaymentStatus({ type: 'FAIL', 'message': error.message, 'title': STRINGS.payment_failed })
                    }
                    setAlertVisible(true);
                    setLoading(false);
                } else {
                    setPaymentStatus({ type: 'SUCCESS', 'message': STRINGS.bill_payment_success, 'title': STRINGS.payment_success })

                    setAlertVisible(true);
                    setLoading(false);
                }
            }, 1000);
        }
        catch (error: any) {
            setShowPaymentOptions(false);
            setLoading(false)
            showMessageToast(error?.message ?? '')
        }
    }
    const okClick = async () => {
        setAlertVisible(false);
        props.navigation.dispatch(
            CommonActions.reset({
                index: 0,
                routes: [
                    { name: SCREENS.BottomBar.identifier }
                ],
            })
        );
    }

    return (
        <StripeProvider publishableKey="pk_test_51OFd0jL4Cr6vAwq9tFeceN6CXG8DsaeVgkwPumExbc3tpPl3P459OzQ7qHBWli3piR4O6vINgIfCyuqwr3Xl1RiD00jFscF7YQ">
            <View style={styles(theme).container}>
                <Header
                    title={STRINGS.pay_bill}
                    onBack={() => { props.navigation.goBack() }} />
                {postpaidMsisdns.length > 0 &&
                    <View style={styles(theme).container}>
                        <MsisdnsList
                            msisdn={postpaidMsisdns[0]}
                            msisdnList={postpaidMsisdns}
                            onPress={(item) => {
                            }}
                        />
                        <Text
                            style={{ marginHorizontal: getScaleSize(24) }}
                            align="center"
                            font={FONTS.Roboto.Bold}
                            color={theme._333333}
                            size={getScaleSize(18)}>
                            {STRINGS.current_invoice}
                        </Text>
                        <FlatList
                            data={billDetails}
                            ListFooterComponent={() => {
                                return (
                                    <View style={{ height: getScaleSize(170) }}></View>
                                )
                            }}
                            renderItem={({ item, index }) => {
                                return (
                                    <View style={styles(theme).invoiceContainer}>
                                        <View style={styles(theme).detailsContainer}>
                                            <Text
                                                style={{ flex: 1 }}
                                                font={FONTS.Roboto.Medium}
                                                color={theme._828282}
                                                size={getScaleSize(14)}>
                                                {STRINGS.invoice_id}
                                            </Text>
                                            <Text
                                                font={FONTS.Roboto.Medium}
                                                color={theme._000}
                                                size={getScaleSize(14)}>
                                                {item.bill_id}
                                            </Text>
                                        </View>
                                        <View style={styles(theme).detailsContainer}>
                                            <Text
                                                style={{ flex: 1 }}
                                                font={FONTS.Roboto.Medium}
                                                color={theme._828282}
                                                size={getScaleSize(14)}>
                                                {STRINGS.bill_date}
                                            </Text>
                                            <Text
                                                font={FONTS.Roboto.Medium}
                                                color={theme._000}
                                                size={getScaleSize(14)}>
                                                {moment(item.bill_date * 1000).format('DD MMM YYYY')}
                                            </Text>
                                        </View>
                                        <View style={styles(theme).detailsContainer}>
                                            <Text
                                                style={{ flex: 1 }}
                                                font={FONTS.Roboto.Medium}
                                                color={theme._828282}
                                                size={getScaleSize(14)}>
                                                {STRINGS.amount_due}
                                            </Text>
                                            <Text
                                                font={FONTS.Roboto.Medium}
                                                color={theme._000}
                                                size={getScaleSize(14)}>
                                                {STRINGS.currency + item.amount / 100}
                                            </Text>
                                        </View>
                                        <View style={styles(theme).dashedLine}></View>
                                        <View style={styles(theme).amountContainer}>
                                            <View style={styles(theme).textContainer}>
                                                <Icons
                                                    name={'download'}
                                                    color={theme._54B4D3}
                                                    type={'Fontisto'}
                                                    size={15} />
                                                <Text
                                                    style={{ marginHorizontal: getScaleSize(15) }}
                                                    font={FONTS.Roboto.Medium}
                                                    color={theme._54B4D3}
                                                    size={getScaleSize(14)}>
                                                    {STRINGS.download_invoice}
                                                </Text>
                                            </View>
                                            {item?.is_paid ? (
                                                <Button style={styles(theme).buttonContainer}
                                                    title={STRINGS.pay_now}
                                                    isDisable
                                                    onPress={() => { showMessageToast(STRINGS.bill_paid); }}
                                                />
                                            ) : (
                                                <Button style={styles(theme).buttonContainer}
                                                    title={STRINGS.pay_now}
                                                    onPress={() => { openPaymentSheet(item) }}
                                                />
                                            )}
                                        </View>
                                    </View>
                                )
                            }} />
                        <SafeAreaView />
                    </View>
                }
                {loading && <ProgressView />}
            </View>
            <AlertModal
                title={paymentStatus.title}
                description={paymentStatus.message}
                isVisible={isAlertVisible}
                imageType={paymentStatus.type}
                actions={buttonArray}
                onClose={() => { setAlertVisible(false) }}
                onPress={(e: any, index: number) => {
                    if (index == 0) {
                        okClick()
                    }
                }}
            />
        </StripeProvider>
    )
}

const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    invoiceContainer: {
        backgroundColor: theme._FFF,
        borderRadius: getScaleSize(15),
        borderColor: theme._F5F5F5,
        borderWidth: getScaleSize(1),
        padding: getScaleSize(15),
        marginHorizontal: getScaleSize(20),
        marginVertical: getScaleSize(10),
        marginBottom: getScaleSize(10)
    },
    amountContainer: { flexDirection: 'row', alignItems: 'center', },
    dashedLine: {
        borderBottomColor: theme._AFAFAF,
        borderStyle: 'dashed',
        borderBottomWidth: getScaleSize(1),
        marginVertical: getScaleSize(10)
    },
    detailsContainer: {
        flexDirection: 'row', alignItems: 'center',
        paddingVertical: getScaleSize(5)
    },
    textContainer: {
        flexDirection: 'row', alignItems: 'center',
        flex: 1,
    },
    buttonContainer: { width: getScaleSize(100), marginVertical: getScaleSize(5) }
})


export default PayBill