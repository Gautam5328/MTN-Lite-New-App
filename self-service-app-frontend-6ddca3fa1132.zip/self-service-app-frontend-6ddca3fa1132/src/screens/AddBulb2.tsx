import { View, TouchableOpacity, StyleSheet, Image, SafeAreaView } from 'react-native'
import React, { useContext, useState } from 'react'
//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context"

//ASSETS & CONSTANT
import { FONTS, IMAGES } from "../assets"
import { STRINGS, getScaleSize } from "../constant"

//COMPONENTS
import { Button, Header, Text } from "../components"

//SCREENS
import { SCREENS } from "../screens"

//PACKAGES
import ProgressCircle from 'react-native-progress-circle'

function AddBulb2(props: any) {

    const { theme } = useContext(ThemeContext);

    const { logDetails } = useContext(ShipbookContext);

    function onContinue() {
        logDetails("Continue button clicked");
        props.navigation.navigate(SCREENS.NameDevice.identifier);
    }

    return (
        <View style={style(theme).rootContainer}>
            <Header
                title={STRINGS.add_smart_bulb}
                onBack={() => { props.navigation.goBack() }} />
            <View style={style(theme).container}>
                <View style={style(theme).headContainer}>
                    <Text
                        style={style(theme).heading}
                        font={FONTS.Roboto.Regular}
                        color={theme._000}
                        size={getScaleSize(20)}>
                        {STRINGS.looking_for_nearby_devices}
                    </Text>
                </View>
                <View style={style(theme).progressContainer}>
                    <ProgressCircle
                        percent={20}
                        radius={55}
                        borderWidth={8}
                        color={theme._3399FF}
                        shadowColor={theme._D3D3D3}
                        bgColor={theme._FFF}
                    >
                        <Text
                            style={style(theme).heading}
                            font={FONTS.Roboto.Regular}
                            color={theme._000}
                            size={getScaleSize(17)}>
                            {STRINGS.twenty}
                        </Text>
                    </ProgressCircle>
                </View>
                <View style={style(theme).textContainer}>
                    <Text
                        font={FONTS.Roboto.Regular}
                        color={theme._000}
                        size={getScaleSize(17)}>
                        {STRINGS.having_trouble_finding_the_device}
                    </Text>
                    <Text
                        style={style(theme).click}
                        font={FONTS.Roboto.Regular}
                        color={theme.MAIN_THEME_COLOR}
                        size={getScaleSize(17)}>
                        {STRINGS.click_here}
                    </Text>
                </View>

                <View style={style(theme).btnContainer}>
                    <Button
                        style={style(theme).btnGetStarted}
                        title={STRINGS.continue}
                        onPress={() => onContinue()}
                    />
                    <Text
                        style={style(theme).subtitle}
                        font={FONTS.Roboto.Regular}
                        color={theme._AFAFAF}
                        size={getScaleSize(15)}>
                        {STRINGS.cancel}
                    </Text>
                </View>
                <SafeAreaView />
            </View>
        </View>

    )
}

export default AddBulb2

const style = (theme: ThemeContextType['theme']) => StyleSheet.create({

    rootContainer: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    container: {
        paddingHorizontal: getScaleSize(24),
        flex: 1.0
    },
    subtitle: {
        alignSelf: 'center'
    },
    btnGetStarted: {
        marginTop: getScaleSize(40),
        marginBottom: getScaleSize(30)
    },
    progressContainer: { justifyContent: 'flex-end', alignItems: 'center', flex: 0.2 },
    textContainer: { justifyContent: 'center', marginTop: 20, alignItems: 'center', flex: 0.1 },
    headContainer: { flex: 0.1, justifyContent: 'center' },
    heading: { fontWeight: 'bold' },
    btnContainer: { justifyContent: 'flex-end', flex: 0.55 },
    click: { textDecorationLine: 'underline' },
})