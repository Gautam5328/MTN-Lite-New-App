import React, { useEffect, useState } from 'react';
import { View, StyleSheet } from 'react-native';
//Context
import { ThemeContext } from "../context";
//Constant
import { showMessageToast } from '../constant';
//API
import { API } from '../api';
//Components
import { Header, ProgressView } from '../components';
//Packages
import WebView from 'react-native-webview';

function Shopping(props: any) {

    const [webviewUrl1, setWebviewUrl1] = useState('');

    const [loading, setLoading] = useState(false);

    useEffect(() => {
        eshop();
    }, []);

    const eshop = async () => {
        try {
            setLoading(true);
            const result = await API.transactionInstance.get('/eshop/information')
            if (result.status == 200) {
                const apiUrl = result.data.url;
                setWebviewUrl1(apiUrl);
                setLoading(false);
            }
        } catch (error: any) {
            setLoading(false);
            showMessageToast(error?.message ?? '')
        }
    };

    return (
        <View style={styles.container}>
            <Header
                title={''}
                onBack={() => { props.navigation.goBack() }}
            />
            {loading && <ProgressView />}
            <WebView source={{ uri: webviewUrl1 }} style={styles.container} />
        </View>
    );
};

export default Shopping;

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    redLine: {
        height: 1,
        backgroundColor: 'red',
    },
});