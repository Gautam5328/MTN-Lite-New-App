import { View, TouchableOpacity, StyleSheet, Image, SafeAreaView } from 'react-native'
import React, { useContext, useState } from 'react'
//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context"

//ASSETS & CONSTANT
import { FONTS, IMAGES } from "../assets"
import { STRINGS, getScaleSize } from "../constant"

//COMPONENTS
import { Button, Header, Text } from "../components"

//SCREENS
import { SCREENS } from "../screens"

//PACKAGES
import ProgressCircle from 'react-native-progress-circle'

function DeviceFound(props: any) {

    const { theme } = useContext(ThemeContext);

    const { logDetails } = useContext(ShipbookContext);

    function onNext() {
        logDetails("Continue button clicked");
        props.navigation.navigate(SCREENS.NameDevice.identifier);
    }

    return (
        <View style={style(theme).rootContainer}>
            <Header
                title={STRINGS.devices}
                onBack={() => { props.navigation.goBack() }} />
            <View style={style(theme).container}>
                <View style={style(theme).headContainer}>
                    <Text
                        font={FONTS.Roboto.Bold}
                        color={theme._000}
                        size={getScaleSize(21)}>
                        {STRINGS.devices_found}
                    </Text>
                </View>
                <View style={style(theme).btnContainer}>
                    <Button
                        style={style(theme).btnGetStarted}
                        title={STRINGS.next}
                        onPress={() => onNext()}
                    />
                </View>
                <SafeAreaView />
            </View>
        </View>
    )
}

export default DeviceFound

const style = (theme: ThemeContextType['theme']) => StyleSheet.create({

    rootContainer: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    container: {
        paddingHorizontal: getScaleSize(24),
        flex: 1.0
    },
    btnGetStarted: {
        marginBottom: getScaleSize(30)
    },
    headContainer: {
        flex: 0.25,
        justifyContent: 'flex-end',
        alignItems: 'center'
    },
    btnContainer: {
        justifyContent: 'flex-end',
        flex: 0.65
    },

})