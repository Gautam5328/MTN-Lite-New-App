import React, { useContext, useEffect, useState } from "react";
import { Image, SafeAreaView, StyleSheet, TextInput, TouchableOpacity, View } from "react-native";

//CONTEXT
import { ThemeContext, ThemeContextType } from "../context";

//CONSTANT & UTILS
import { STRINGS, formatRawMobileNumber, getScaleSize, showMessageToast } from "../constant";
import { FONTS, IMAGES } from "../assets";

//COMPONENTS
import { Button, Header, NumberBox, PhoneBook, Text } from "../components";

//SCREENS
import { SCREENS } from "../screens";

//PACKAGES
import { useSelector } from "react-redux";


function ShareDataFrom(props: any) {

    const customerdetails = useSelector((state: any) => state.customerData);

    const [selectedData, setSelectedData] = useState<any>('')
    const [shareData, setShareData] = useState<any>('')
    const [mobileNumber, setMobileNumber] = useState<any>(customerdetails?.customer?.msisdns?.[0] ?? {})
    const [toNumber, setToNumber] = useState<any>('')
    const [toMsisdn, setToMsisdn] = useState<any>('')


    const { theme } = useContext(ThemeContext)

    function onContinue() {

        if (!toNumber) {
            showMessageToast(STRINGS.enter_mobile_number_message);
            return;
        } else if (toNumber.length < 10) {
            showMessageToast(STRINGS.enter_valid_number_error);
            return;
        } else if (!selectedData) {
            showMessageToast(STRINGS.enter_data_message);
            return;
        }
        props.navigation.navigate(SCREENS.ShareDataConfirm.identifier, {
            frommsisdn: mobileNumber,
            tomsisdn: { msisdn: formatRawMobileNumber(toNumber), customer_name: toMsisdn?.customer_name ?? 'Unknown' },
            data: selectedData
        })
    }

    function checkData(value: any) {
        setShareData(value)
        if (value >= 1024) {
            let data = Math.round(Number(value / 1024) * 100) / 100
            setSelectedData(data + ' GB')
        } else {
            setSelectedData(value + ' MB')
        }
    }

    const handleSelectPhoneNumber = async () => {
        try {
            const phoneNumber = await PhoneBook();
            setToNumber(phoneNumber?.msisdn ?? '');
            setToMsisdn(phoneNumber)
        } catch (error) {
            console.error('Error selecting phone number:');
        }
    };

    return (
        <View style={styles(theme).container}>
            <Header
                title={STRINGS.share_data}
                onBack={() => { props.navigation.goBack() }} />
            <Text
                style={styles(theme).fromText}
                font={FONTS.Roboto.Bold}
                color={theme._828282}
                size={getScaleSize(16)}>
                {STRINGS.from}
            </Text>
            <NumberBox style={styles(theme).numberBox} item={mobileNumber}
                onPress={() => {
                    props.navigation.navigate(SCREENS.SelectNumber.identifier, {
                        selectedItem: mobileNumber,
                        msisdnList: customerdetails?.customer?.msisdns ?? [],
                        onSelect: (item: any) => {
                            setMobileNumber(item)
                        }
                    })
                }} />
            <Text
                style={styles(theme).fromText}
                font={FONTS.Roboto.Bold}
                color={theme._828282}
                size={getScaleSize(16)}>
                {STRINGS.to}
            </Text>
            <View style={styles(theme).inputContainer}>
                <TextInput
                    keyboardType="number-pad"
                    value={toNumber}
                    onChangeText={(value) => { setToNumber(value) }}
                    style={styles(theme).numberInput}
                    placeholder={STRINGS.mobile_number}
                    placeholderTextColor={theme._333333} />
                <TouchableOpacity onPress={handleSelectPhoneNumber} >
                    <Image style={styles(theme).phoneBookImage} source={IMAGES.contact_book} />
                </TouchableOpacity>
            </View>
            <Text
                style={styles(theme).dataText}
                font={FONTS.Roboto.Bold}
                color={theme._828282}
                size={getScaleSize(16)}>
                {STRINGS.data}
            </Text>
            <View style={styles(theme).dataContainer}>
                {['50 MB', '100 MB', '200 MB', '500 MB', '1 GB', '2 GB', '5 GB'].map((e, index) => {
                    return (
                        <TouchableOpacity
                            key={index}
                            style={selectedData == e ? styles(theme).selectedDataBox : styles(theme).dataBox} onPress={() => {
                                setSelectedData(e)
                            }}>
                            <Text
                                font={FONTS.Roboto.Bold}
                                color={selectedData == e ? theme.TEXT_COLOR_AS_THEME : theme._333333}
                                size={getScaleSize(12)}>
                                {e}
                            </Text>
                        </TouchableOpacity>
                    )
                })}
            </View>
            <Text
                style={styles(theme).orText}
                font={FONTS.Roboto.Bold}
                color={theme._D3D3D3}
                size={getScaleSize(16)}>
                {STRINGS.or}
            </Text>

            <View style={[styles(theme).inputContainer, {
                marginTop: getScaleSize(20),
            }]}>
                <TextInput
                    keyboardType="number-pad"
                    value={shareData}
                    onChangeText={(value) => { checkData(value) }}
                    style={styles(theme).numberInput}
                    placeholder={STRINGS.share_data_value}
                    placeholderTextColor={theme._333333} />
            </View>
            <View style={styles(theme).container} />
            <Button
                isDisable={(toNumber.length < 10 || selectedData == '') ? true : false}
                style={styles(theme).btnContinue}
                title={STRINGS.proceed}
                onPress={() => onContinue()} />
            <SafeAreaView />
        </View>
    )
}


const styles = (theme: ThemeContextType['theme']) => StyleSheet.create({
    container: {
        flex: 1.0,
        backgroundColor: theme._FFF
    },
    fromText: {
        marginTop: getScaleSize(20),
        marginBottom: getScaleSize(10),
        marginHorizontal: getScaleSize(28),
    },
    numberBox: {
        marginHorizontal: getScaleSize(24),
    },
    dataText: {
        marginTop: getScaleSize(20),
        marginBottom: getScaleSize(2),
        marginHorizontal: getScaleSize(28),
    },
    orText: {
        marginTop: getScaleSize(20),
        marginBottom: getScaleSize(2),
        marginHorizontal: getScaleSize(28),
        alignSelf: 'center'
    },
    dataContainer: {
        marginLeft: getScaleSize(18),
        marginHorizontal: getScaleSize(24),
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    dataBox: {
        marginTop: getScaleSize(8),
        marginLeft: getScaleSize(8),
        paddingHorizontal: getScaleSize(8),
        paddingVertical: getScaleSize(4),
        backgroundColor: theme._F5F5F5,
        borderRadius: getScaleSize(8),
    },
    selectedDataBox: {
        marginTop: getScaleSize(8),
        marginLeft: getScaleSize(8),
        paddingHorizontal: getScaleSize(8),
        paddingVertical: getScaleSize(4),
        backgroundColor: theme.MAIN_THEME_COLOR,
        borderRadius: getScaleSize(8),
    },
    btnContinue: {
        marginVertical: getScaleSize(40),
        marginHorizontal: getScaleSize(24),
    },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: theme._D3D3D3,
        marginHorizontal: getScaleSize(24),
        paddingHorizontal: getScaleSize(10),
    },
    numberInput: {
        flex: 1.0,
        height: getScaleSize(40),
        color: theme._333333
    },
    phoneBookImage: {
        height: getScaleSize(20),
        width: getScaleSize(20),
    },
    shareOthers: {
        alignSelf: 'flex-end',
        marginHorizontal: getScaleSize(24),
        marginTop: getScaleSize(8),
    }
})

export default ShareDataFrom

