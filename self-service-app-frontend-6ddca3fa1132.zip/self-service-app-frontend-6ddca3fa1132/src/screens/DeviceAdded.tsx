import { View, TouchableOpacity, StyleSheet, SafeAreaView } from 'react-native'
import React, { useContext } from 'react'
//CONTEXT
import { ShipbookContext, ThemeContext, ThemeContextType } from "../context"

//ASSETS & CONSTANT
import { FONTS, IMAGES } from "../assets"
import { STRINGS, getScaleSize } from "../constant"

//COMPONENTS
import { Button, Text } from "../components"

//SCREENS
import { SCREENS } from "../screens"

//PACKAGES
import ProgressCircle from 'react-native-progress-circle'

function DeviceAdded(props: any) {

    const { theme } = useContext(ThemeContext);

    const { logDetails } = useContext(ShipbookContext);

    function onFinish() {
        logDetails("Finish button clicked");
        props.navigation.navigate(SCREENS.BottomBar.identifier);
    }

    return (
        <View style={style(theme).rootContainer}>
            <View style={style(theme).container}>
                <View style={style(theme).progressContainer}>
                    <ProgressCircle
                        percent={100}
                        radius={70}
                        borderWidth={8}
                        color={theme._3399FF}
                        shadowColor={theme._D3D3D3}
                        bgColor={theme._FFF}
                    >
                        <Text
                            font={FONTS.Roboto.Bold}
                            size={getScaleSize(20)}>
                            {STRINGS.hundred}
                        </Text>
                    </ProgressCircle>
                </View>
                <View style={style(theme).textcontainer}>
                    <Text
                        style={style(theme).text}
                        font={FONTS.Roboto.Regular}
                        color={theme._000}
                        size={getScaleSize(21)}>
                        {STRINGS.congratulations}
                    </Text>
                    <Text
                        style={style(theme).text}
                        font={FONTS.Roboto.Regular}
                        color={theme._000}
                        size={getScaleSize(21)}>
                        {STRINGS.your_devices_added_successfully}
                    </Text>
                </View>
                <View style={style(theme).btncontainer}>
                    <Button
                        style={style(theme).btnGetStarted}
                        title={STRINGS.finish}
                        onPress={() => onFinish()}
                    />
                </View>
            </View>
            <SafeAreaView />
        </View>
    )
}

export default DeviceAdded

const style = (theme: ThemeContextType['theme']) => StyleSheet.create({

    rootContainer: {
        flex: 1.0,
        backgroundColor: theme._FFF,
    },
    container: { flex: 1.0, paddingHorizontal: getScaleSize(24) },
    subtitle: {
        alignSelf: 'center'
    },
    btnGetStarted: {
        // marginTop: getScaleSize(40),
        // marginBottom: getScaleSize(30)
    },
    progressContainer: {
        justifyContent: 'flex-end',
        alignItems: 'center',
        flex: 0.3
    },
    btncontainer: { justifyContent: 'flex-end', flex: 0.3 },
    text: { alignSelf: 'center', fontSize: 22, fontWeight: 'bold', color: 'black' },
    textcontainer: { flex: 0.3, justifyContent: 'center' }
})

