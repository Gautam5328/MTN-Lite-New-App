export const OPRATORS = {
    'DEMO': {
        PRIMARY_THEME_COLOR: '#E31837',

        ICON_COLOR_AS_THEME: '#fff',

        TEXT_COLOR_AS_THEME: '#FFF',

        SUB_TEXT_COLOR_AS_THEME: '#d3d3d3',

        HEADER_TEXT_COLOR: '#E31837'

    },
    'MTN': {
        PRIMARY_THEME_COLOR: '#ffcb05',

        ICON_COLOR_AS_THEME: '#202020',

        TEXT_COLOR_AS_THEME: '#202020',

        SUB_TEXT_COLOR_AS_THEME: '#404040',

        HEADER_TEXT_COLOR: '#202020'
    }
}