export default {
    welcome_to: "Selamat Datang ",
 };