export default {
    //LEADING SCREEN
    your_one_stop_application: "Your One Stop Application.",
    boost_your_life_enhance_your_world: 'Boost your life enhance your world',
    let_get_started: "Let's get started",

    //LOGIN SCREEN
    welcome_to: "Welcome To ",
    telecom: 'Telecom!',
    insert_your_phone_number_to_continue: 'Insert your phone number to continue',
    mobile_number: 'Mobile Number',
    continue: 'Continue',
    or: 'OR',
    continue_with_apple: "Continue with Apple",
    continue_with_facebook: "Continue with Facebook",
    continue_with_google: "Continue with Google",
    enter_mobile_number_message: 'Please enter mobile number',
    enter_valid_number_error: 'Please enter valid mobile number',

    //TABBAR
    home: 'Home',
    smart_home: 'Smart Home',
    play: 'Play',
    more: 'More',

    //VERIFY OTP
    verify_its_you: "Verify it's you",
    we_have_sent_verification_code: "We have sent verification code to ",
    resend_otp: 'Resend OTP',
    invalid_otp: 'Invaild OTP',


    //HOME
    search: 'Search',
    data_balance: 'Data Balance',
    airtime_balance: 'Airtime Balance',
    recharge: 'Recharge',
    recharge_for_friend: 'Recharge for friend',
    buy_bundle: 'Buy Bundle',
    buy_now: 'Buy Now',
    quick_links: 'Quick Links',

    //RECHARGE
    enter_number_and_select_recharge_amount: 'Enter your number and select recharge amount',
    invalid_mobile: 'Invalid Mobile Number',

    //Device
    add_device_header: 'Add Device',
    add_device_description: 'Select the device you want to add',
    smart_bulb: 'Smart Bulb',
    smart_tv: 'Smart TV',
    smart_ac: 'Smart AC',
    air_purifier: 'Air Purifier',
    smart_camera: 'Smart Camera',
    smart_fan: 'Smart Fan',
    cancel: 'Cancel',

    //paymentSuccess
    payment_success: "Congratulations!",
    payment_canceled: "Canceled Payment",
    payment_failed: "Payment Failed!",
    payment_success_desc: "Your recharge was successful",
    ok: 'OK',

    //Buy Bundle
    buy_bundle_success: 'Your bundle purchase was successful',

    //Assign Room
    assign_room_header: 'Assign Room',
    assign_room_text: 'Select the room where you want to access smart bulb',
    living_room: 'Living Room',
    bed_room1: 'Bedroom 1',
    bed_room2: 'Bedroom 2',
    kichen: 'Kichen',
    guest_room: 'Guest Room',
    add_new_room: 'Add New Room',

    //Name Device
    name_your_device: 'Name your Devices',
    congratulations: 'Congratulations!',
    your_new_smart_device_added_successfully: 'Your new smart device added successfully',
    now_lets_give_your_device_a_name: 'Now, lets give your device(s) a name',
    device_name: 'Device Name',

    //Device Added
    hundred:'100%',
    your_devices_added_successfully:' Your device(s) has been setup successfully.',
    your_device_has_successfully: 'Your device has successfully',
    been_added: 'been added',
    finish: 'Finish',

    //Add Bulb1
    add_smart_bulb: 'Add Smart Bulb',
    please_follow_these_instructions: 'Please follow these instructions',
    connect_the_bulb_in_the_holder: '1. Connect the bulb in the holder',
    switch_the_bulb_on_and_off_five_times: '2. Switch the bulb On and Off five times',
    bulb_will_now_start_blinking: '3. Bulb will now start blinking',
    press_continue: '4. Press Continue',

    //Add Bulb2
    looking_for_nearby_devices: 'Looking for nearby devices',
    having_trouble_finding_the_device: 'Having trouble finding the device?',
    click_here: 'Click Here',
    twenty: '20%',

    //SHARE MENU
    share_data: 'Share Data',
    proceed: "Proceed",
    share: 'Share',
    from: 'From',
    to: 'To',
    data: 'Data',
    linked_number: "Linked Number",
    confirm_your_share: 'Confirm ',
    share_data_value: 'Enter data value',

    //SHARE AIRTIME
    share_airtime: 'Share Airtime',
    choose_airtime: 'Choose Airtime',
    share_amount: 'Enter amount',

    //BORROW DATA
    borrow_data: 'Borrow Data',
    borrow_for: 'Borrowing for',
    enter_data_message: 'Please select/enter data value',

    //BORROW AIRTIME
    borrow_airtime: 'Borrow Airtime',
    enter_amount_message: 'Please select/enter amount',

    //SELECT NUMBER
    select_number: 'Select Number',

    //BORROW
    header_title: 'Borrow Data',
    choose_borrow_airtime: 'Choose Borrow Airtime',
    choose_borrow_data: 'Choose Borrow Data',
    airtime: 'Airtime',

    //Share Airtime Data
    telecom_share: 'Share',
    share_airtime_data_header: 'Share Airtime/Data',

    //Borrow Airtime Data
    telecom_borrow: 'Borrow',
    borrow_airtime_data_header: 'Borrow Airtime/Data',

    //Privacy Policy
    privacy_policy_header: 'Privacy Policy',

    //Terms Condition
    terms_condiitons_header: 'Terms & Conditions',

    //History
    transaction_history_header: 'Transaction History',

    //Logout
    logout: 'Logout',

    //CONTACT_US
    contact_us: 'Contact Us',
    contact_us_msg: 'You can get in touch with us through below platforms. Our team will reach out to you as soon as it would be possible.',
    customer_support: 'Customer Support',
    contact_no: 'Contact Number',
    email_address: 'Email Address',

    //VOUCHER
    enter_voucher: 'Enter Voucher',

    //PAY BILL
    pay_bill: 'Pay Bill',
    current_invoice: 'Current Invoice',
    total_outstanding_amount: 'Total Outstanding Amount',
    download_invoice: 'Download Invoice',
    pay_now: 'Pay Now',
    invoice_id: 'Invoice ID',
    bill_date: 'Bill date',
    amount_due: 'Amount due',
    bill_payment_success: "Your bill payment was successful",
    bill_paid: 'Bill already paid',

    //FIBER
    buy_fiberplan: 'Fiber Plan',
    buy_fiberPlan_success: 'Your fiber purchase was successful',
    current_plans: 'Current Plans',
    fiber: 'Fiber',

    //FIBER CARD
    upgrade: 'Upgrade',
    browse_plans: 'Browse Plans',
    data_speed: 'Data & Speed',

    //ROAMING
    roaming: 'Roaming',
    voice_roaming: "Voice",
    sms_roaming: 'SMS',
    data_roaming: 'Data',

    //FASTMODE
    fast_mode: 'Fast Mode',
    press_and_hold: 'Press and hold the button on the plug until the LED starts blinking rapidly',
    next: 'Next',
    switch_to_slow: 'Switch to Slow Mode',

    //SLOWMODE
    slow_mode: 'Slow Mode',
    switch_to_fast: 'Switch to Fast Mode',

    //FASTMODESEARCH
    searching_for_device: 'Searching for Device',

    //SLOWMODE2
    clicking_next: 'Clicking Next will open your WiFi Settings.',
    please_connect: 'Please Connect to the SmartLife-XXX network.',
    once_connected: 'Once Connected, please come back to the App.',

    //DeviceFound
    devices:'Devices',
    devices_found:'2 devices found',
    no_devices_found:'No devices found',

    //WIFIDETAILS
    wifi_details:'Wifi Details',
    lets_get_your_wifi_details:'Lets get your WiFi Details',
    please_ensure_your_wifi:'Please ensure your WiFi router is 2.4 GHz'
};