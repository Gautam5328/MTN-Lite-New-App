import ACTION_TYPES from '../actions/actiontypes';

const initialState = {
    loading: false,
    error: '',
    customer: {},
}
const customerReducer = (state = initialState, action:any) => {
    switch (action.type) {
        
        case ACTION_TYPES.SET_CUSTOMERDATA:
            return {
                ...state,
                customer: action.payload,
                loading: false,
            };
        default:
            return initialState
    }
}
export default customerReducer
