import { API } from '../../api'
import ACTION_TYPES from './actiontypes'

export const setCustomerData = (data:any) => {
    return async (dispatch:any) => {
        dispatch({
            type: ACTION_TYPES.SET_CUSTOMERDATA,
            payload: data,
        })
    }
}


