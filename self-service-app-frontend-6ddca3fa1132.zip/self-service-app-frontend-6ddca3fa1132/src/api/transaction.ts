import axios from 'axios';
import Shipbook from "@shipbook/react-native";
import NetInfo from '@react-native-community/netinfo'

import { responseInterceptor } from './responseValidation'
import { responseErrorInterceptor } from './errorValidation'
import { getValidAccessToken } from './token';

//PACKAGES
import KeysTurbo from 'react-native-keys';

export const transactionInstance = axios.create({
    baseURL: KeysTurbo.secureFor('transaction_url'),
    headers: {
        "Content-Type": " application/x-amz-json-1.1"
    }
});

transactionInstance.interceptors.request.use(
    async (config) => {
        var isConnected = (await NetInfo.fetch()).isConnected;
        if (isConnected) {
        if (!KeysTurbo.DISABLE_SHIP_BOOK_LOG) {
            const log = Shipbook.getLogger('API CONFIG')
            log.i(`Config Header ${JSON.stringify(config?.headers)}`)
            log.i(`Config Base URL ${JSON.stringify(config?.baseURL)}`)
            log.i(`Config Data ${JSON.stringify(config?.data)}`)
        }

        try {
            const result: any = await getValidAccessToken()
            config.headers.Authorization = `${"Bearer " + result?.IdToken}`
            return config;
        }
        catch (error: any) {
            if (!KeysTurbo.DISABLE_SHIP_BOOK_LOG) {
                const log = Shipbook.getLogger('Error')
                log.e(`Error ${error}`)
                log.e(`Error Status ${error?.response?.status}`)
                log.e(`Error Config Header ${JSON.stringify(error?.response?.config?.headers)}`)
                log.e(`Error Config Base URL ${JSON.stringify(error?.response?.config?.baseURL)}`)
                log.e(`Error Config Data ${JSON.stringify(error?.response?.config?.data)}`)
                log.e(`Error Details ${JSON.stringify(error?.response?.data)}`)
            }

            return Promise.reject({
                error: error,
                message: error?.response?.data?.message ?? '',
                data: error?.response?.data ?? null,
                isError: true
            });
        }
    }else{
        return Promise.reject({
            error: {},
            message:  'No Internet Connection',
            data: null,
            isError: true
        });
    }
    },
    (error) => {
        if (!KeysTurbo.DISABLE_SHIP_BOOK_LOG) {
            const log = Shipbook.getLogger('Error')
            log.e(`Config Error ${error}`)
            log.e(`Config Error Status ${error?.response?.status}`)
            log.e(`Config Error Header ${JSON.stringify(error?.response?.config?.headers)}`)
            log.e(`Config Error Base URL ${JSON.stringify(error?.response?.config?.baseURL)}`)
            log.e(`Config Error Data ${JSON.stringify(error?.response?.config?.data)}`)
            log.e(`Config Error Details ${JSON.stringify(error?.response?.data)}`)
        }

        return Promise.reject({
            error: error,
            message: error?.response?.data?.message ?? '',
            data: error?.response?.data ?? null,
            isError: true
        });
    }
);

transactionInstance.interceptors.response.use(responseInterceptor, responseErrorInterceptor);
