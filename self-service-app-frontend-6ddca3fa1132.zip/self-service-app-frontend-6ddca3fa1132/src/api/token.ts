import { STRINGS, Storage } from "../constant";

//API
import { API } from "../api";

//PACKAGES
import "core-js/stable/atob";
import { jwtDecode } from 'jwt-decode'
import KeysTurbo from "react-native-keys";

export async function getValidAccessToken() {

    const accessToken = await Storage.get(Storage.ACCESS_TOKEN)
    
    if (accessToken) {
        const isValid = isValidAccessToken(accessToken)

        if (isValid) {
            return { IdToken: accessToken }
        }
    }

    const refreshToken = await Storage.get(Storage.REFRESH_TOKEN)

    const params = {
        AuthFlow: STRINGS.refresh_token,
        ClientId: KeysTurbo.secureFor('amazon_client_id'),
        AuthParameters: {
            REFRESH_TOKEN: refreshToken,
        },
    }

    try {
        const result = await API.authInstance.post('', params, {
            headers: { 'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth' }
        })
    
        if (result.status == 200) {
            if (result?.data?.AuthenticationResult && result?.data?.AuthenticationResult?.IdToken) {
                Storage.save(Storage.ACCESS_TOKEN, result?.data?.AuthenticationResult?.IdToken);
            }
    
            return { IdToken: result?.data?.AuthenticationResult?.IdToken }
        }
    }
    catch (error) {
        return error
    }
}

export function isValidAccessToken(token: string) {
    let decodedToken: any = jwtDecode(token);

    let currentDate = new Date();

    if (decodedToken.exp * 1000 < currentDate.getTime()) {
        return false
    } else {
        return true;
    }
}