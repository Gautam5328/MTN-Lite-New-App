import axios from 'axios';
import Shipbook from "@shipbook/react-native";

import { responseInterceptor } from './responseValidation'
import { responseErrorInterceptor } from './errorValidation'

//PACKAGES
import KeysTurbo from 'react-native-keys';
import NetInfo from '@react-native-community/netinfo'

export const authInstance = axios.create({
    baseURL: KeysTurbo.secureFor('auth_url'),
    headers: {
        "Content-Type": " application/x-amz-json-1.1"
    }
});

authInstance.interceptors.request.use(
    async(config) => {

        var isConnected = (await NetInfo.fetch()).isConnected;
        if (isConnected) {
            if (!KeysTurbo.DISABLE_SHIP_BOOK_LOG) {
                const log = Shipbook.getLogger('API CONFIG')
                log.i(`Config Header ${JSON.stringify(config?.headers)}`)
                log.i(`Config Base URL ${JSON.stringify(config?.baseURL)}`)
                log.i(`Config Data ${JSON.stringify(config?.data)}`)
            }


            return config;
        } else {
            return Promise.reject({
                error: {},
                message: 'No Internet Connection',
                data: null,
                isError: true
            });
        }
    },
    (error) => {
        if (!KeysTurbo.DISABLE_SHIP_BOOK_LOG) {
            const log = Shipbook.getLogger('Error')
            log.e(`Config Error ${error}`)
            log.e(`Config Error Status ${error?.response?.status}`)
            log.e(`Config Error Header ${JSON.stringify(error?.response?.config?.headers)}`)
            log.e(`Config Error Base URL ${JSON.stringify(error?.response?.config?.baseURL)}`)
            log.e(`Config Error Data ${JSON.stringify(error?.response?.config?.data)}`)
            log.e(`Config Error Details ${JSON.stringify(error?.response?.data)}`)
        }


        return Promise.reject({
            error: error,
            message: error?.response?.data?.message ?? '',
            data: error?.response?.data ?? null
        });
    }
);

authInstance.interceptors.response.use(responseInterceptor, responseErrorInterceptor);
