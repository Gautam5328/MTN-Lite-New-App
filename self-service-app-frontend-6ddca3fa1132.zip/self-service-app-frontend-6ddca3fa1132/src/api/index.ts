import { authInstance } from "./auth";
import { transactionInstance } from "./transaction";

export const API = {
    authInstance,
    transactionInstance
}