import Shipbook from "@shipbook/react-native";
import KeysTurbo from "react-native-keys";

export const responseInterceptor = (response: any) => {
    if (!KeysTurbo.DISABLE_SHIP_BOOK_LOG) {
        const log = Shipbook.getLogger('Response')
        log.i(`Response Status ${response?.status}`)
        log.i(`Response Config Header ${JSON.stringify(response?.config?.headers)}`)
        log.i(`Response Config Base URL ${JSON.stringify(response?.config?.baseURL)}`)
        log.i(`Response Config Data ${JSON.stringify(response?.config?.data)}`)
        log.i(`Response Details ${JSON.stringify(response?.data)}`)
    }

    return response;
};