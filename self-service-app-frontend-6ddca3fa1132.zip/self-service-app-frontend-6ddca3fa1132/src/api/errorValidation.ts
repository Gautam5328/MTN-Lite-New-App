import Shipbook from "@shipbook/react-native";
import KeysTurbo from "react-native-keys";

export const responseErrorInterceptor = (error: any) => {

    if (!KeysTurbo.DISABLE_SHIP_BOOK_LOG) {
        const log = Shipbook.getLogger('Error')
        log.e(`Error ${error}`)
        log.e(`Error Status ${error?.response?.status}`)
        log.e(`Error Config Header ${JSON.stringify(error?.response?.config?.headers)}`)
        log.e(`Error Config Base URL ${JSON.stringify(error?.response?.config?.baseURL)}`)
        log.e(`Error Config Data ${JSON.stringify(error?.response?.config?.data)}`)
        log.e(`Error Details ${JSON.stringify(error?.response?.data)}`)
    }

    if (error.isError) {
        return Promise.reject(error);
    }
    else {
        return Promise.reject({
            error: error,
            message: error?.response?.data?.message ?? '',
            data: error?.response?.data ?? null
        });
    }
  
};
