import { OPRATORS } from "../../content"

import { operator } from '../../constant'

export let LIGHT_THEME_COLOR = {
    MAIN_THEME_COLOR: OPRATORS[operator].PRIMARY_THEME_COLOR,
    ICON_COLOR_AS_THEME: OPRATORS[operator].ICON_COLOR_AS_THEME,
    TEXT_COLOR_AS_THEME: OPRATORS[operator].TEXT_COLOR_AS_THEME,
    SUB_TEXT_COLOR_AS_THEME: OPRATORS[operator].SUB_TEXT_COLOR_AS_THEME,
    HEADER_TEXT_COLOR: OPRATORS[operator].HEADER_TEXT_COLOR,
    _54B4D3: '#54B4D3',
    _14A44D: '#14A44D',
    _E4A11B: '#E4A11B',
    _80C72E: '#80C72E',
    _F7F7F7: '#f7f7f7',
    _F5F5F5: '#F5F5F5',
    _E8E8E8: '#E8E8E8',
    _D3D3D3: '#d3d3d3',
    _AFAFAF: '#afafaf',
    _333333: "#333333",
    _FFF: '#fff',
    _000: '#000',
    _828282: '#828282',
    _3399FF: "#3399FF",

}

export let DARK_THEME_COLOR = {
    MAIN_THEME_COLOR: OPRATORS[operator].PRIMARY_THEME_COLOR,
    ICON_COLOR_AS_THEME: OPRATORS[operator].ICON_COLOR_AS_THEME,
    TEXT_COLOR_AS_THEME: OPRATORS[operator].TEXT_COLOR_AS_THEME,
    SUB_TEXT_COLOR_AS_THEME: OPRATORS[operator].SUB_TEXT_COLOR_AS_THEME,
    HEADER_TEXT_COLOR: OPRATORS[operator].HEADER_TEXT_COLOR,
    _54B4D3: '#54B4D3',
    _14A44D: '#14A44D',
    _E4A11B: '#E4A11B',
    _80C72E: '#80C72E',
    _F7F7F7: '#f7f7f7',
    _F5F5F5: '#F5F5F5',
    _E8E8E8: '#E8E8E8',
    _D3D3D3: '#d3d3d3',
    _AFAFAF: '#afafaf',
    _333333: "#333333",
    _FFF: '#fff',
    _000: '#000',
    _828282: '#828282',
    _3399FF: "#3399FF",

}